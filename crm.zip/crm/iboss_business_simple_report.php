<?php
/**
* iboss_master_crm_info
*
* 21/04/2016
*/
//error_reporting(E_ALL); 


class Iboss_business_simple_report extends CI_Controller
{

	 function Iboss_business_simple_report(){
		parent::__construct();
        date_default_timezone_set('Asia/Singapore');
        $current_date=date('Y-m-d H:i:s');
		//page limits for the index views are to be adjusted depending on views, requirements and on a per controller basis.
		$this->page_limit = null; //adjust this as required.

		$this->load->database();
		//$this->load->model("Iboss_master_crm_info_model");

		// each controller is responsible for loading its own helpers/libraries
		$this->load->model("Crm_personal_info_model");
		$this->load->model("Crm_corporate_info_model");
		$this->load->model("Crm_contact_info_model");
		$this->load->model("Crm_compliance_info_model");
		$this->load->model("Crm_address_info_model");
		$this->load->model("Crm_markerting_info_model");
		$this->load->model("Iboss_crm_edu_and_emp_info_model");
		$this->load->model("Iboss_view_model");
		
		$this->page_limit = null;
		$this->load->library("pagination");
		$this->load->library("form_validation");
		$this->load->helper("form");
		$this->load->helper("url");
		$this->load->helper("date");
		$this->load->helper("farops_api");
		$this->load->library('datatables'); 
		
        $this->load->model("Iboss_acc_master_crm_info_model");

		
		$this->iboss_read = $this->load->database('iBOSS_read', TRUE);
		
		$this->iboss_w = $this->load->database('default', TRUE);
		
		

	}
	

	


function get_product_json_new_oldTODAY($value='') 
{
//echo 'hhhhh';
// {

// 	error_reporting(E_ALL);
// 			ini_set('display_errors', 1);

// 			ini_set('memory_limit', '-1');
// 			ini_set('max_execution_time', 0);
// 			memory_get_peak_usage(true);

	
   $data = new stdClass();
   $data->templates = array('datatables','datepicker','icheck','chosen','select2');
//  // $data->business_class = $_POST['business_class'];
//   //$far_code = $_POST['far_name'];
//   //$date =explode("-" , $_POST['daterange']);
//   //$start_date = sg2iso(trim($date[0]));
//   //$end_date = sg2iso(trim($date[1]));
//$pep = $_POST['pep'];
  
 
//   if($_POST['filter_by']=='inforce')
//   {
    
// 	  $date="and inforce_date between '$start_date' and '$end_date'";	
//    // $completed_date="and submitted_date between '$start_date' and '$end_date'  and  status='Completed'  group by far_code";	
//       $completed_date="and completion_date between  '$start_date' and '$end_date'"; 
	
//   }else{
	  
// 	 $date="and submission_date between '$start_date' and '$end_date'";	
//      //$completed_date="and submitted_date between '$start_date' and '$end_date'  and status!='Voided'  group by far_code"; 
// 	 $completed_date="and submitted_date between  '$start_date' and '$end_date'"; 
	 
	 
// //   }	  

$client_type=""; 


if($_POST['client_type'] =='all')
{
   $client_type="";  
  //die();
	 
	
}else{
	$client_type="and client_type='".$_POST['client_type']."'";  
   //print_r($gender);
}



//$gender=""; 


if($_POST['gender'] =='Female')
{ 
   $gender="2";  
  //die();
	 
	
}else if($_POST['gender'] =='Male')
{
	
	$gender ="1";
	//	$gender="and gender='".$_POST['gender']."'";  
   //print_r($gender);
}
 else {
	
	//$gender ="2";
	$gender=""; 

 }
 $newgender = "and gender='".$gender."'";

 
$pep="";  
if($_POST['pep'] =='all')
{
   $pep=" where"; 
   //print_r($pep); 
 //die();
	  
	
}else{
	$pep="where pep='".$_POST['pep']."'";  
   
}

 
$sql="";
//$filter_col="";
if($_POST['client_type'] =="INV" or  $_POST['client_type'] =="Personal")
{
$sql ="select count(client_type) from iboss_master_crm_report where client_type='INV'";
print_r($sql); //die();
}
else if($_POST['client_type'] =="Corp")
{
	$sql ="select count(client_type) from iboss_master_crm_report where client_type='Corp'";
}
else {

	$sql= "";

}


/*union
select count(gender) from iboss_master_crm_report  where gender ='1';
*/

/*
if($_POST['business_class'] =="0" or  $_POST['business_class'] =="1")
{
	
  //$sql .="(select count_li from ((select count(*) as count_li,iboss_crm_unique_id,submission_date from iboss_acc_li_policy_info where delete_log='False'  and servicing_far='80002' and inforce_date between '2019-01-01' and '2019-12-31'  group by iboss_crm_unique_id ))a where iboss_crm_unique_id=t1.unique_id)as count_li, 
  //(select submission_date from ((select count(*) as count_li,iboss_crm_unique_id,submission_date from iboss_acc_li_policy_info where delete_log='False'  and servicing_far='80002' and inforce_date between '2019-01-01' and '2019-12-31'  group by iboss_crm_unique_id ))a where iboss_crm_unique_id=t1.unique_id)as submission_date, ";
  $sql .="(select count_li from ((select count(*) as count_li,iboss_crm_unique_id,submission_date from iboss_acc_li_policy_info where delete_log='False'  $servicing_far and inforce_date between '2019-01-01' and '2019-12-31' group by iboss_crm_unique_id ))a where iboss_crm_unique_id=t1.unique_id)as count_li, 
  (select submission_date from ((select count(*) as count_li,iboss_crm_unique_id,submission_date from iboss_acc_li_policy_info where delete_log='False'  $servicing_far and inforce_date between '2019-01-01' and '2019-12-31' group by iboss_crm_unique_id ))a where iboss_crm_unique_id=t1.unique_id)as submission_date,";
//print_r($sql);
//die();
}
if($_POST['business_class'] =="0" or  $_POST['business_class'] =="2")
{
   // $sql .="(select count_inv  from ((select count(*) as count_inv,iboss_crm_unique_id from iboss_acc_inv_report where delete_log='False'  $invs_servicing_far $completed_date group by iboss_crm_unique_id ))a where iboss_crm_unique_id=t1.unique_id)as count_inv,";
	
	$sql .=" '0' as count_inv,";
		  
}
if($_POST['business_class'] =="0" or  $_POST['business_class'] =="3")
{
	$sql .="(select count_gi  from ((select count(*) as count_gi,iboss_crm_unique_id,submission_date from iboss_acc_gi_policy_info where delete_log='False'  $servicing_farcode $date  group by iboss_crm_unique_id ))a where iboss_crm_unique_id=t1.unique_id)as count_gi,";
		   
}
if($_POST['business_class'] =="0" or  $_POST['business_class'] =="6")
{
  $sql .="(select count_group  from ((select count(*) as count_group,iboss_crm_unique_id,submission_date from iboss_acc_group_policy_info where delete_log='False'  $servicing_farcode $date  group by iboss_crm_unique_id ))a where iboss_crm_unique_id=t1.unique_id)as count_group,";
  
}
if($_POST['business_class'] =="0" or  $_POST['business_class'] =="5")
{
  $sql .="(select count_other  from ((select count(*) as count_other,iboss_crm_unique_id,submission_date from iboss_acc_other_services_info where delete_log='False' $servicing_far group by iboss_crm_unique_id ))a where iboss_crm_unique_id=t1.unique_id) as count_other,";

}  */



  $master_excel = "SELECT 
   client_type,
   gender,
  nationality_name,
   pep from iboss_master_crm_report $pep $client_type $newgender LIMIT 10";
   $export = $this->iboss_read->query($master_excel);

   $data->master_export_value =$export->result_array();
  
   echo json_encode($data);
/*
   $master_excel = "SELECT count(client_type)from iboss_master_crm_report where pep='$pep' $client_type $newgender LIMIT 10";
   $export = $this->iboss_read->query($master_excel);

   $data->master_export_value =$export->result_array();
  
   echo json_encode($data);*/
  
}


/* SAMPLE WORK */

function get_product_json_new_old($value='') 
{

	//print_r($_POST); die();

	
	header('Content-Type: application/json');
	
//echo 'hhhhh';
// 

// 	error_reporting(E_ALL);
//  			ini_set('display_errors', 1);

			ini_set('memory_limit', '-1');
			ini_set('max_execution_time', 0);
			memory_get_peak_usage(true);
// echo 'hello';
    $year = $_POST['yearpicker'];
	$biz_based=$_POST['filter_by'];
	$client_type=$_POST['client_type'];
	$gender=$_POST['gender'];
	$nationality=$_POST['nationality_name'];
	$pep=$_POST['pep'];
	$ai=$_POST['ai'];

	if($biz_based=='inforce'){

		$common_biz_based='inforce_date';
		$inv_biz_based='completion_date';
		$others_biz_based='completed_date';

	}else{
		
		$common_biz_based='submission_date';
		$inv_biz_based='submitted_date';
		$others_biz_based='submission_date';

	}
	
	//Client_type start//

if($client_type =='Corp') 
{
	$common_client='corp';

}
else if($client_type =='INV')
{
	$common_client='INV';

}
else{

	//echo 'No records';
	$common_client="";
	//$common_client="and gender";

	//$common_client="and client_type='".$_POST['client_type']."'";
}

//Client_type end//

//Pep start//

$pep="";  
if($_POST['pep'] =='all')
{
   $pep=" and pep"; 
   //print_r($pep); 
 //die();
	  
	
}else{
	$pep="and pep='".$_POST['pep']."'";  
   
}

//Pep end//

//Ai start//

$ai="";  
if($_POST['ai'] =='all')
{
   $ai=" and ai"; 
   
	
}else{
	$ai="and ai='".$_POST['ai']."'";  
   
}

//Ai end//

//Gender start//

if($gender =='1') 
{
	$gender="and gender='".$_POST['gender']."'";

}
else if($gender =='2')
{
	$gender="and gender='".$_POST['gender']."'";

}
else{


	//$gender="and gender='".$_POST['gender']."'";
	
	
	$gender="and gender";




}


//Gender end//

//Nationality Start//
//$nationality="";  
/*if($_POST['nationality_name'] =='all')
{
   $nationality=" and nationality_name"; 
  
  
	
}else{

	echo $nationality="and nationality_name='".$_POST['name']."'";

}*/
//Nationality end//




   $data = new stdClass();
   $data->templates = array('datatables','datepicker','icheck','chosen','select2');

   //echo $hello = "SELECT unique_id,client_type,nationality_id,nationality_name,gender,pep,ai FROM iboss_master_crm_report where client_type='$common_client' $pep $ai $gender $nationality";

   $master_excel = "select *,count(*) from  (select dest.* from (
	select * from (
	select iboss_crm_unique_id from  iboss_acc_li_policy_info  where delete_log='False' and DATE_FORMAT( $common_biz_based ,'%Y' ) = $year
	union
	select iboss_crm_unique_id from  iboss_acc_gi_policy_info  where delete_log='False' and DATE_FORMAT( $common_biz_based ,'%Y' ) = $year 
	union
	select iboss_crm_unique_id from  iboss_acc_group_policy_info  where delete_log='False' and DATE_FORMAT( $common_biz_based ,'%Y' ) = $year 
	union
	select iboss_crm_unique_id from iboss_acc_inv_report where delete_log='False' and DATE_FORMAT( $inv_biz_based ,'%Y' ) = $year
	union
	select iboss_crm_unique_id from iboss_acc_other_services_info where delete_log='False' and DATE_FORMAT( $others_biz_based ,'%Y' ) = $year
	)a
	) src,
	(SELECT unique_id,client_type,nationality_id,nationality_name,gender,pep,ai FROM iboss_master_crm_report where client_type='$common_client' $pep $ai $gender) dest where dest.unique_id=src.iboss_crm_unique_id 
	)a group by gender,nationality_name,pep,client_type,ai";

	//print_r($master_excel); die();
   

	
	
   
  
   
	  $export = $this->iboss_read->query($master_excel);
		// print_r($export); die();
	  $data1->master_export_value =$export->result_array();
	 echo json_encode($data1);
  
}

/* END WORK * /


  /*************************************  Start Excel Export **********************/
  function export_excel_report( )
  {
  ini_set('memory_limit', '-1');
  ini_set('max_execution_time', 0);
  memory_get_peak_usage(true);
  
  $business_class = $_POST['business_class'];
  $far_code = $_POST['far_name'];
  $date =explode("-" , $_POST['daterange']);
  $start_date = sg2iso(trim($date[0]));
  $end_date = sg2iso(trim($date[1]));
  
  if($_POST['far_name'] !="")
  {
	  $far_code="and far_code='".$_POST['far_name']."'";
	  $servicing_far="and servicing_far='".$_POST['far_name']."'";
	  $servicing_farcode="and servicing_farcode='".$_POST['far_name']."'";
	  $invs_servicing_far="and far_code='".$_POST['far_name']."'";
  }else{
	  
	  if($_POST['far_status'] =='all')
	  {
		  
	  $far_code="and  far_code in (select iboss_far_code from iboss_farops_far_info)";
	  $servicing_far="and servicing_far in (select iboss_far_code from iboss_farops_far_info)";
	  $servicing_farcode="and servicing_farcode in (select iboss_far_code from iboss_farops_far_info)";
	  $invs_servicing_far="and trans_servicing_farcode in (select iboss_far_code from iboss_farops_far_info)";
		  
	  }else{
		  
	  $far_code="and far_code in (select iboss_far_code from iboss_farops_far_info where iboss_status='".$_POST['far_status']."')";
	  $servicing_far="and servicing_far in (select iboss_far_code from iboss_farops_far_info where iboss_status='".$_POST['far_status']."')";
	  $servicing_farcode="and servicing_farcode in (select iboss_far_code from iboss_farops_far_info where iboss_status='".$_POST['far_status']."')";
	  $invs_servicing_far="and trans_servicing_farcode in (select iboss_far_code from iboss_farops_far_info where iboss_status='".$_POST['far_status']."')";  
	  
	  }

  }
  
  if($_POST['filter_by']=='inforce')
  {
    
	  $date="and inforce_date between '$start_date' and '$end_date'";	
      $completed_date="and submitted_date between  '$start_date' and '$end_date'"; 
	  $completed_date_other="and completed_date between  '$start_date' and '$end_date'"; 
	  
	
  }else{
	  
	 $date="and submission_date between '$start_date' and '$end_date'";	
	 $completed_date="and submitted_date between  '$start_date' and '$end_date'"; 
	 $completed_date_other="and submission_date between  '$start_date' and '$end_date'"; 
	  
	 
	 
  }	 
  $pep="";  
  if($_POST['pep'] =='all')
  {
	  $pep="";  
	   
	  
  }else{
	  $pep="and pep='".$_POST['pep']."'";  
	 
  }

  $sql="";
  $filter_col="";
  if($_POST['business_class'] =="0" or  $_POST['business_class'] =="1")
  {
    $sql_li="select  distinct iboss_crm_unique_id ,submission_date,inforce_date from iboss_acc_li_policy_info where delete_log='False' $servicing_far  $date";
	
  }	
  
  if($_POST['business_class'] =="0" or  $_POST['business_class'] =="3")
  {
	 $sql_gi="select  distinct iboss_crm_unique_id ,submission_date,inforce_date from iboss_acc_gi_policy_info where delete_log='False' $servicing_farcode  $date";
	 		
  }
  if($_POST['business_class'] =="0" or  $_POST['business_class'] =="6")
  {
	$sql_group="select  distinct iboss_crm_unique_id ,submission_date,inforce_date from iboss_acc_group_policy_info where delete_log='False' $servicing_farcode  $date";
	 		
	
  }

  if($_POST['business_class'] =="0" or  $_POST['business_class'] =="5")
  {
	$sql_others="select  distinct iboss_crm_unique_id ,submission_date,completed_date as inforce_date from iboss_acc_other_services_info where delete_log='False' $servicing_far  $completed_date_other";
	 		
	
  }
  
 if($_POST['business_class'] =="0" or  $_POST['business_class'] =="2")
  {
	$sql_inv="select  distinct (select iboss_crm_unique_id from iboss_acc_inv_account where  id= T1.iboss_acc_inv_account_id ) as iboss_crm_unique_id ,submitted_date as submission_date,'' as inforce_date from iboss_acc_inv_transaction T1 where delete_log='False' $invs_servicing_far  $completed_date";
  }
  
 
	if(!empty($sql_li)){
	$sql_li="UNION ".$sql_li;

	}
	if(!empty($sql_gi)){
	$sql_gi="UNION ".$sql_gi;

	}
	if(!empty($sql_group)){
	$sql_group="UNION ".$sql_group;

	}
	if(!empty($sql_inv)){
	$sql_inv="UNION ".$sql_inv;

	}
	if(!empty($sql_others)){
		$sql_others="UNION ".$sql_others;
    }


    $query =$sql_li .' '. $sql_gi .' '. $sql_group  .' '. $sql_inv  .' '. $sql_others; 
     $query1=ltrim($query,"UNION ");
	
    $master_excel="select *,DATE_FORMAT(max(submission_date), '%d/%m/%Y') as submission from (select * from( $query1 ) a) src,
	(SELECT unique_id,far_name,far_code,identification_no,fin_no,passport_no,saluation,nric_name,pep, nationality_name from iboss_master_crm_report where 1=1 $pep $far_code) dest
	where  dest.unique_id = src.iboss_crm_unique_id group by iboss_crm_unique_id,far_code";
	//print_r($master_excel);
	//die();
	$export = $this->iboss_read->query($master_excel);
	$master_export_value =$export->result();
	
	
	header( "Content-Type: application/vnd.ms-excel" );
	header( "Content-disposition: attachment; filename=".date('d-m-Y')." - Master Crm.xls");
	$handle = fopen('php://output', 'w');


	echo "\t"."\t"."\t"."iBOSS SCRENNING CLIENTS"."\n";
	echo"\r\n";
	echo "FAR Code"."\t"."FAR Name"."\t"."Client NRIC"."\t"."Name (As in NRIC) / Business Name"."\t"."Nationality"."\t"."PEP"."\t"."Submission Date";
	echo"\r\n";
     
  foreach($master_export_value as $row)
   {
	  
		echo $out=$row->far_code."\t".
		$row->far_name."\t".
		$row->identification_no."\t".
		$row->nric_name."\t".
		$row->nationality_name."\t".
		$row->pep."\t".
		$row->submission."\r\n";
		 
	}

	echo"\r\n";
	fclose($handle);
  
 
  }
  
  
  
  
  

  function product_details()
  {
	 
	$far_status = $_POST['far_status'];

	if($_POST['far_status'] =='Active')
	{
			$sql=	"select  concat( iboss_far_code,'-',iboss_preferred_name,'-',iboss_status) as name, iboss_far_code  from iboss_farops_far_info where iboss_status='Active'";

	}
	
	else if($_POST['far_status'] =='Terminated')
	{
			$sql=	"select  concat( iboss_far_code,'-',iboss_preferred_name,'-',iboss_status) as name , iboss_far_code from iboss_farops_far_info where iboss_status='Terminated' ";
	}
	else
	{
		$sql=	"select  concat( iboss_far_code,'-',iboss_preferred_name,'-',iboss_status) as name , iboss_far_code from iboss_farops_far_info ";
		//  $data->farcode_options = array("0" => "All");
	}
  
	$export = $this->iboss_read->query($sql);
	$result=$export->result();
	
	
    $farcode_options = array("" => "All");
	foreach($result as $farstatus)
	
	{
		$farcode_options[$farstatus->iboss_far_code]=$farstatus->name;
	}

	// print_r($farcode_options);
	// die();

	
	
	$attr = 'id="far_name" class="form-control chosen-select business_repo_val  filter_new " ';
	echo	form_dropdown('far_name', $farcode_options, '', $attr);
	


  }
  


	function index( ) {

		$data->templates = array('datatables','datepicker','icheck','chosen','select2');
		$data->iboss_dict_biz_class_id_options =array("0"=>"All");
		$data->iboss_dict_biz_class_id_options += biz_class_index_result('yes');
		//$data->iboss_business_simple_report = array("all" =>"All", "Male"=>"Male", "Female"=>"Female");
		//$data->iboss_business_simple_report = array("all" =>"All", "Personal"=>"INV", "Corp"=>"corp");
	
		// $data->far_id_options = array("" => "All");
        // $far_id = $this->_selector_farcode();
        // foreach ($far_id as $key => $val) {
        //     $data->far_id_options[$key] = $val;
        // }
		
		
		// $iboss_biz_introducer_info_id =  personal_info_index_result();
		//  echo "<pre>";
		// print_r( $iboss_biz_introducer_info_id);
		//  die();
		//$data->farcode_options =array(""=>"All");
		$data->farcode_options[""] ="All";
	   foreach ($iboss_biz_introducer_info_id as $key => $val) {
            $data->farcode_options[$val->iboss_far_code] = $val->iboss_far_code.'-'.$val->iboss_preferred_name.'-'.$val->iboss_status;
        }
		

		$data->nationality_value[""] ="All";
		$nationality_query=$this->db->query("select * from iboss_dict_country")->result();
		//print_r($nationality_query);
		//die();
	   foreach ($nationality_query as $key => $val) {
		 	$data->nationality_value[$val->id] = $val->name;
			//print_r($data); die();
		}
		
		
		
	    // $data->iboss_dict_biz_class_id_options = biz_class_index_result('yes'); 
		
		$this->load->view("template/common_header", $data);
		$this->load->view("iboss_monthly_screnning_clients/iboss_business_simple_report_summary", $data);
		$this->load->view("template/common_footer", $data);
		return;
	}


	
	

	function _set_confirmation( &$data,$line,$uri_segments,$icon,$text,$tooltip,$confirmation="Are you sure?" ){
		$controller = strtok($uri_segments,"/");
		$function = strtok("/");
		if(_test_access($controller,$function)){
			$data->actions_sidebar[$line]['uri_segments'] = $uri_segments;
			$data->actions_sidebar[$line]['icon'] = $icon;
			$data->actions_sidebar[$line]['text'] = $text;
			$attr['class'] = "btn btn-primary";
			$attr['data-rel'] = "tooltip";
			$attr['title'] = $tooltip;
			$data->actions_sidebar[$line]['attr'] = $attr;
			$data->modals[$line]['id'] = $controller."_".$function;
			$data->modals[$line]['header'] = $text." Confirmation";
			$data->modals[$line]['body'] = $confirmation;
			$data->modals[$line]['uri_segments'] = $uri_segments;
		}
		return $data;
	}


	function _nitro_set_rules() {
		$this->Crm_personal_info_model->_nitro_set_rules();
		return;
	}


	function _nitro_send_post_to_view( $post, &$data  ){
		
		
		foreach( $post as $key => $val )
		{
			$data->$key = $val;
		}
		return $data;
	}


	function _nitro_pagination_init($function, $total, $perpage ) {
		$config['base_url'] 	= site_url("iboss_master_crm_info/$function");
		$config['total_rows'] 	= $total;
		$config['per_page'] 	= $perpage;
		$config['num_links'] = 5;
		$config['full_tag_open'] = '<div class="pagination pagination-centered"><ul>';
		$config['full_tag_close'] = '</ul></div>';
		$config['first_link'] = 'First';
		$config['first_tag_open'] = '<li>';
		$config['first_tag_close'] = '</li>';
		$config['next_link'] = '&gt;';
		$config['next_tag_open'] = '<li>';
		$config['next_tag_close'] = '</li>';
		$config['prev_link'] = '&lt;';
		$config['prev_tag_open'] = '<li>';
		$config['prev_tag_close'] = '</li>';
		$config['last_link'] = 'Last';
		$config['last_tag_open'] = '<li>';
		$config['last_tag_close'] = '</li>';
		$config['cur_tag_open'] = '<li class="active"><a href="#">';
		$config['cur_tag_close'] = '</a></li>';
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		$this->pagination->initialize($config);
		return;
	}

	function _selector_options($model,$index,$option,$orderby,$where=null) {
		$this->load->model($model);
		$result = $this->$model->retrieve($where, null, 0, $orderby);
		$selector_options = array();
		foreach($result as $key=>$val) {
			$selector_options[$val->$index] = ucwords(strtolower($val->$option));
		}
		Return $selector_options;
	}

	
	
function _selector_farcode()
	{
	   if($this->session->userdata('consult_selector_options'))
		{
		
		$selector_options = $this->session->userdata('consult_selector_options');
		  
		}
		else
		{
		 $selector_options = selector_consultans();  
		 $this->session->set_userdata('consult_selector_options',$selector_options);
		}
       return $selector_options;
	}
	
	
	
	
 
 
 


}


?>

