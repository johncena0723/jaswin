<link href="<?=base_url();?>css/plugins/chosen/new-chosen.css" rel="stylesheet">
<?php $this->load->view("iboss_group_load_file/iboss_tab_nav");?>
<?php $this->load->view("template/jeditable_index.php");?>

<script>
$(document).ready( function () {
		$(".row_hide").addClass('hidden');
	});	
</script>
<style>
	/*.excel {
    float: right;
	}*/

.loader {
  position: relative;
  display: grid;
  grid-template-columns: 33% 33% 33%;
  grid-gap: 2px;
  width: 50px;
  height: 50px;
}
.loader > div {
  width: 100px;
  height: 100px;
  background: #EE7103;
  -moz-border-radius: 50px;
  -webkit-border-radius: 50px;
  border-radius: 60px;
  position: relative;
  display: inline-block;
  width: 70%;
  height: 70%;  
  transform: scale(0);
  transform-origin: center center;
  animation: loader 0.5s infinite linear;
}
.loader > div:nth-of-type(1), .loader > div:nth-of-type(5), .loader > div:nth-of-type(9) {
  animation-delay: 0.2s;
}
.loader > div:nth-of-type(4), .loader > div:nth-of-type(8) {
  animation-delay: 0.1s;
}
.loader > div:nth-of-type(2), .loader > div:nth-of-type(6) {
  animation-delay: 0.3s;
}
.loader > div:nth-of-type(3) {
  animation-delay: 0.4s;
}

@keyframes loader {
  0% {
    transform: scale(0);
  }
  40% {
    transform: scale(1);
  }
  80% {
    transform: scale(1);
  }
  100% {
    transform: scale(0);
  }
}
.news {
  background-color: #00629B;
}

.loader > div:nth-of-type(9) {
  background-color: #00629B;
}

.loader > div:nth-of-type(6) {
  background-color: #e7eaec00;
}

.loader > div:nth-of-type(8) {
  background-color: #e7eaec00;
}

.panel-default {
    border-color: transparent;
}

.panel {
    
    background-color: transparent;    
}


.capitalize {
    text-transform: capitalize;
}

.uppercase {
    text-transform: uppercase;
}
.share-it{
	position:fixed;
	width:10px;

	right:0;
	z-index:9;
	top:10%;
}	
.share-it i{
	font-size:16px;
}
.facebook{margin:0 auto; float:left; margin-right:4px;height:140px;width:25px;}
.facebook  a{
	color:#fff;
	padding:10px 16px;
	background-color:#527aba;
	display:inline-block;
	transition:0.5s ease;
	width:140px;
	
}
/*.facebook  a:hover{
	color:#fff;
	padding:10px 20px;
	margin-left:-20px;
	background-color:#527aba;
	display:inline-block;
}
*/
.twitter{margin:0 auto; float:left; margin-right:4px;}
.twitter  a{
	color:#fff;
	padding:10px 16px;
	background-color:#77cdf1;
	display:inline-block;
	text-align:center;
	transition:0.5s ease;
	width:140px;
}
/*.twitter  a:hover{
	color:#fff;
	padding:10px 20px;
	margin-left:-20px;
	background-color:#77cdf1;
	display:inline-block;
	text-align:center;

}*/
.vertical-text {
	transform: rotate(90deg);
	transform-origin: left top 0;
	margin-left:24px;
}
.modal-backdrop {
    z-index: 1000 !important;
}
.sidebar-container ul.nav-tabs li.active a {font-weight: 600 !important;
		background-color:#527aba;
	 color:#fff;
	 border:none;
}
.fa-copy{
color:orange;	

}

#mytable_filter [type="search"]{
	
	width: 450px;
}

</style>
<div class="wrapper wrapper-content animated fadeInRight ecommerce">
<!--<div class="share-it">
		<div class="facebook">
          <a data-toggle="tab" href="#tab-1"  class="right-sidebar-toggle1 vertical-text">Filter options</a>
          </div>
        <div class="twitter">
          <a  data-toggle="tab" href="#tab-2" class="right-sidebar-toggle1 vertical-text">Column options</a>
        </div>
		
	  </div>-->

	  <div id="exTab2" class="tabs-container">
						
					
					<ul class="nav nav-pills nav-wizard">
						<?if($this->uri->segment('1') == 'iboss_acc_update_address_info'){ ?>
						<!--<li class="active" ><a  href="<?=site_url('iboss_customer_servicing_report/index')?>"  style="padding:11px 15px;background-color: #f8ac59;"><i class="fa fa-user"></i>Home</a></li>-->
						<li class="<?=($nav_active=="1")?'active':'';?> " ><a href="<?=site_url('iboss_acc_update_address_info/index')?>" style="padding:11px 15px;"><i class="fa fa-user"></i>Home</a></li>

						<li class="<?=($nav_active=="2")?'active':'';?> " ><a href="<?=site_url('iboss_acc_update_address_info/pending_address')?>" style="padding:11px 15px;"><i class="fa fa-user"></i>Pending Address</a></li>
						<?}?>
						<?if($this->uri->segment('1') == 'iboss_acc_update_contact_info'){ ?>
						<!--<li class="active" ><a  href="<?=site_url('iboss_customer_servicing_report/index')?>"  style="padding:11px 15px;background-color: #f8ac59;"><i class="fa fa-user"></i>Home</a></li>-->
						<li class="<?=($nav_active=="1")?'active':'';?> " ><a href="<?=site_url('iboss_acc_update_contact_info/index')?>" style="padding:11px 15px;"><i class="fa fa-user"></i>Home</a></li>

						<li class="<?=($nav_active=="2")?'active':'';?> " ><a href="<?=site_url('iboss_acc_update_contact_info/pending_contact_status')?>" style="padding:11px 15px;"><i class="fa fa-user"></i>Pending Contact</a></li>
						<?}?>

					</ul>

					      <br>
						</div>

	  <div class="ibox float-e-margins close_bar">
	    <div class="ibox-title">
			<h5>Filter</h5>
			
			<?php if($this->uri->segment('1') =='iboss_master_crm_info'){?>
				
                    <a  href="<?=site_url('iboss_master_crm_info/crm_corporate_info')?>" class="btn btn-warning pull-right" style="margin-left:5px;margin-top:-6px" name="filter" type="button">New Corporate Info <i class="fa fa-plus"></i></a> 
	           	    <a  href="<?=site_url('iboss_master_crm_info/crm_personal_info')?>" class="btn btn-primary pull-right" style="margin-left:5px;margin-top:-6px" name="filter" type="button">New Personal Info  <i class="fa fa-plus"></i></a> 
				
				<?}?>
		</div>
		<div class="ibox-content">
			<div class="row">
	            <?=form_open_multipart("iboss_master_crm_info/export_excel_new",array('class'=>"form-horizontal" , 'id'=>'master_export' , "name"=>"master_export"))?>
	            
				<!--<div class="col-lg-12">
            	<div class="col-sm-5">
            		<label><?="Search By Consultant:"?></label>
            			<div class="form-group">
              				<div class="col-sm-12">
                				<? $attr = 'id=iboss_dict_cpd_type_id_new" class="form-control chosen-select iboss_dict_cpd_type_id_new" onchange="master_crm_val(this.value);" ';?>
								<?=form_dropdown('iboss_dict_cpd_type_id', $far_id_options, '', $attr)?>
						
              				</div>  
            			</div>
                </div>

               
                <div class="col-sm-7">
            		<label><?="Search By Client Name/NRIC Number/Passport Number/Fin Number/Client ID:"?></label>
	        			<div class="form-group">
	          				<div class="col-sm-6" >
	            	<?=form_input(array('id'=>"nric_no",  'name'=>"nric_no", 'value'=>'', 'placeholder'=>"Client Name/NRIC Number/Passport Number/Fin Number/Client ID", 'class'=>"form-control filter_new" ,'onchange'=>"reloadtable_search();"))?>

	          				</div>
	          				
								<button class="btn btn-primary" name="submit"  type="button" onclick="reloadtable_search();">Submit</button>
		        				<button class="btn btn-default" name="reset" onclick="return form_clear();" type="button">Clear</button> 
						
		      				
	        			</div>
            			
                </div>
				</div>-->
				<div class="col-lg-12">
            	<div class="col-sm-4 ">
            		<label ><?="Search By Consultant"?></label>
            			<div class="form-group">
              				<div class="col-sm-12 ">
                				<? $attr = 'id=iboss_dict_cpd_type_id_new" class="form-control chosen-select iboss_dict_cpd_type_id_new filter_new"  ';?>
								<?=form_dropdown('iboss_dict_cpd_type_id', $far_id_options, $_GET['iboss_dict_cpd_type_id'], $attr)?>
						
              				</div>  
            			</div>
                </div>


            <div class="col-sm-4">
                		<label><?="Client Name"?></label>
                		<div class="form-group">
	          				<div class="col-sm-12 " >
	            	<?=form_input(array('id'=>"client_name",  'name'=>"client_name", 'value'=>$_GET['client_name'], 'placeholder'=>"Client Name", 'class'=>"form-control filter_new" ))?>

	          				</div>
                	</div>
                </div>

                <div class="col-sm-4">
            		<label><?="NRIC Number"?></label>
                		<div class="form-group">
	          				<div class="col-sm-12 " >
	            	<?=form_input(array('id'=>"nric_no",  'name'=>"nric_no", 'value'=>$_GET['nric_no'], 'placeholder'=>"NRIC Number", 'class'=>"form-control filter_new" ))?>

	          				</div>
                	</div>

					
            	</div>
				
				</div> 
				<br>
			
				<div class="col-lg-12">
					

            		<div class="col-sm-4">
                		<label><?="Passport Number"?></label>
                		<div class="form-group">
	          				<div class="col-sm-12 " >
	            	<?=form_input(array('id'=>"passport_no",  'name'=>"passport_no", 'value'=>$_GET['passport_no'], 'placeholder'=>"PASSPORT NUMBER", 'class'=>"form-control filter_new" ))?>

	          				</div>
                	</div>

					
            	</div>

            	<div class="col-sm-4">
            		<label><?=" FIN Number"?></label>
                		<div class="form-group">
	          				<div class="col-sm-12 " >
	            	<?=form_input(array('id'=>"fin_no",  'name'=>"fin_no", 'value'=>$_GET['fin_no'], 'placeholder'=>"FIN NUMBER", 'class'=>"form-control filter_new"))?>

	          				</div>
                	</div>

					
            	</div>

            	<div class="col-sm-4">
            		<label><?=" Client ID"?></label>
                		<div class="form-group">
	          				<div class="col-sm-12 " >
	            				<?=form_input(array('id'=>"client_id",  'name'=>"client_id", 'value'=>$_GET['client_id'], 'placeholder'=>"CLIENT ID", 'class'=>"form-control filter_new"))?>

	          				</div>
                		</div>

					
            	</div>
				<!-- contact -->
				<div class="col-sm-4">
            		<label><?="Contact"?></label>
                		<div class="form-group">
	          				<div class="col-sm-12 " >
							  <?=form_input(array('id'=>"primary_contact", 'name'=>"primary_contact",'value'=>$primary_contact, 'placeholder'=>'Contact','class'=>"form-control filter_new" ))?>

	          				</div>
                		</div>	
            	</div>
				<!-- contact end -->
				<!-- email -->
				<div class="col-sm-4">
            		<label><?="Email"?></label>
                		<div class="form-group">
	          				<div class="col-sm-12 " >
							  <?=form_input(array('id'=>"primary_email",'name'=>"primary_email",'value'=>$primary_email, 'placeholder'=>'Email','class'=>"form-control filter_new"))?>
	          				</div>
                		</div>	
            	</div>


				<!-- emailend -->
												
											  

				



				</div>
				
				
				
				<div class="">
				<br>	
					<div class="col-sm-4">
					<br>
					<div class="col-sm-4" style="text-align: left;" >
					<!--<button class='btn btn-info excel' type='button' onclick="export_excel()">Export</button>-->
							<button class='btn btn-info excel' type='button' onclick="export_excel_new()">Export</button>
						</div>
					</div>
					<div class="col-sm-4"></div>
				 <div class="col-sm-4" style="text-align: right;" >							
				 <br>
							<button class="btn btn-primary"   type="button" onclick="master_crm_val();">Submit</button>
							<button class="btn btn-default" name="reset" onclick="return form_clear();" type="button">Clear</button> 
						</div>
					
				</div>
			 
				                   
					
	            <?=form_close()?>
			</div>
				
					
				
		</div>

    
	<div class="row row_hide hidden">
		<div class="col-lg-12">
			<div class="ibox float-e-margins">
										
			   </div>
				
				
				<div class="ibox-content">
					<div class="">
					<table class="table table-striped  table-hover" id="mytable" >
						<!--<a class="btn btn-info excel hide" value = '' onclick="export_excel()">Export</a>-->
						<thead>
						<tr>
							<!--<th data-field="" ><?="Client Id"?></th>-->
							<th data-field=""><?="FAR Code"?></th>
							<th data-field=""><?="FAR Name"?></th>
							<th data-field=""><?="FAR Status"?></th>
							<th data-field=""><?="Contact"?></th>
							<th data-field=""><?="Email"?></th>

							<th data-field="">NRIC Number / Passport No / FIN No</th>
							<!-- <th data-field="">Passport No</th> -->
							<!-- <th data-field="">FIN No</th> -->
							<th data-field="">NRIC Name / Business Name</th>
							<th>Actions</th>
							<!--<th>passport no</th>
							<th>Fin no</th>-->
							
						</tr>
						</thead>
						
					</table>
					</div>
				</div>
				
				
			</div>
		</div>
		
		
		
	<br>	
	<br>	
	<br>	
	<br>	
	<br>	
	<br>	
		<br>	
	</div>
</div>
<br>	

<div id="table_individual_div" style="display:none;">
	<table id="table_individual" style="border:1px solid;" border="1" cellpadding="0" cellspacing="0">
		<thead>
			<tr>
				<td>Client Id</td>
				<td>FAR Code</td>
				<td>FAR Name</td>
				<td>NRIC Number / Biz Registration No</td>
				<td>Passport No</td>
				<td>Fin No</td>
				<td>NRIC Name / Business Name</td>
			</tr>
		</thead>
		<tbody id="table_individual_tbody"></tbody>
	</table>
</div>
	
<script src="<?=base_url()?>js/plugins/dataTables/jquery.datatables.min.js"></script>
<link href="<?=base_url()?>css/plugins/dataTables/datatables.min.css" rel="stylesheet">
<script src="<?=base_url()?>js/plugins/dataTables/datatables.min.js"></script>


<script>

function export_excel_new(){

	$('#loading_gif').modal('show');
	$("#master_export")[0].submit();
	$('#loading_gif').modal('hide');

}

/*$('#master_export').on('keypress', function(e) {
    return e.which !== 13;
});*/


	$(document).keypress(function(event){
    var keycode = (event.keyCode ? event.keyCode : event.which);

    if(keycode == '13'){
    	//$('.excel').addClass('hide');
        master_crm_val();
        
       // to_store_into_get();
    }
	});


	 $('.filter_new').keypress( function(e){
		 var filter = $('.filter_new').val();
     if (e.which == 13  && filter != '')   { 
     	$('.test').click();
     	//master_crm_val();
      } //else {
		 
		 // $(".row_hide").addClass('hidden');
		// }
   
   	});

	 $('.reset').click( function () {
	 	$('.filter').val('');
	 	$(".row_hide").addClass('hidden');
		$('.test').click();
	});
	
	

$('.forfilter,.close_bar').click(function () {$('#right-sidebar').removeClass('sidebar-open'); $('.forfilter').addClass('hide');

	
});

 $('.right-sidebar-toggle1').click(function () {

 //alert($(this).attr('href'));
 $('[data-toggle="tab"]').parent().removeClass('active');
  $('[href="'+$(this).attr('href')+'"]').parent().addClass('active');
 
        //$('#right-sidebar').toggleClass('sidebar-open');
		if($('#right-sidebar').attr('class')=='sidebar-open')
		{
		if($(''+$(this).attr('href')).hasClass('active'))
		{
		$('#right-sidebar').removeClass('sidebar-open');
		 $('.forfilter').addClass('hide');
		}
		}
		else
		{
			
		$('#right-sidebar').addClass('sidebar-open');
			 $('.forfilter').removeClass('hide');
		}
		
    });
	
	function to_store_to_get()
{
	var all_date = $('.filter_new').serialize();
	localStorage.setItem('index_parameter_MASTER',"<?=base_url()?>index.php/iboss_master_crm_info/index?"+all_date);
}	

$(document).ready(function(){
		// Setup datatables
	$.fn.dataTableExt.oApi.fnPagingInfo = function(oSettings)
      {
          return {
              "iStart": oSettings._iDisplayStart,
              "iEnd": oSettings.fnDisplayEnd(),
              "iLength": oSettings._iDisplayLength,
              "iTotal": oSettings.fnRecordsTotal(),
              "iFilteredTotal": oSettings.fnRecordsDisplay(),
              "iPage": Math.ceil(oSettings._iDisplayStart / oSettings._iDisplayLength),
              "iTotalPages": Math.ceil(oSettings.fnRecordsDisplay() / oSettings._iDisplayLength)
          };
      };
	
		
	
		
	
     /* var table = $("#mytable").dataTable({
          initComplete: function() {
              var api = this.api();
              $('#mytable_filter input,.filter')
                  .off('.DT')
                  .on('input.DT', function() {
                      api.search(this.value).draw();
              });
          },
              oLanguage: {
              sProcessing: "loading..."
          },
              processing: true,
              serverSide: true,
              ajax: {"url": "<?php echo base_url().'index.php/iboss_master_crm_info/get_product_json/'?>", "type": "POST"},
                	columns: [
						{"data": "unique_id"},
						{"data": "far_code"},
						{"data": "identification_no"},
						{"data": "nric_name"},
						{"data": "Actions"}						
				
                  ],
          		//order: [[1, 'asc']],
               rowCallback: function(row, data, iDisplayIndex) {
              var info = this.fnPagingInfo();
              var page = info.iPage;
              var length = info.iLength;
              $('td:eq(0)', row).html();
          }
      });*/
	
	 // master_crm_val()
			
	});
	
	$(document).ready( function () {
		$("#mytable_filter").addClass('hidden');
		var check_link = localStorage.getItem('index_parameter_MASTER');

			<?php if(!empty($_GET)):?>

		
		if(check_link!=undefined)
		{
			localStorage.removeItem('index_parameter_MASTER');

			master_crm_val();
		}

			<?php endif;?>
	});	

	$(document).ready(function() {
$.fn.dataTable.ext.errMode = 'none';
 
$('#mytable')
    .on( 'error.dt', function ( e, settings, techNote, message ) {
        //console.log( 'An error has been reported by DataTables: ', message );
    				var type="Please check the data or contact IT Dept!!!";
    					$(".row_hide").addClass('hidden');
                 	$('#warning_alert_message_index').modal('show');
                 	$('.para').text(type);
    	

    } )
    .DataTable();
});
	
function master_crm_val()
{
	//$('.excel').addClass('hide');
	to_store_to_get();
	var far_code=$(".iboss_dict_cpd_type_id_new").val();
	var nric_no=$("#nric_no").val();
	var client_name = $('#client_name').val();
	var fin_no = $('#fin_no').val();
	var client_id = $('#client_id').val();
	var passport = $('#passport_no').val();



	/* if( far_code == '' &&  nric_no == '' && client_name == '' && fin_no == '' && client_id == '' && passport == ''){
		$('#loading_gif').modal('hide');
		//$(".row_hide").removeClass('hidden');	
		$(".row_hide").addClass('hidden');
		notify('warning','Select the values !');
		return false;
	} */

	// if( far_code != '' ||  nric_no != '' || client_name != '' || fin_no != '' || client_id != '' || passport != ''){
	// 	$('.excel').removeAttr('disabled')
	// }

	$(".row_hide").removeClass('hidden');
	$('#mytable').DataTable().clear();
	//$('#mytable').DataTable().clear();
//$('#mytable').DataTable().destroy();
//	console.log(far);
	if(far_code )
	{
		far = far_code;
		//$('.excel').removeClass('hide');
		//$('.excel').val(far);
	}else {
		far = '';
	}
	
	/*$(' #right-sidebar a i').addClass('fa-check-square').removeClass('fa-square-o');$('#right-sidebar  span').addClass('m-l-xs').removeClass('todo-completed');*/
	
	var dtable = $("#mytable").DataTable({
		
          initComplete: function() {
             var api = this.api();
              $('#mytable_filter input,.filter')
                  .off('.DT')
                  .on('input.DT', function() {
                      api.search(this.value).draw();
              });
          },
              language: {
		              processing: "<div class='loader'><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>"
		          },
		  destroy: true,
              processing: true,
              serverSide: true,
              ajax: {"url": "<?php echo base_url().'index.php/iboss_master_crm_info/get_product_json/'?>"+far, "type": "POST",
              error: function (xhr, error, code)
            	{
            	   	var type="Please check the data or contact IT Dept!!";
    				$(".row_hide").addClass('hidden');
                 	$('#warning_alert_message_index').modal('show');
                 	$('.para').text(type);

            	  var headers = xhr.getAllResponseHeaders();
   				  var arr = headers.trim().split(/[\r\n]+/);
   				  var headerMap = {};
    			 arr.forEach(function (line) {
      				var parts = line.split(': ');
      				var header = parts.shift();
      				var value = parts.join(': ');
     			    headerMap[header] = value;
    				});

    				if(headerMap['status']=='500'){
    				var type="Please check the data or contact IT Dept!!";
    				$(".row_hide").addClass('hidden');
                 	$('#warning_alert_message_index').modal('show');
                 	$('.para').text(type);
    				}

    			if(headerMap['status']=='404'){
    				var type="Permission denied!!!";
    				$(".row_hide").addClass('hidden');
                 	$('#warning_alert_message_2').modal('show');
                 	$('.para').text(type);
    			}
            },
			  
			  "data": function(d) {
					   var frm_data = $('.filter_new').serializeArray();
					   $.each(frm_data, function(key, val) {
						 d[val.name] = val.value;						 
					   });					   
					 },
					 
			  },
			  /*dom: 'Blfrtip',
       		 buttons: [
   				{
        			extend: 'excel',
        			className: 'btn-info',
        			exportOptions: {
            		columns: 'th:not(:last-child)'
        		}
    		}],*/
              deferRender: true,
                	columns: [
						//{"data": "unique_id"},//0
						{"data": "far_code"},//1
						{"data": "iboss_preferred_name"},//2
						{"data": "iboss_status"},//2
						{"data": "contact" },//3
						{"data": "email"},//2
						{"data": "identification_no" },
						
						//{"data": "passport_no"},
						//{"data": "fin_no"},
						{"data": "nric_name"},//4
						<?php if($this->uri->segment('1') =='iboss_acc_update_address_info'){?>
						{"data": "Update_Address"},						
						<? } else if($this->uri->segment('1') =='iboss_acc_update_contact_info'){?>
						{"data": "Update_Contact"},						
						<?} else {?>
						{"data": "Actions"}	//5				
						<?}?>
						//{"data": "passport_no"},//6
						//{"data": "fin_no"}//7

                  ], "columnDefs":[ { "orderable":false , "targets":5}],
                /*  "columnDefs": [
									{ "orderable": false, "targets": 5 },
									{ "visible": false,  "targets": [ 6,7 ] },
									{render: function ( data, type, row ) {	 
		            	                                         if(row['identification_no']=='')
		            	                                         {
		            	                                         	
		            	                                         	if(row['passport_no']!='')
		            	                                         	{
		            	                                         		data = row['passport_no'];
		            	                                         	}
		            	                                         	else
		            	                                         	{
		            	                                         		data = row['fin_no'];
		            	                                         	}
		            	                                         }
						                                         else 
						                                         {
						                                         	
						                                         	data = row['identification_no'];
						                                         	
						                                          }
						                                        	
												//alert(data);
											return data;},targets: 3},
								  ],*/
          		//order: [[0, 'desc']],
               rowCallback: function(row, data, iDisplayIndex) {
              var info = this.fnPagingInfo();
              var page = info.iPage;
              var length = info.iLength;
              $('td:eq(0)', row).html();
          }
      });
	  
	  
	$("#mytable_filter").addClass('hidden'); 


	$('.buttons-excel').removeClass('btn-default');


$('a.toggle-vis').on( 'click', function (e) {
        e.preventDefault();
 
        // Get the column API object

        var column = dtable.column( $(this).attr('data-column') );
 
        // Toggle the visibility
        column.visible( ! column.visible() );
       // column.searchable();
    } );

$('.test').on('click', function() {
  //clear global search values
  dtable.search('');
  dtable.column($(this).data('columnIndex')).search(this.value).draw();
});	

$('.reloadtable_search').on('keyup', function() {
  //clear global search values
  //dtable.search('');
  dtable.columns([3, 4]).search(this.value).draw();
});	

	
}
	/******************************* Excel Export *****************/
	function export_excel(){

	var far_code=$(".iboss_dict_cpd_type_id_new").val();
	var nric_no=$("#nric_no").val();
	var client_name = $('#client_name').val();
	var fin_no = $('#fin_no').val();
	//var client_id = $('#client_id').val();
	var passport = $('#passport_no').val();
	$('#loading_gif').modal('show');
	
	if($.trim(far_code) == '' &&  $.trim(nric_no) == '' && $.trim(client_name) == '' && $.trim(fin_no) == '' && $.trim(passport) == ''){
		$('#loading_gif').modal('hide');
		notify('warning','Select the values !');
		return false;
	}


		
		$('#table_individual_tbody').empty();
		$.ajax({
		url: "<?php echo base_url().'index.php/iboss_master_crm_info/export_excel/'?>",
		type: "POST",
		data:$('.filter_new').serialize(),
		dataType : "json",
		success:function( data){
		 		
		 		let table_data = "";

		 		for(let count=0, result_length=data.length; count < result_length; count++) {
		 		table_data += "<tr>";
		 			table_data += "<td>"+data[count]['unique_id']+"</td>";
		 			table_data += "<td>"+data[count]['far_code']+"</td>";
		 			table_data += "<td>"+data[count]['iboss_preferred_name']+"</td>";
		 			table_data += "<td>"+data[count]['identification_no']+"</td>";
		 			table_data += "<td>"+data[count]['passport_no']+"</td>";
		 			table_data += "<td>"+data[count]['fin_no']+"</td>";
		 			table_data += "<td>"+data[count]['nric_name']+"</td>";
				table_data += "</tr>";
		 		}
		 		
		 		$('#table_individual_tbody').append(table_data);

		 		$('#loading_gif').modal('hide');
		 		
		 			platform_export( 'Master_Crm' ,'xls');
		 		
		 }, error: function() {
			$('#loading_gif').modal('hide');
            $('#warning_alert_message_2').modal('show');
		 }	
	});

	}

	

	function platform_export(name, type, fn, dl) {
		var elt = document.getElementById('table_individual');
		var wb = XLSX.utils.table_to_book(elt, {sheet:"Sheet JS"});
		return dl ?
		XLSX.write(wb, {bookType:type, bookSST:true, type: 'base64'}) :
		XLSX.writeFile(wb, fn || ( name+'.' + (type || 'xls')));
	}

	/******************************* Excel Export *****************/

/*function reloadtable_search()
	{
		$('#loading_gif').modal('show');
		var far_code=$(".iboss_dict_cpd_type_id_new").val();
		var nric_no=$("#nric_no").val();
		
		if(far_code =='' && nric_no=='' )
		{  
	       $('#loading_gif').modal('hide');
		   $(".row_hide").addClass('hidden');
			notify('warning','Select the values !');
			return false;
		}
		
		else {
		$('#loading_gif').modal('hide');
			if( nric_no != '' && far_code != '') {
				master_crm_val(far_code);	
			} else {
				master_crm_val(far_code);	
			}
			
			if( far_code=='' && nric_no!=''){
				master_crm_val();	
			}
		}
	//dtable.columns([1, 2]).search(''+val).draw()
	//alert(val);
	}*/
	
</script>



	          <script>
				function redirect_page(val)
				{
					//alert(val);
				var far_code=$(".iboss_dict_cpd_type_id_new").val();
					//alert(far_code);
				if(val=="personal"){
					//alert(val);
				 window.location.href="<?=base_url()?>index.php/iboss_master_crm_info/insert_personal_data/"+far_code;
				}else{
				 window.location.href="<?=base_url()?>index.php/iboss_master_crm_info/insert_corporate_data/"+far_code;	
					
				}
					
				}
				
				</script>
<script type="text/javascript">
  function view_client(unique_id,id)
  {
    $('#client_view').html('');
    $.ajax({
              type: "POST",
              url: "<?php echo base_url()?>index.php/iboss_master_crm_info/view_client/"+unique_id+"/"+id,
              
              success: function(data)
              {
               // alert(data);
                  $('#client_view').html(data);
                  $('#myModal_client_view').modal('show');
              }
          });
  }
  
  function form_clear()
  {
	$(".row_hide").addClass('hidden');
	$('.filter_new').val('');
	//$('.excel').attr('disabled' , 'disabled');
	$('.chosen-select option:selected').removeAttr('selected');
	$('.chosen-select').trigger("chosen:updated");
	//var check_link = localStorage.getItem('index_parameter_MASTER');
	
	//window.location.href="<?=base_url()?>index.php/iboss_master_crm_info/index";
  }
  
  
  function add_investment(unique_id)
{
  $.ajax({
            type:"POST",
            url:"<?php echo base_url()?>index.php/iboss_master_crm_info/show_investment_details/"+unique_id,
            success:function(data){

           //  alert(data);

              if($.trim(data)!='')
              {
                //alert('have');
                //window.location.href = "<?=site_url('iboss_acc_inv_info/add_edit_policy')?>/"+unique_id+"/"+data;
				window.open("<?=site_url('iboss_acc_inv_info/add_edit_policy')?>/"+unique_id+"/"+data);
              }
              else
              {
                //alert('not');
                //window.location.href = "<?=site_url('iboss_acc_inv_info/add_edit_policy')?>/"+unique_id+"/<?="new"?>";
				window.open("<?=site_url('iboss_acc_inv_info/add_edit_policy')?>/"+unique_id+"/<?="new"?>");
              }

            }
        });
} 



function farops_license_check(far_code,ctype,unique_id)
  {
$('#loading_gif').modal('show');
    $.ajax({
              type: "POST",
              url: "<?php echo base_url()?>index.php/iboss_master_crm_info/farops_license_check/"+far_code+"/"+ctype,
              
              success: function(data)
              {
                if(data !='')
				{
					if(ctype =='LI')
					{
				      //window.location.href = "<?=site_url('iboss_acc_li_policy_info/add_edit_policy')?>/"+unique_id+"/<?="new"?>";	
					  window.open("<?=site_url('iboss_acc_li_policy_info/add_edit_policy')?>/"+unique_id+"/<?="new"?>");
				    }
					if(ctype =='GI')
					{
					//window.location.href = "<?=site_url('iboss_acc_gi_policy_info/add_edit_policy')?>/"+unique_id+"/<?="new"?>";		
					window.open("<?=site_url('iboss_acc_gi_policy_info/add_edit_policy')?>/"+unique_id+"/<?="new"?>");
					}
					if(ctype =='GROUP')
					{
				      //window.location.href = "<?=site_url('iboss_acc_group_policy_info/add_edit_policy')?>/"+unique_id+"/<?="new"?>";	
					  window.open("<?=site_url('iboss_acc_group_policy_info/add_edit_policy')?>/"+unique_id+"/<?="new"?>");
				    }
					if(ctype =='OTHER')
					{
				      //window.location.href = "<?=site_url('iboss_acc_other_services_info/add_edit_policy')?>/"+unique_id+"/<?="new"?>";	
					  window.open("<?=site_url('iboss_acc_other_services_info/add_edit_policy')?>/"+unique_id+"/<?="new"?>");
				    }					
					
					if(ctype =='INV')
					{
                        add_investment(unique_id);
						
				    }
					
				 $('#loading_gif').modal('hide');
				 
				}else{
					
					   $('#loading_gif').modal('hide');
					
					    $('#auth_modal_form').modal('show');	
					 
                         $("#lic_check_unique_id").val(unique_id);
						 $("#lic_check_far_code").val(far_code);
						 $("#lic_check_ctype").text(ctype);
					
					//notify('warning','Auth Not Availble');
				}

              }
          });
  }

  
  
 function redirect_lic()
 {
	 var unique_id=$("#lic_check_unique_id").val();
	 var far_code=$("#lic_check_far_code").val();
	 var ctype=$("#lic_check_ctype").text();
	 
	switch (ctype) {
               case 'LI': var type = 'iboss_acc_li_policy_info';
               break;
            
               case 'GI': var type = 'iboss_acc_gi_policy_info';
               break;
            
               case 'GROUP': var type = 'iboss_acc_group_policy_info';
               break;
            
               case 'INV': var type = 'iboss_acc_inv_info';
               break;
            
               default:  var type = '';
            }
			
			if($.trim(type)!='')
			{
			$('#auth_modal_form').modal('hide');	
			window.open("<?=base_url()?>index.php/"+type+"/add_edit_policy/"+unique_id+"/new");	
			//window.location.href = "<?=base_url()?>/index.php/"+type+"/add_edit_policy/"+unique_id+"/new";		
			}
			else
			{
			location.reload();	
			}
			
	 
 }
 
 
 function Update_Address_Log(unique_id)
 { 
	
	$('#update_address_log_popup').modal('show');
	
	$('#update_address_log_table').DataTable().clear().draw();
	
	var dtable = $('#update_address_log_table').DataTable({
              language: {
		              processing: "<div class='loader'><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>"
		          },
				destroy: true, 
				processing: true,								
              	serverSide: true,				
				pageLength: 10,
				//bDeferRender: true,
				//bAutoWidth: false,
				//scrollY: "400px",
				//scrollX: "2000px",
				ajax: {
				         url: "<?=base_url()?>index.php/iboss_acc_update_address_info/update_address_log/"+unique_id,
				          type:"POST",
			
		},
		
		columns: [
						{"data": "unique_id"},
						{"data": "biz_class"},
						{"data": "iboss_acc_policy_id"},
						{"data": "address_type"},						
						{"data": "change_mode"},
						{"data": "page_name"},
						{"data": "old_value"},						
						{"data": "new_value"},
						{"data": "username"},
						{"data": "action_name"},
						{"data": "current_date_time"}
						
						
		]

});

	 
 }
 
 
 
 function Update_Contact_Log(unique_id)
 { 
	
	$('#update_contact_log_popup').modal('show');
	
	$('#update_contact_log_table').DataTable().clear().draw();
	
	var dtable = $('#update_contact_log_table').DataTable({
              language: {
		              processing: "<div class='loader'><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>"
		          },
				destroy: true, 
				processing: true,								
              	serverSide: true,				
				pageLength: 10,
				//bDeferRender: true,
				//bAutoWidth: false,
				//scrollY: "400px",
				//scrollX: "2000px",
				ajax: {
				         url: "<?=base_url()?>index.php/iboss_acc_update_contact_info/update_contact_log/"+unique_id,
				          type:"POST",
			
		},
		
		columns: [
						{"data": "unique_id"},
						{"data": "biz_class"},
						{"data": "iboss_acc_policy_id"},						
						{"data": "change_mode"},
						{"data": "page_name"},
						{"data": "old_value"},						
						{"data": "new_value"},
						{"data": "username"},
						{"data": "action_name"},
						{"data": "current_date_time"}
						
						
		]

});

	 
 }
  
  


  
  
  
</script>

<!-- update address log -->

<div class="modal inmodal fade in" id="update_address_log_popup" tabindex="-1" role="dialog" aria-labelledby="" aria-hidden="true" data-backdrop="static" data-keyboard="false">
                                <div class="modal-dialog modal-lg" style="width:70%;">
                                    <div class="modal-content">
                                         <div class="modal-header" style="padding: 15px 15px;text-align:left;">
										 <label style="color: #1bb394;">Update Address Log</label>
                                            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>
                                       
                                        </div>
                                        <div class="modal-body">
										<div class="table-responsive" style="max-height:600px">

										<table class="table table-striped  table-hover" id="update_address_log_table" style="width:100%;">
										<thead>
										<tr>																
										<th>Unique ID</th>
										<th>Biz Class</th>
										<th>Policy ID /  Account ID</th>
										<th>Address Type</th>
										<th>Change Mode</th>
										<th>Table Name</th>						
										<th>Old Value</th>												
										<th>New Value</th>						
										<th>Username</th>						
										<th>Action Name</th>							
										<th>Current Date Time</th>
										</tr>



										</thead>


										</table>



										</div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-white" data-dismiss="modal">Close</button>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
  
  <!-- end -->
  
  
  
  <!-- update contact log -->

<div class="modal inmodal fade in" id="update_contact_log_popup" tabindex="-1" role="dialog" aria-labelledby="" aria-hidden="true" data-backdrop="static" data-keyboard="false">
                                <div class="modal-dialog modal-lg" style="width:70%;">
                                    <div class="modal-content">
                                         <div class="modal-header" style="padding: 15px 15px;text-align:left;">
										 <label style="color: #1bb394;">Update Contact Log</label>
                                            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>
                                       
                                        </div>
                                        <div class="modal-body">
										<div class="table-responsive" style="max-height:600px">

										<table class="table table-striped  table-hover" id="update_contact_log_table" style="width:100%;">
										<thead>
										<tr>																
										<th>Unique ID</th>
										<th>Biz Class</th>
										<th>Policy ID /  Account ID</th>										
										<th>Change Mode</th>
										<th>Table Name</th>						
										<th>Old Value</th>												
										<th>New Value</th>						
										<th>Username</th>						
										<th>Action Name</th>							
										<th>Current Date Time</th>
										</tr>



										</thead>


										</table>



										</div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-white" data-dismiss="modal">Close</button>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
  
  <!-- end -->




  <div class="modal inmodal fade in" id="master_crm_index_delete_pop" tabindex="-1" role="dialog" aria-labelledby="" aria-hidden="true" data-backdrop="static" data-keyboard="false">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                         <div class="modal-header" style="padding: 15px 15px;text-align:left;">
										 <label style="color: #1bb394;">New Iboss Alert </label>
                                            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>
                                       
                                        </div>
                                        <div class="modal-body">
                                            <label class="control-label"> <b>This client already have some accounts! Once you delete those accounts</b></label>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-white" data-dismiss="modal">Close</button>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>




           <div class="modal inmodal fade" id="auth_modal_form" tabindex="-1" role="dialog" aria-labelledby="" aria-hidden="true" data-backdrop="static" data-keyboard="false">
							  <div class="modal-dialog">
								<div class="modal-content">
								  <div class="modal-header" style="padding: 15px 15px;text-align:left;">
									<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
									<label style="color: #1bb394;"><b id="lic_check_ctype"> Business Class </b> </label>
								  </div>
								  <div class="modal-body">
								  <label class="control-label">Don't have authorized to sell this Business Class? Do you want to create policy ?</label>
								  </div>
								  <div class="modal-footer">
								         <input type="hidden" name="lic_check_far_code" id="lic_check_far_code">
										 <input type="hidden" name="lic_check_unique_id" id="lic_check_unique_id">
									<button  name="ll" Onclick="redirect_lic()"  type="button" class="btn btn-primary">Yes</button>
									<button type="button" class="btn btn-default" data-dismiss="modal">No</button>        
								  </div>
								</div>
							  </div>
							</div>




<div class="modal fade" id="myModal_client_view" tabindex="-1" role="dialog" aria-labelledby="" aria-hidden="true">

  <div id="client_view" >
    
    
  </div>  
</div>


						<div class="modal fade" id="loading_gif" role="dialog" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog" style="margin: 14% 45%;">
    
      <!-- Modal content-->
     <span style="color: white;" class="waitclass"><i class="fa fa-spinner fa-spin fa-4x fa-fw"></i></span>
      
    </div>
  </div> 