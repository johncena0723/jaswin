<?php
/**
* iboss_master_crm_info
*
* 21/04/2016
*/
//error_reporting(E_ALL);


class Iboss_master_crm_info extends CI_Controller
{

	 function Iboss_master_crm_info(){
		parent::__construct();
        date_default_timezone_set('Asia/Singapore');
        $current_date=date('Y-m-d H:i:s');
		//page limits for the index views are to be adjusted depending on views, requirements and on a per controller basis.
		$this->page_limit = null; //adjust this as required.

		$this->load->database();
		//$this->load->model("Iboss_master_crm_info_model");

		// each controller is responsible for loading its own helpers/libraries
		$this->load->model("Crm_personal_info_model");
		$this->load->model("Crm_corporate_info_model");
		$this->load->model("Crm_contact_info_model");
		$this->load->model("Crm_compliance_info_model");
		$this->load->model("Crm_address_info_model");
		$this->load->model("Crm_markerting_info_model");
		$this->load->model("Iboss_crm_edu_and_emp_info_model");
		$this->load->model("Iboss_view_model");
		
		$this->page_limit = null;
		$this->load->library("pagination");
		$this->load->library("form_validation");
		$this->load->helper("form");
		$this->load->helper("url");
		$this->load->helper("date");
		$this->load->helper("copy_paste_crm_info");
		$this->load->helper("farops_api");
		$this->load->library('datatables'); 
		
		
		
		
		$this->load->model("Iboss_acc_inv_info_model");
		$this->load->model("Iboss_acc_inv_far_details_model");
		$this->load->model("Iboss_acc_inv_client_info_model"); 		
		$this->load->model("Iboss_dict_investment_type_model");
		$this->load->model("Iboss_acc_master_crm_info_model");

		$this->load->model("Iboss_doc_mgt_info_model");
		
		$this->load->helper("call_auth");

		$this->ums_fa_biz_class_info_id = explode(",", $this->session->userdata('ums_fa_biz_class_info_id'));
        //$this->output->enable_profiler();
		
		
		$this->iboss_read = $this->load->database('iBOSS_read', TRUE);
		
		

	}
	
	
	
	
	function previous_client_name_data()
	{
		 date_default_timezone_set('Asia/Singapore');
		 $current_date_time=date('Y-m-d H:i:s');
		
		if($_POST['save_type']=='add_personal_previous_client_name')
				  {
					
								
								
								if(!empty($_POST['row_id']))
								{	

									$sql_previous="select id, previous_client_name, change_date from iboss_crm_previous_client_name where delete_log='False' AND id ='".$_POST['row_id']."'";
									$result = $this->db->query($sql_previous);
									$res = $result->result();
									// $res = $this->Iboss_acc_group_policy_transfer_model->retrieve(['id'=>$_POST['row_id'],'delete_log'=>"False"]);
									$index =json_encode($res);
									$str = trim($index,']');
									echo trim($str,'[');
									
								}
								else{
								
								
							  if($_POST['id']=='')
							  {
								$_insert['previous_client_name'] = $_POST['previous_client_name'];
								$_insert['change_date'] = sg2iso($_POST['previous_client_name_change_date']);
								$_insert['username'] = $this->session->userdata('name');
								$_insert['date_time'] = $current_date_time;
								$_insert['unique_id'] = $_POST['unique_id'];

								$this->db->insert('iboss_crm_previous_client_name', $_insert);
					
								echo 'insert';
								  
							  }else{
								  
								$_update['previous_client_name'] = $_POST['previous_client_name'];
								$_update['change_date'] = sg2iso($_POST['previous_client_name_change_date']);
								$_update['username'] = $this->session->userdata('name');
								$_update['date_time'] = $current_date_time;
								$_update['unique_id'] = $_POST['unique_id'];
								
								$this->db->where('id', $_POST['id']);
								$this->db->update('iboss_crm_previous_client_name', $_update);
								  
								echo 'update';  
							  }
								}
								  
					  
					 
					  
				  }
				  
				  
				  if($_POST['delete_type']=='add_personal_previous_client_name')
				  {
					 $_update['delete_log'] = 'True';
					 
					 $this->db->where('id', $_POST['id']);
					 $this->db->update('iboss_crm_previous_client_name', $_update); 
					 
				  }
				  
				  
	}
	
	
	function change_consultant_name()
	{
		
		$id = $_POST['unique_id'];
		$change_consultant_name = $_POST['change_consultant_name'];
		$client_name = $_POST['client_name'];
		$client_type = $_POST['client_type'];
		
		
		$sql1="select iboss_crm_unique_id from iboss_acc_li_client_info where delete_log='False' AND iboss_crm_unique_id = '".$id."' LIMIT 1";
		$result1 = $this->db->query($sql1);
		$results1 = $result1->result();
		if(!empty($results1))
		{
		echo "Success"; 
		die;
		}
		else
		{
			//echo "gi";
			$sql2="select iboss_crm_unique_id from iboss_acc_gi_client_info where delete_log='False' AND iboss_crm_unique_id = '".$id."' LIMIT 1";
			$result2 = $this->db->query($sql2);
			$results2 = $result2->result();			
			if(!empty($results2))
			{
			echo "Success"; 
			die;
			}
				else
				{
					//echo "group";				
					$sql3="select iboss_crm_unique_id from iboss_acc_group_client_info where delete_log='False' AND iboss_crm_unique_id = '".$id."' LIMIT 1";
					$result3 = $this->db->query($sql3);
					$results3 = $result3->result();				
					if(!empty($results3))
					{
					echo "Success"; 
					die;
					}
					else
					{
						//echo "INV";				
						$sql4="select iboss_crm_unique_id from iboss_acc_inv_client_info where delete_log='False' AND iboss_crm_unique_id = '".$id."' LIMIT 1";
						$result4 = $this->db->query($sql4);
						$results4 = $result4->result();				
						if(!empty($results4))
						{
						echo "Success"; 
						die;
						}
						else
						{
							//echo "OTHER";				
							$sql5="select iboss_crm_unique_id from iboss_acc_other_services_client_info where delete_log='False' AND iboss_crm_unique_id = '".$id."' LIMIT 1";
							$result5 = $this->db->query($sql5);
							$results5 = $result5->result();				
							if(!empty($results5))
							{
							echo "Success"; 
							die;
							}
							else
							{
							//echo "document_mgt";	
								$sql6="select iboss_unique_id from iboss_doc_mgt_info where delete_log='False' AND iboss_unique_id = '".$id."' LIMIT 1";
								$result6 = $this->db->query($sql6);
								$results6 = $result6->result();				
								if(!empty($results6))
								{
								echo "Success"; 
								die;
								}
								else
								{
									//echo "else";
									$sql7="select unique_id from iboss_master_crm_index where nric_name='".$client_name."' AND far_code = '".$change_consultant_name."' LIMIT 1";
									$result7 = $this->db->query($sql7);
									$results7 = $result7->result();
									if(!empty($results7))
									{
									echo "Client Have"; 
									die;
									}
									else
									{
										if($client_type=='Corporate')
										{
											$_update['far_code'] = $change_consultant_name;
											
											$this->db->where('unique_id', $id);
											$this->db->update('iboss_crm_corporate_info', $_update);
											
											$this->db->where('unique_id', $id);
											$this->db->update('iboss_master_crm_index', $_update);
											echo "Client Dont Have";
										}

										if($client_type=='Personal')
										{
											$_update['far_code'] = $change_consultant_name;
											
											$this->db->where('unique_id', $id);
											$this->db->update('iboss_crm_personal_info', $_update);
											
											$this->db->where('unique_id', $id);
											$this->db->update('iboss_master_crm_index', $_update);
											echo "Client Dont Have";
										}		
									}
								//$affected_rows = $this->Crm_personal_info_model->delete( $id );
								//$affected_rows = $this->iboss_master_crm_index_delete( $id );
								//redirect( "iboss_master_crm_info/index" );	
								}	
							}								
						}
					}
				}
			
			
		}
		
		
	}
	
	
	
function get_product_json($value='') 
  { 
  $this->datatables->set_database('iBOSS_read');
  header('Content-Type: application/json');
  
if(in_array(1,$this->ums_fa_biz_class_info_id)){$function = 'life_policy_info'; $type = 'LI';};
  if(in_array(7,$this->ums_fa_biz_class_info_id)){$function = 'gi_policy_info'; $type = 'GI';};
  if(in_array(8,$this->ums_fa_biz_class_info_id)){$function = 'group_policy_info'; $type = 'GROUP';};
  if(in_array(9,$this->ums_fa_biz_class_info_id)){$function = 'investment_info'; $type = 'INV';};
  if(in_array(10,$this->ums_fa_biz_class_info_id)){$function = 'life_policy_info'; $type = 'LI';};
  if(in_array(3,$this->ums_fa_biz_class_info_id)){$function = 'life_policy_info'; $type = 'LI';};
	
  //$this->datatables->select('unique_id,far_code,identification_no,passport_no,fin_no,nric_name,dob,crm_controller,iboss_farops_far_info.iboss_preferred_name as iboss_preferred_name');
  $this->datatables->select("t1.unique_id, t1.far_code, trim(t1.nric_name) as nric_name, t1.dob, t1.crm_controller, t2.iboss_preferred_name as iboss_preferred_name, t2.iboss_status as iboss_status,t3.primary_email as email,
   	CASE
		WHEN (t1.identification_no != ''  AND  t1.passport_no  != '' AND  t1.fin_no   !='') THEN concat(t1.identification_no,' / ',t1.passport_no,' / ',t1.fin_no)    
		WHEN (t1.identification_no  = ''  AND  t1.passport_no  != '' AND  t1.fin_no   ='') THEN concat(t1.passport_no)    
		WHEN (t1.identification_no  = ''  AND  t1.passport_no  = '' AND  t1.fin_no   !='') THEN concat(t1.fin_no)    
		WHEN (t1.identification_no != ''  AND  t1.passport_no  != ''  AND   t1.fin_no   ='') THEN concat(t1.identification_no,' / ',t1.passport_no)    
		WHEN (t1.identification_no != ''  AND  t1.passport_no  = '' AND  t1.fin_no   ='') THEN concat(t1.identification_no)
		WHEN (t1.identification_no != ''  AND  t1.passport_no  = '' AND  t1.fin_no   !='') THEN concat(t1.identification_no,' / ',t1.fin_no)    
		WHEN (t1.identification_no = ''  AND  t1.passport_no != ''  AND   t1.fin_no   !='') THEN concat(t1.passport_no,' / ',t1.fin_no)    

		WHEN (t1.identification_no IS NULL   AND  t1.passport_no  IS NOT NULL  AND  t1.fin_no  IS NULL ) THEN concat(t1.passport_no)    
		WHEN (t1.identification_no  IS NULL   AND  t1.passport_no  IS NULL  AND  t1.fin_no   IS NOT NULL ) THEN concat(t1.fin_no)    
		WHEN (t1.identification_no IS NOT NULL   AND  t1.passport_no  IS NOT NULL   AND   t1.fin_no  IS NULL ) THEN concat(t1.identification_no,' / ',t1.passport_no)    
		WHEN (t1.identification_no IS NOT NULL   AND  t1.passport_no IS NULL  AND  t1.fin_no  IS NULL ) THEN concat(t1.identification_no)
		WHEN (t1.identification_no IS NOT NULL   AND  t1.passport_no IS NULL  AND  t1.fin_no   IS NOT NULL ) THEN concat(t1.identification_no,' / ',t1.fin_no)    
		WHEN (t1.identification_no IS NULL   AND  t1.passport_no IS NOT NULL   AND   t1.fin_no  IS NOT NULL) THEN concat(t1.passport_no,' / ',t1.fin_no) 
		ELSE ''
		END as identification_no,CASE 
		WHEN (t3.primary_contact != '') THEN t3.primary_contact 
		WHEN (t3.primary_office != '') THEN t3.primary_office
		ELSE ''
		END as contact 
		" , FALSE);

  $this->datatables->from('iboss_master_crm_index t1');
 
  $this->datatables->join('iboss_farops_far_info t2', 't2.iboss_far_code=t1.far_code'); 
  $this->datatables->join('iboss_master_crm_report t3 ', 't3.unique_id=t1.unique_id', 'left'); 
 
  if(!empty($_POST['client_id']))
  {
 $this->datatables->like('t1.unique_id' , trim($_POST['client_id']));


  }
  
  if($value !='undefined' && $value !='')
  {
  $this->datatables->where('t1.far_code' ,  $value);
  }
  
  if(!empty($_POST['client_name']))
  {
  $this->datatables->like('t1.nric_name' , trim($_POST['client_name']));
  }
  if(!empty($_POST['nric_no']))
  {
  $this->datatables->like('t1.identification_no' , trim($_POST['nric_no']));
  }
  if(!empty($_POST['fin_no']))
  {
  $this->datatables->like( 't1.fin_no' , trim($_POST['fin_no']));
  }
  if(!empty($_POST['passport_no']))
  {
  $this->datatables->like( 't1.passport_no' , trim($_POST['passport_no']));
  }

  if(!empty($_POST['primary_contact']))
  {
  // $this->datatables->like( 't3.primary_contact' , trim($_POST['primary_contact']));

  //  $this->datatables->or_like( 't3.primary_office' , trim($_POST['primary_contact']));
  	  $this->datatables->where('(t3.primary_contact Like "%'.trim($_POST['primary_contact']).'%" or  t3.secondary_contact Like "%'.trim($_POST['primary_contact']).'% " or t3.home_contact Like "%'.trim($_POST['primary_contact']).'% "  or t3.office_contact Like "%'.trim($_POST['primary_contact']).'% " or  t3.primary_office Like "%'.trim($_POST['primary_contact']).'% " or  t3.secondary_office Like "%'.trim($_POST['primary_contact']).'% ")' , '' , FALSE);


  }


   if(!empty($_POST['primary_email']))

  {
	$this->datatables->where('(t3.primary_email Like "%'.trim($_POST['primary_email']).'%" or  t3.secondary_email Like "%'.trim($_POST['primary_email']).'% ")' , '' , FALSE);
 
  }

  
  $add_button_data="";

  if(in_array(1,$this->ums_fa_biz_class_info_id) or in_array(3,$this->ums_fa_biz_class_info_id))
  {
  $add_button_data.=' <li><a  title="Life Insurance"  href="#"   onclick="farops_license_check(\'$2\',\'LI\',\'$1\')" data-code="$1" style="font-size: 14px;"><i class="fa fa-user-plus" aria-hidden="true" style="color:#f8ac59"></i> Life Insurance  </a></li>';
  }

  if(in_array(7,$this->ums_fa_biz_class_info_id)  or in_array(3,$this->ums_fa_biz_class_info_id))
  {
  $add_button_data.=' <li><a  title="General Insurance"  href="#" onclick="farops_license_check(\'$2\',\'GI\',\'$1\')" style="font-size: 14px;"><i class="fa fa-user-plus" aria-hidden="true" style="color:#f8ac59"></i> General Insurance  </a></li>';
  }

  if(in_array(8,$this->ums_fa_biz_class_info_id)  or in_array(3,$this->ums_fa_biz_class_info_id))
  {
  $add_button_data.='<li><a  title="Group Insurance"  onclick="farops_license_check(\'$2\',\'GROUP\',\'$1\')"  href="#" style="font-size: 14px;"><i class="fa fa-user-plus" aria-hidden="true" style="color:#f8ac59"></i> Group Insurance  </a></li>';
  }
  
  /* if(in_array(7,$this->ums_fa_biz_class_info_id)  or in_array(3,$this->ums_fa_biz_class_info_id))
  {
  $add_button_data.=' <li><a  title="General Insurance" target="_blank" href="'.base_url().'index.php/iboss_acc_gi_policy_info/add_edit_policy/$1/new" style="font-size: 14px;"><i class="fa fa-user-plus" aria-hidden="true" style="color:#f8ac59"></i> General Insurance  </a></li>';
  }

  if(in_array(8,$this->ums_fa_biz_class_info_id)  or in_array(3,$this->ums_fa_biz_class_info_id))
  {
  $add_button_data.='<li><a  title="Group Insurance"  target="_blank" href="'.base_url().'index.php/iboss_acc_group_policy_info/add_edit_policy/$1/new" style="font-size: 14px;"><i class="fa fa-user-plus" aria-hidden="true" style="color:#f8ac59"></i> Group Insurance  </a></li>';
  } */
  
  

  if(in_array(9,$this->ums_fa_biz_class_info_id)  or in_array(3,$this->ums_fa_biz_class_info_id))
  {    
  $add_button_data.='<li><a  title="Investment"  onclick="farops_license_check(\'$2\',\'INV\',\'$1\')"   style="font-size: 14px;"><i class="fa fa-user-plus" aria-hidden="true" style="color:#f8ac59"></i> Investment  </a></li>';
  }

  if(in_array(10,$this->ums_fa_biz_class_info_id)  or in_array(3,$this->ums_fa_biz_class_info_id))
  {  
  $add_button_data.='<li><a  title="Other Services" target="_blank" href="'.base_url().'index.php/iboss_acc_other_services_info/add_edit_policy/$1/new"  style="font-size: 14px;"><i class="fa fa-user-plus" aria-hidden="true" style="color:#f8ac59"></i> Other Services  </a></li>';
  }


$this->datatables->add_column('Actions', '<div class="btn-group">
  <button data-toggle="dropdown" class="btn btn-primary btn-sm dropdown-toggle"><span class="caret"></span>Action</button>
  <ul class="dropdown-menu" style="left:auto;right:0px;">
  <li><a  title="Account Summary" target="_blank" href="'.base_url().'index.php/iboss_master_crm_info/'.$function.'/$1/$2/'.$type.'" style="font-size: 14px;"><i class="fa fa-user" aria-hidden="true" style="color:#f8ac59"></i> Account Summary </a></li>
  <li><a  title="View CRM" target="_blank" href="'.base_url().'index.php/iboss_master_crm_info/$3/$1/view" style="font-size: 14px;"><i class="fa fa-search-plus" aria-hidden="true" style="color:#1c84c6"></i> View CRM </a></li>
  <li><a  title="Edit" target="_blank" href="'.base_url().'index.php/iboss_master_crm_info/$3/$1" data-code="$1" style="font-size: 14px;"><i class="fa fa-pencil-square-o" aria-hidden="true" style="color:#1ab394"></i> Edit </a></li>
  <li><a  title="Account Summary" target="_blank" href="'.base_url().'index.php/iboss_master_crm_info/upload_documents/$1/$2" style="font-size: 14px;"><i class="fa fa-file" aria-hidden="true"></i> View Documents </a></li>
  <li><a  title="Copy" href="'.base_url().'index.php/iboss_master_crm_info/copy_paste_crm/$1" data-code="$1" style="font-size: 14px;"><i class="fa fa-copy" aria-hidden="true" style="color:#f8ac59"></i> Copy </a></li>
  <li><a  title="Delete"  href="#modal-form" data-toggle="modal"  data-rowid="$1" data-code="$1" style="font-size: 14px;"><i class="fa  fa-trash-o" aria-hidden="true" style="color:#ed5565"></i> Delete </a></li>
  <li><a  title="Log" target="_blank" href="'.base_url().'index.php/iboss_master_crm_info/crm_log/$1" data-code="$1" style="font-size: 14px;"><i class="fa fa-file-text-o" aria-hidden="true" style="color:#1ab394"></i> Log </a></li>

  </ul>
  </div>
  <div class="btn-group">
  <button data-toggle="dropdown" class="btn btn-warning btn-sm dropdown-toggle"><span class="caret"></span>Add New</button>
  <ul class="dropdown-menu" style="left:auto;right:0px;">
  '.$add_button_data.'
  </ul>
  </div>','unique_id,far_code,crm_controller');


  $this->datatables->add_column('Update_Address', '<a href="'.base_url().'index.php/iboss_acc_update_address_info/acc_crm_address_info/$1/$2" data-code="$1" class="btn btn-primary btn-sm" name="save" type="button"><i class="fa fa-edit"></i></a> &nbsp; <a onclick="Update_Address_Log(\'$1\')" class="btn btn-success btn-sm" type="button"><i class="fa fa-file-text-o"></i></a>','unique_id,far_code,crm_controller');

  $this->datatables->add_column('Update_Contact', '<a href="'.base_url().'index.php/iboss_acc_update_contact_info/acc_crm_contact_info/$1/$2" data-code="$1" class="btn btn-primary btn-sm" name="save" type="button"><i class="fa fa-edit"></i></a>  &nbsp; <a onclick="Update_Contact_Log(\'$1\')" class="btn btn-success btn-sm" type="button"><i class="fa fa-file-text-o"></i></a>','unique_id,far_code,crm_controller');

  $this->datatables->add_column('Update_Contact_Log', 'onclick="Update_Contact_Log(\'$1\')"','unique_id');

  echo  $this->datatables->generate();
  
  
  
  
  
  }
 
  /*************************************  Start Excel Export **********************/
  function export_excel_new( ){

	ini_set('memory_limit', '-1');
	ini_set('max_execution_time', 0);
	memory_get_peak_usage(true);

  
  header( "Content-Type: application/vnd.ms-excel" );
  header( "Content-disposition: attachment; filename=".date('d-m-Y')." - Master Crm.xls");
  $handle = fopen('php://output', 'w');

		$master_excel = "SELECT 
		unique_id,
		identification_no,
		fin_no,
		passport_no,
		saluation,
		nric_name,
		preferred_name,
		far_code,
		dob,
		nationality_name,
		citizenship_name,
		country_of_residence_name,
		primary_contact,
		home_contact,
		office_contact,
		primary_office,
		secondary_office,
		primary_email,
		secondary_email,
		residential_postal_code,
		residential_unit,
		residential_block,
		residential_building,
		residential_street,
		residential_city_name,
		residential_state_name,
		residential_country_name,
		overseas_postal_code,
		overseas_unit,
		overseas_block,
		overseas_building,
		overseas_street,
		overseas_city_name,
		overseas_state_name,
		overseas_country_name,
		mailing_postal_code,
		mailing_unit,
		mailing_block,
		mailing_building,
		mailing_street,
		mailing_city_name,
		mailing_state_name,
		mailing_country_name,
		occupation_id,
		ai,
		pep,
		smoker,
		far_name,
		race, 
		marital_status, 
		gender_name,
		religion,
		`language`,
		faiwa_client,
		REPLACE(remarks,'\n','') as remarks, 
		high_education,
		school, 
		qulification, 
		employer,
		nature_business,
		nature_employement,
		designation,
		length_service,
		income,
		oi, 
		cdd_search,
		cdd_hit, 
		cdd_outcome,
		ecdd_outcome, 
		calls,
		call_consent_date,
		email,
		email_consent_date,
		sms,
		sms_consent_date,
		fax,
		fax_consent_date,
		letter,
		letter_consent_date,
		eversion,
		eversion_consent_date,
		nature_business
		
	FROM
		iboss_master_crm_report
		WHERE
		1 = 1 and unique_id not LIKE '%Auth%' AND far_code is not null ";
	

  		$filter_ColumnName = " ";
  		$consultant = 'ALL';
  
	if (!empty($_POST['iboss_dict_cpd_type_id'])){
	  $filter_ColumnName .= "\t"." Consultant :"."\t".$_POST['iboss_dict_cpd_type_id']."\t"."\t"."\r\n";
	$master_excel .= " AND `iboss_master_crm_report`.`far_code` = '".$_POST['iboss_dict_cpd_type_id']."' ";
	} else{
	  $filter_ColumnName .= "\t"." Consultant :"."\t".$consultant."\t"."\t"."\r\n";
	}

	if(!empty($_POST['client_name'])){
	  $filter_ColumnName .= "\t"." Client Name :"."\t".$_POST['client_name']."\t"."\t"."\r\n";
	$master_excel .= " AND `iboss_master_crm_report`.`nric_name` LIKE '%".trim($_POST['client_name'])."%' ";
	}

	if(!empty($_POST['nric_no'])){
	  $filter_ColumnName .= "\t"." NRIC Number :"."\t".$_POST['nric_no']."\t"."\t"."\r\n";
	$master_excel .= " AND `iboss_master_crm_report`.`identification_no` LIKE '%".trim($_POST['nric_no'])."%'";
	}

	if(!empty($_POST['passport_no'])){
	  $filter_ColumnName .= "\t"." Passport Number :"."\t".$_POST['passport_no']."\t"."\t"."\r\n";
	$master_excel .=" AND  `iboss_master_crm_report`.`passport_no` LIKE '%".trim($_POST['passport_no'])."%'";
	}

	if(!empty($_POST['fin_no'])){
	  $filter_ColumnName .= "\t"." FIN Number :"."\t".$_POST['fin_no']."\t"."\t"."\r\n";
	  $master_excel .=" AND  `iboss_master_crm_report`.`fin_no` LIKE '%".trim($_POST['fin_no'])."%'"; 
	}

	if(!empty($_POST['client_id'])){
	  $filter_ColumnName .= "\t"." Client ID :"."\t".$_POST['client_id']."\t"."\t"."\r\n";
	  $master_excel .=" AND  `iboss_master_crm_report`.`unique_id` LIKE '%".trim($_POST['client_id'])."%'";  
	}

$master_excel .= "  ORDER BY `far_code` ASC ";

$export = $this->iboss_read->query($master_excel);

/*echo '<pre>';
print_r($this->iboss_read->last_query());*/



$master_export_value =	$export->result();

	echo "\t"."\t"."\t"."\t"."\t"."\t"."\t"."\t"."\t"."\t"."iBOSS  MASTER CRM INFO REPORT"."\n";
	echo"\r\n";
	echo "\t"."Filter Columns :"."\t"."\t"."\r\n";
	echo $filter_ColumnName;
	echo"\r\n";
	//echo "\t"."\t"."\t"."\t"."\t"."\t"."\t"."\t"."\t"."\t"."\t"."\t"."\t"."\t"."\t"."\t"."\t"."\t"."\t"."\t"."\t"."\t"."\t"."\t"."\t"."\t"."\t"."Local PostCode"."\t"."Local UnitNumber"."\t"."Local Block"."\t"."Local Building"."\t"."Local StreetName"."\t"."Local City"."\t"."Local State"."\t"."Local Country"."\t"."Overseas PostCode"."\t"."Overseas UnitNumber"."\t"."Overseas Block"."\t"."Overseas Building"."\t"."Overseas StreetName"."\t"."Overseas City"."\t"."Overseas State"."\t"."Overseas CountryName"."\t"."Mailing PostCode"."\t"."Mailing UnitNumber"."\t"."Mailing Block"."\t"."Mailing Building"."\t"."Mailing StreetName"."\t"."Mailing City"."\t"."Mailing State"."\t"."Mailing CountryName";
	//echo"\r\n";
	echo "Client Id"."\t"."FAR Code"."\t"."FAR Name "."\t"."NRIC Number / Business Registration No"."\t"."Name (As in NRIC) / Business Name"."\t"."Salutation"."\t"."Preferred Name"."\t"."Nationality"."\t"."Country of Residence"."\t"."Nature of business"."\t"."Entry Pass"."\t"."Race"."\t"."FIN No"."\t"."Passport No"."\t"."DOB / Date of Registration"."\t"."Gender"."\t"."Marital Status"."\t"."Smoking Status"."\t"."FAiWA Client"."\t"."Religion"."\t"."Preferred Language"."\t"."Remarks"."\t"."Primary Contact (HP)"."\t"."Secondary Contact (HP)"."\t"."Home Contact"."\t"."Office Contact"."\t"."Primary Email Address"."\t"."Secondary Email Address"."\t"."Local Postal Code"."\t"."Local Unit Number"."\t"."Local Block"."\t"."Local Building"."\t"."Local Street Name"."\t"."Local City"."\t"."Local State"."\t"."local Country"."\t"."OverSeas Postal Code"."\t"."OverSeas Unit Number"."\t"."OverSeas Block"."\t"."OverSeas Building"."\t"."OverSeas Street Name"."\t"."OverSeas City"."\t"."OverSeas State"."\t"."OverSeas Country"."\t"."Mailing Postal Code"."\t"."Mailing Unit Number"."\t"."Mailing Block"."\t"."Mailing Building"."\t"."Mailing Street Name"."\t"."Mailing City"."\t"."Mailing State"."\t"."Mailing Country"."\t"."Highest Education"."\t"."School"."\t"."Qualification"."\t"."Employer"."\t"."Nature of Business"."\t"."Occupation"."\t"."Nature of Employment"."\t"."Designation"."\t"."Length of Service"."\t"."Annual Income"."\t"."Ai Client"."\t"."Oi Client"."\t"."PEP"."\t"."CDD Date Of Search"."\t"."CDD Number of Hit"."\t"."CDD Outcome"."\t"."ECDD Outcome"."\t"."CALL"."\t"."Consent Date"."\t"."Email"."\t"."Consent Date"."\t"."SMS"."\t"."Consent Date"."\t"."Fax"."\t"."Consent Date"."\t"."Letter"."\t"."Consent Date"."\t"."Only Receive Electronic Version"."\t"."Consent Date";

	echo"\r\n";

	foreach($master_export_value as $row) {
		echo $out=$row->unique_id."\t".
		$row->far_code."\t".
		$row->far_name."\t".
		$row->identification_no."\t".
		$row->nric_name."\t".
		$row->saluation."\t".
		$row->iboss_preferred_name."\t".
		$row->nationality_name."\t".
		$row->country_of_residence_name."\t".
		$row->corp_nature_business."\t".
		$row->citizenship_name."\t".
		$row->race."\t".
		$row->fin_no."\t".
		$row->passport_no."\t".
		iso2sg($row->dob)."\t".
		$row->gender_name."\t".
		$row->marital_status."\t".
		$row->smoker."\t".
		$row->faiwa_client."\t".
		$row->religion."\t".
		$row->language."\t".
		trim($row->remarks)."\t".
		$row->primary_contact."\t".
		$row->secondary_office."\t".
		$row->home_contact."\t".
		$row->office_contact."\t".
		$row->primary_email."\t".
		$row->secondary_email."\t".
		$row->residential_postal_code."\t".
		$row->residential_unit."\t".
		$row->residential_block."\t".
		$row->residential_building."\t".
		$row->residential_street."\t".
		$row->residential_city_name."\t".
		$row->residential_state_name."\t".
		$row->residential_country_name."\t".
		$row->overseas_postal_code."\t".
		$row->overseas_unit."\t".
		$row->overseas_block."\t".
		$row->overseas_building."\t".
		$row->overseas_street."\t".
		$row->overseas_city_name."\t".
		$row->overseas_state_name."\t".
		$row->overseas_country_name."\t".
		$row->mailing_postal_code."\t".
		$row->mailing_unit."\t".
		$row->mailing_block."\t".
		$row->mailing_building."\t".
		$row->mailing_street."\t".
		$row->mailing_city_name."\t".
		$row->mailing_state_name."\t".
		$row->mailing_country_name."\t".
		$row->high_education."\t".
		$row->school."\t".
		$row->qulification."\t".
		$row->employer."\t".
		$row->nature_business."\t".
		$row->occupation_id."\t".
		$row->nature_employement."\t".
		$row->designation."\t".
		$row->length_service."\t".
		$row->income."\t".
		$row->ai."\t".
		$row->oi."\t".
		$row->pep."\t".
		iso2sg($row->cdd_search)."\t".
		$row->cdd_hit."\t".
		$row->cdd_outcome."\t".
		$row->ecdd_outcome."\t".
		$row->calls."\t".
		iso2sg($row->call_consent_date)."\t".
		$row->email."\t".
		iso2sg($row->email_consent_date)."\t".
		$row->sms."\t".
		iso2sg($row->sms_consent_date)."\t".
		$row->fax."\t".
		iso2sg($row->fax_consent_date)."\t".
		$row->letter."\t".
		iso2sg($row->letter_consent_date)."\t".
		$row->eversion."\t".
		iso2sg($row->eversion_consent_date)."\r\n";
	}
	
	echo"\r\n";
	fclose($handle);
}


  	function export_excel( ){

  		ini_set('memory_limit', '-1');
  		ini_set('max_execution_time', 0);
  		memory_get_peak_usage(true);
  

      $master_excel = "SELECT unique_id,far_code,identification_no,passport_no,fin_no,nric_name,`iboss_farops_far_info`.`iboss_preferred_name` as iboss_preferred_name
      FROM iboss_master_crm_index 
      JOIN iboss_farops_far_info ON `iboss_farops_far_info`.`iboss_far_code`=`iboss_master_crm_index`.`far_code` WHERE 1=1";

      if (!empty($_POST['iboss_dict_cpd_type_id'])){

          $master_excel .= " AND `iboss_master_crm_index`.`far_code` = '".$_POST['iboss_dict_cpd_type_id']."' ";
      }

      if(!empty($_POST['client_name'])){

          $master_excel .= " AND `iboss_master_crm_index`.`nric_name` LIKE '%".trim($_POST['client_name'])."%' ";
      }

      if(!empty($_POST['nric_no'])){

          $master_excel .= " AND `iboss_master_crm_index`.`identification_no` LIKE '%".trim($_POST['nric_no'])."%'";
      }

      if(!empty($_POST['passport_no'])){

          $master_excel .=" AND  `iboss_master_crm_index`.`passport_no` LIKE '%".trim($_POST['passport_no'])."%'";
      }

      if(!empty($_POST['fin_no'])){

            $master_excel .=" AND  `iboss_master_crm_index`.`fin_no` LIKE '%".trim($_POST['fin_no'])."%'"; 
      }
  
      if(!empty($_POST['client_id'])){

            $master_excel .=" AND  `iboss_master_crm_index`.`unique_id` LIKE '%".trim($_POST['client_id'])."%'";  
      }

      $master_excel .= " ORDER BY `unique_id` ASC ";

      $export = $this->iboss_read->query($master_excel);

  		echo  json_encode($export->result());

  	}

  	/************************************* End Excel Export **********************/

	function index( ) {

		//$data = $this->Crm_personal_info_model->init_data();
		//$orderby[$column] = $direction;
		//nullify or add more key/value pairs to $orderby as required
		//$limit = $this->page_limit;
          

		  
		  
		  

		  
		$data->templates = array('datatables','chosen');
		//for filters in the index page
		//$all['All'] = "All";
		//following is and example of an array to pass to view for the dropdown
		//$data->status_options = array_merge($all,$enum['status_options']);
		
		//$data->index1 = $this->Crm_personal_info_model->retrieve(array(), $limit, $offset, $orderby);
		//$data->index2 = $this->Crm_corporate_info_model->retrieve(array(), $limit, $offset, $orderby);
		
		
		//$sql = "select id,far_code,unique_id,identification_no as identification_no, nric_name as nric_name ,status as status ,dob as dob from iboss_crm_personal_info where delete_log='False'  union select id,far_code,unique_id ,biz_reg_no as identification_no, business_name as nric_name, status as status, biz_reg_date as dob from iboss_crm_corporate_info where delete_log='False' order by unique_id desc";
		
		               // $sql = "update iboss_crm_personal_info set  delete_log='True' where  copy_parent_id !=''";
				      ///  $result = $this->db->query($sql);
						
						//$sql = "update iboss_crm_corporate_info set  delete_log='True' where  copy_parent_id !=''";
				       // $result = $this->db->query($sql);
		
		$this->session->unset_userdata('redirect_name_far_code');
		//Unset Refer url Page
		$this->session->unset_userdata('refer_url_page');
		//End Unset url Page
		
		
										$this->session->unset_userdata('refer_policy_owner_type');
										$this->session->unset_userdata('refer_client_name');
										$this->session->unset_userdata('refer_relationship');
										$this->session->unset_userdata('refer_iboss_client_info_table');
										$this->session->unset_userdata('edit_crm_acc');
		
		//$sql = "select unique_id,nric_name as nric_name,far_code as far_code,identification_no as identification_no ,dob as dob,status as status ,copy_parent_id as copy_parent_id from iBOSS.iboss_crm_personal_info where delete_log='False' and  prefix_unique_id='Inv' union select unique_id, business_name COLLATE utf8_unicode_ci as nric_name , far_code as far_code,biz_reg_no as identification_no,biz_reg_date as dob ,status as status ,copy_parent_id as copy_parent_id from iBOSS.iboss_crm_corporate_info where delete_log='False' order by unique_id desc";

		//$query = $this->db->query($sql);
          
		//print_r( $query->result());
		//$data->index = $this->Iboss_view_model->retrieve([],2000,null,null,'master_crm_index');
		//$data->index = $query->result();

		//$data->get_all_column = $this->Iboss_view_model->get_column_name('master_crm_index');
		
		//print_r($data->index);
		//$data->p_email = function($unq_id){ $p_data =  $this->_selector_options('crm_email_info_model', 'unique_id', 'email_id', array('unique_id' => "asc"),array('unique_id' => $unq_id,'set_default'=>'Yes'));
        //  if(count($p_data)!="0"){return $p_data[$unq_id]; }else{ echo "";} };
		  
		  
		// $data->p_no = function($unq_id){ $p_data =  $this->_selector_options('crm_contact_info_model', 'unique_id', 'contact_number', array('unique_id' => "asc"),array('unique_id' => $unq_id,'set_default'=>'Yes'));
         // if(count($p_data)!="0"){return $p_data[$unq_id]; }else{ echo "";} };
		  
		  
		   
		  
		//$data->index = $this->Crm_personal_info_model->retrieve(array(), $limit, $offset, $orderby);
        
		$data->far_id_options = array("" => "All");
        $far_id = $this->_selector_farcode();
        foreach ($far_id as $key => $val) {
            $data->far_id_options[$key] = $val;
        }
		
		

		/* $_selector_FARname_options = selector_consultans_FARname();  
    	foreach ($_selector_FARname_options as $key => $val) {
            $data->far_id_options_2[$key] = $val.' - '.$key;
        }
		 */
		/* $data->count_li_insurance =function($unqie_id){
				
                $sql = "select id from iboss_acc_li_policy_info where  iboss_crm_unique_id='".$unqie_id."' and delete_log='False'";
				$result = $this->db->query($sql);
				$li_result = $result->num_rows();
				
				return  $li_result;
				
				};
		 */
		
		
		//$data->curr_item = $offset;
		//$data->direction = $direction;
		//$this->_nitro_pagination_init('index',$this->Crm_personal_info_model->count(),$limit);
		//$data->links = $this->pagination->create_links();

		//$this->_set_action($data,1,"iboss_master_crm_info/add_edit/","fa fa-plus fa-fw","Add","Add");
		
		$this->load->view("template/common_header", $data);
		$this->load->view("iboss_master_crm/iboss_master_crm_info_index", $data);
		$this->load->view("template/common_footer", $data);
		return;
	}


	
	function deletessssssss( $id = 0 ){
		
		$sql1="select * from iboss_acc_li_policy_info where delete_log='False' AND iboss_crm_unique_id = '".$id."'";
		$result1 = $this->db->query($sql1);
		$results1 = $result1->result();
		if(!empty($results1)){echo "Success"; die;}
		else if(empty($results1))
		{
		echo "gi";		
		$sql2="select * from iboss_acc_gi_policy_info where delete_log='False' AND iboss_crm_unique_id = '".$id."'";
		$result2 = $this->db->query($sql2);
		$results2 = $result2->result();			
		if(!empty($results2)){echo "Success"; die;}
		}
		else if(empty($results2))
		{
		echo "group";				
		$sql3="select * from iboss_acc_group_policy_info where delete_log='False' AND iboss_crm_unique_id = '".$id."'";
		$result3 = $this->db->query($sql3);
		$results3 = $result3->result();	
		if(!empty($results3)){echo "Success"; die;}
		}
		elseif(empty($results3))
		{
		echo "inv";						
		$sql4="select * from iboss_acc_inv_account where delete_log='False' AND iboss_crm_unique_id = '".$id."'";
		$result4 = $this->db->query($sql4);
		$results4 = $result4->result();	
		if(!empty($results4)){echo "Success"; die;}
		}
		elseif(empty($results4))
		{
		echo "other";						
		$sql5="select * from iboss_acc_other_services_info where delete_log='False' AND iboss_crm_unique_id = '".$id."'";
		$result5 = $this->db->query($sql5);
		$results5 = $result5->result();	
		if(!empty($results5)){echo "Success"; die;}
		}
		else
		{
		echo "else";
		$affected_rows = $this->Crm_personal_info_model->delete( $id );
		redirect( "iboss_master_crm_info/index" );
		}
		
	}
	
	
	function delete( $id = 0 ){
		
		$sql1="select iboss_crm_unique_id from iboss_acc_li_client_info where delete_log='False' AND iboss_crm_unique_id = '".$id."' LIMIT 1";
		$result1 = $this->db->query($sql1);
		$results1 = $result1->result();
		if(!empty($results1))
		{
		echo "Success"; 
		die;
		}
		else
		{
			//echo "gi";
			$sql2="select iboss_crm_unique_id from iboss_acc_gi_client_info where delete_log='False' AND iboss_crm_unique_id = '".$id."' LIMIT 1";
			$result2 = $this->db->query($sql2);
			$results2 = $result2->result();			
			if(!empty($results2))
			{
			echo "Success"; 
			die;
			}
				else
				{
					//echo "group";				
					$sql3="select iboss_crm_unique_id from iboss_acc_group_client_info where delete_log='False' AND iboss_crm_unique_id = '".$id."' LIMIT 1";
					$result3 = $this->db->query($sql3);
					$results3 = $result3->result();				
					if(!empty($results3))
					{
					echo "Success"; 
					die;
					}
					else
					{
						//echo "INV";				
						$sql4="select iboss_crm_unique_id from iboss_acc_inv_client_info where delete_log='False' AND iboss_crm_unique_id = '".$id."' LIMIT 1";
						$result4 = $this->db->query($sql4);
						$results4 = $result4->result();				
						if(!empty($results4))
						{
						echo "Success"; 
						die;
						}
						else
						{
							//echo "OTHER";				
							$sql5="select iboss_crm_unique_id from iboss_acc_other_services_client_info where delete_log='False' AND iboss_crm_unique_id = '".$id."' LIMIT 1";
							$result5 = $this->db->query($sql5);
							$results5 = $result5->result();				
							if(!empty($results5))
							{
							echo "Success"; 
							die;
							}
							else
							{
							//echo "else";
							//$affected_rows = $this->Crm_personal_info_model->delete( $id );
							$affected_rows = $this->iboss_master_crm_index_delete( $id );
							redirect( "iboss_master_crm_info/index" );	
							}								
						}
					}
				}
			
			
		}
	}
	
	
	function iboss_master_crm_index_delete($id)
	{
			
			$this->db->where('unique_id', $id);
			$this->db->delete('iboss_master_crm_index');	
			
			$check = preg_match("/Corp/", $id);
			
			if($check == true)
			{
			$corporate['delete_log'] = "True";
			$this->db->where('unique_id', $id);
			$this->db->update('iboss_crm_corporate_info', $corporate);	
			}
			else
			{
			$personal['delete_log'] = "True";
			$this->db->where('unique_id', $id);
			$this->db->update('iboss_crm_personal_info', $personal);		
			}
			
	}	
	
	function deletes($id){
		
			$value=explode('-' ,$id);	
			$policy_id = $value[0];
			$type = $value[1];
			if($type = 'OTHER')
			{
			$attrs['delete_log'] = "True";
			$this->db->where('id', $policy_id);
			$this->db->update('iboss_acc_other_services_info', $attrs);	
			}
			else
			{
			$attrs['delete_log'] = "True";
			$this->db->where('id', $policy_id);
			$this->db->update('iboss_acc_'.$type.'_policy_info', $attrs);	
			}

		//$this->Iboss_acc_li_policy_info_model->delete( $id );
		//redirect( "iboss_master_crm_info/index" );
		//Delete The Record
				
				//End Delete Record	
	}
	
	function restore($key = "" ,$table_name="",$id="") {
	$this->load->model("crm_log_model");
	$value= $this->crm_log_model->delete_restore($key,$table_name,$id);
	
	}


	function _set_action( &$data,$line,$uri_segments,$icon,$text,$tooltip,$onclick="" ){
		$controller = strtok($uri_segments,"/");
		$function = strtok("/");
		if(_test_access($controller,$function)){
			$data->actions_sidebar[$line]['uri_segments'] = $uri_segments;
			$data->actions_sidebar[$line]['icon'] = $icon;
			$data->actions_sidebar[$line]['text'] = $text;
			$attr['class'] = "btn btn-primary";
			$attr['data-rel'] = "tooltip";
			$attr['title'] = $tooltip;
			if(!empty($onclick)){$attr['onclick'] = $onclick;}
			$data->actions_sidebar[$line]['attr'] = $attr;
		}
		return $data;
	}


	function _set_confirmation( &$data,$line,$uri_segments,$icon,$text,$tooltip,$confirmation="Are you sure?" ){
		$controller = strtok($uri_segments,"/");
		$function = strtok("/");
		if(_test_access($controller,$function)){
			$data->actions_sidebar[$line]['uri_segments'] = $uri_segments;
			$data->actions_sidebar[$line]['icon'] = $icon;
			$data->actions_sidebar[$line]['text'] = $text;
			$attr['class'] = "btn btn-primary";
			$attr['data-rel'] = "tooltip";
			$attr['title'] = $tooltip;
			$data->actions_sidebar[$line]['attr'] = $attr;
			$data->modals[$line]['id'] = $controller."_".$function;
			$data->modals[$line]['header'] = $text." Confirmation";
			$data->modals[$line]['body'] = $confirmation;
			$data->modals[$line]['uri_segments'] = $uri_segments;
		}
		return $data;
	}


	function _nitro_set_rules() {
		$this->Crm_personal_info_model->_nitro_set_rules();
		return;
	}


	function _nitro_send_post_to_view( $post, &$data  ){
		
		
		foreach( $post as $key => $val )
		{
			$data->$key = $val;
		}
		return $data;
	}


	function _nitro_pagination_init($function, $total, $perpage ) {
		$config['base_url'] 	= site_url("iboss_master_crm_info/$function");
		$config['total_rows'] 	= $total;
		$config['per_page'] 	= $perpage;
		$config['num_links'] = 5;
		$config['full_tag_open'] = '<div class="pagination pagination-centered"><ul>';
		$config['full_tag_close'] = '</ul></div>';
		$config['first_link'] = 'First';
		$config['first_tag_open'] = '<li>';
		$config['first_tag_close'] = '</li>';
		$config['next_link'] = '&gt;';
		$config['next_tag_open'] = '<li>';
		$config['next_tag_close'] = '</li>';
		$config['prev_link'] = '&lt;';
		$config['prev_tag_open'] = '<li>';
		$config['prev_tag_close'] = '</li>';
		$config['last_link'] = 'Last';
		$config['last_tag_open'] = '<li>';
		$config['last_tag_close'] = '</li>';
		$config['cur_tag_open'] = '<li class="active"><a href="#">';
		$config['cur_tag_close'] = '</a></li>';
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		$this->pagination->initialize($config);
		return;
	}

	function _selector_options($model,$index,$option,$orderby,$where=null) {
		$this->load->model($model);
		$result = $this->$model->retrieve($where, null, 0, $orderby);
		$selector_options = array();
		foreach($result as $key=>$val) {
			$selector_options[$val->$index] = ucwords(strtolower($val->$option));
		}
		Return $selector_options;
	}

	
	
function _selector_farcode()
	{
	   if($this->session->userdata('consult_selector_options'))
		{
		
		$selector_options = $this->session->userdata('consult_selector_options');
		  
		}else{
		 $selector_options = selector_consultans();  
		 $this->session->set_userdata('consult_selector_options',$selector_options);
		}
       return $selector_options;
	}
	
	
	function _selector_phonecode()
	{
		
		$this->load->model("Iboss_dict_country_model");
		$code = $this->Iboss_dict_country_model->retrieve(array('status'=>"Active"),null, null, array('line'=>'desc'));
		
		$selector_options = array();

		foreach ($code as $key => $value) 
		{
			
					
					$selector_options[$value->id] = ucwords(strtolower($value->name)).' ( +'.$value->phonecode.' )';


		}
		Return $selector_options;
	}
	
	
	
	
	//kanagaraj
	

 	public function get_postal_detail($pin)
	{
		$index =  json_encode($this->Add_postcode_model->retrieve(array('postcode'=>$pin), null, 0, array('postcode'=>'asc')));

		
		if($index == '[]')
		{
			echo "Invalid";
		}
		else
		{
			$st=trim($index,"[");
			echo trim($st,"]");
		}
			
	}




   public function crm_log( $unique_id = NULL )
 	{
 		
		$this->load->model("Crm_log_model");
 		$data = new stdClass();
 		$data->templates = array('datatables');
		$data->crm_tab_type='6';
		$data->unique_id = $unique_id;
		$data->main_crm_type=unqiue_id_spilit($unique_id);
	    $data->title_corp='';
		if($data->main_crm_type=='Corp')
		{
			$data->title_corp='Corp';
		}

 		$data->record = $this->Crm_log_model->retrieve( array("unique_id"=>$unique_id,"action_name"=>'insert'), null, null, array("current_date_time"=>'desc') );

 		$data->record1 =$this->Crm_log_model->retrieve( array("unique_id"=>$unique_id,"action_name"=>'update') , null, null, array("current_date_time"=>'desc') );

 		$data->record2 =$this->Crm_log_model->retrieve( array("unique_id"=>$unique_id,"action_name"=>'delete',"delete_log"=>'False'), null, null, array("current_date_time"=>'desc') );
        
 		//print_r($data->record);
 		
 		$this->_set_action($data,3,"iboss_master_crm_info/index","fa fa-level-up fa-fw","Up 1 level","Back To Dashboard");
 		return $this->load->view('iboss_master_crm/iboss_master_crm_info_log',$data);
 	}


	public function show_investment_details($unique_id)
	{
		$result = $this->Iboss_acc_inv_client_info_model->retrieve(['iboss_crm_unique_id'=>$unique_id]);

		//print_r($result);

		if(count($result)!=0)
		{

			// $account_id = $result[0]->iboss_acc_inv_account_id;

			// if($account_id=='')
			// {
			// 	$this->remove_temporary_data($result[0]->uuid,$unique_id);
			// }

			$account_id ='';
		}
		else
		{

			$account_id ='';
		}

		echo $account_id;
	}

	public function remove_temporary_data($uuid,$crm_unique_id)
	{
		$table_name = ['0'=>"iboss_acc_inv_client_info","1"=>"iboss_acc_inv_account","2"=>"iboss_acc_inv_far_details","3"=>"iboss_investment_log",'4'=>'iboss_acc_inv_crm_personal_info','5'=>'iboss_acc_inv_crm_corporate_info','6'=>'iboss_acc_inv_crm_address_info','7'=>"iboss_acc_inv_crm_compliance_info",'8'=>'iboss_acc_inv_crm_contact_info','9'=>'iboss_acc_inv_crm_edu_and_emp_info','10'=>'iboss_acc_inv_crm_marketing_info'];

		$set =new stdClass();

		for ($i=0; $i <count($table_name) ; $i++) 
		{ 
			$sql = "delete from $table_name[$i] WHERE uuid = '$uuid' ";

			$res = $this->db->query($sql);

			//$result = $res->result();
		}

		return;

	}

	function _selector_provider_details()
	{
		$sql = "SELECT DISTINCT `provider_name`,`provider_id` FROM iboss_dict_investment_type WHERE `status`=\"Active\"";

        $sql_result = $this->db->query($sql);

        //print_r($sql_result->result());

        //echo "<br>";
        $row_array =[];

       foreach( $sql_result->result() as  $row ) 
       {

		$row_array[$row->provider_id] = $row->provider_name;
	   }

       // print_r($row_array);
        //die();
	   Return $row_array;
	}

	
	
	
	function _selector_overseas_country()
	{
		$sql = "SELECT * FROM iboss_dict_country WHERE `status`=\"Active\" and  id NOT IN (1)";

        $sql_result = $this->db->query($sql);
        $row_array =[''=>'--Select the List...'];
        
       foreach( $sql_result->result() as  $row ) 
       {

		$row_array[$row->id] = ucwords(strtolower($row->name));
	   }

       // print_r($row_array);
        //die();
	   Return $row_array;
	}

	
	
	
	
	
	
	public function show_investment_table($unique_id)
	{	
		$view = new stdClass();
		$view =[];

		$iboss_provider_name = $this->_selector_provider_details();
		

		//$result = $this->Iboss_acc_inv_client_info_model->retrieve(['iboss_crm_unique_id'=>$unique_id],NULL,NULL,['id'=>'DESC']);
		$result = $this->Iboss_acc_inv_client_info_model->retrieve(['iboss_acc_inv_account_id is not null and iboss_acc_inv_account_id!="" and iboss_crm_unique_id='=>$unique_id],NULL,NULL,['id'=>'DESC']);

		$account_status = $this->_selector_options('Iboss_dict_inv_account_status_model', 'id', 'name', array('name' => "asc"),array('status' => "Active"));

		

		if(!empty($result))
		{
			for ($j=0; $j <count($result) ; $j++) 
			{ 	
				$views = new stdClass();

				$index = $this->Iboss_acc_inv_info_model->retrieve(['id'=>$result[$j]->iboss_acc_inv_account_id]);
				

				$get_investment_type = $this->Iboss_dict_investment_type_model->retrieve(['id'=>$index[0]->investment_type]);

				$views->account_id =$index[0]->id;

				$views->platform_name = $iboss_provider_name[$index[0]->platform_id];

				$views->investment_type = $get_investment_type[0]->investment_type;

				$views->account_number =$index[0]->account_number;

				$views->account_name =$index[0]->account_name;

				$views->account_status =$account_status[$index[0]->account_status];
               
				$views->action = '<a title="view" href="'.base_url().'index.php/iboss_acc_inv_info/add_edit_policy/'.$unique_id.'/'.$index[0]->id.'/view"  class="btn btn-success btn-sm"><i class="fa fa-search-plus"></i></a> ' .

								 ' <a title="Edit" href="'.base_url().'index.php/Account/Inv_edit/'.$unique_id.'/'.$index[0]->id.'" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i></a> ' .

								 ' <a title="Delete" href="#"  onclick="delete_group_id('.$index[0]->id.');" class="btn btn-danger btn-sm"><i class="fa fa-trash-o"></i></a>';

				$view[] = $views;
			}

			$output = array(  
			                 
			                "show_investment_table"  => $view  
			           );

			echo json_encode($output);
		}
		else
		{
			$output = array(  
		                 
		                "show_investment_table"  => $result  
		           );

		    echo json_encode($output);
		}
		
	}
	
	
//Master CRM


function crm_personal_info($unique_id=null) 
{ 
	
		
		$data = $this->Crm_personal_info_model->init_data();
		$data->templates = array('datatables','datepicker','icheck','chosen','select2');
		
		//Common_data
		$data->main_crm_type="Inv";
		$data->crm_tab_type=1;
		$data->unique_id=$unique_id;
		//Common Data
		
		
         		
		//Importantant 
		          $data->far_code=trim($this->session->userdata('redirect_name_far_code'));
                  $data->nric_name=trim($this->session->userdata('refer_client_name'));
				  $data->preferred_name=trim($this->session->userdata('refer_client_name'));
	    //End

   												
		//Selector Options

		//$data->nationality_id_options = array(""=>"Select an Option");
		//$data->nationality_id_options = $this->_selector_options('Iboss_dict_nationality_model','id','name',array('id'=>'asc'),array('status'=>"Active"));
		
		
		$data->nationality_id_options = array(""=>"Select an Option");
		$nationality_id = $this->_selector_options('Iboss_dict_nationality_model', 'id', 'name', array('id' => "asc"),array('status'=>"Active"));		
        foreach ($nationality_id as $key => $val) {
            $data->nationality_id_options[$key] = ucwords(strtolower($val));
        }
		
		//print_r($data->nationality_id_options);
		//die();
		
		$data->country_id_options = array(""=>"Select an Option");
		$country_id = $this->_selector_options('Iboss_dict_country_model', 'id', 'name', array('id' => "asc"),array('status'=>"Active"));
        foreach ($country_id as $key => $val) {
            $data->country_id_options[$key] = ucwords(strtolower($val));
			
        }
		
		$data->race_id_options = array(""=>"Select an Option");
		$race_id = $this->_selector_options('Iboss_dict_race_model', 'id', 'name', array('id' => "asc"),array('status'=>"Active"));
        foreach ($race_id as $key => $val) {
            $data->race_id_options[$key] = ucwords(strtolower($val));
			
        }
//new add dictionary		
		$data->salutation_options = array(""=>"Select an Option");
		$salutation_id = $this->_selector_options('Iboss_dict_salutation_model', 'id', 'name', array('id' => "asc"),array('status'=>"Active"));
        foreach ($salutation_id as $key => $val) {
            $data->salutation_options[$key] = ucwords(strtolower($val));
			
        }
		
		$data->gender_options = array(""=>"Select an Option");
		$gender_id = $this->_selector_options('Iboss_dict_gender_model', 'id', 'name', array('id' => "asc"),array('status'=>"Active"));
        foreach ($gender_id as $key => $val) {
            $data->gender_options[$key] = ucwords(strtolower($val));
        }
		
		$data->marital_status_options = array(""=>"Select an Option");
		$marital_status_id = $this->_selector_options('Iboss_dict_marital_status_model', 'id', 'name', array('id' => "asc"),array('status'=>"Active"));
        foreach ($marital_status_id as $key => $val) {
            $data->marital_status_options[$key] = ucwords(strtolower($val));
        }
		
		$data->entry_pass_options = array(""=>"Select an Option");
		$entry_pass_id = $this->_selector_options('Iboss_dict_entry_pass_model', 'id', 'name', array('id' => "asc"),array('status'=>"Active"));
        foreach ($entry_pass_id as $key => $val) {
            $data->entry_pass_options[$key] = ucwords(strtolower($val));
        }
//new end dictionary				

		$data->preferred_language_id_options = array(""=>"Select an Option");
		$preferred_language_id = $this->_selector_options('Iboss_dict_preferred_language_model', 'id', 'name', array('id' => "asc"),array('status'=>"Active"));
        foreach ($preferred_language_id as $key => $val) {
            $data->preferred_language_id_options[$key] = ucwords(strtolower($val));
			
        }
		

		//$data->race_id_options = array(""=>"Select an Option");
		//$data->race_id_options = $this->_selector_options('Iboss_dict_race_model','id','name',array('id'=>'asc'),array('status'=>"Active"));
        
		$data->religion_id_options = array(""=>"Select an Option");
		$religion_id = $this->_selector_options('Iboss_dict_religion_model', 'id', 'name', array('id' => "asc"),array('status'=>"Active"));
        foreach ($religion_id as $key => $val) {
            $data->religion_id_options[$key] = ucwords(strtolower($val));
			
        }
		
		
		
		//$data->religion_id_options = $this->_selector_options('Iboss_dict_religion_model','id','name',array('id'=>'asc'),array('status'=>"Active"));
     	//End 
		
		
		//NRIC Name
		$data->nric_name_options = $this->_selector_options('Crm_personal_info_model','id','nric_name',array('id'=>'asc'),array('status'=>"Active",'relationship'=>"self",'delete_log'=>"False"));
        //End 
		
		
		$data->far_id_options = array("" => "-- Select FAR --");
        $far_id = $this->_selector_farcode();
        foreach ($far_id as $key => $val) {
            $data->far_id_options[$key] = $val;
        }
		
		
		if(!empty($unique_id)){
		
        
		$record = $this->Crm_personal_info_model->retrieve( array( "unique_id" => $unique_id ) );
		$record[0]->dob=iso2sg($record[0]->dob);
		
		$record[0]->last_birth_date=$this->chek_the_name($record[0]->unique_id,'','r4');
		$record[0]->next_birth_date= $this->chek_the_name($record[0]->unique_id,'','r5');
	    $id=$record[0]->id;
		$record[0]->autosync_fileds = explode( ',' , $record[0]->autosync_fileds);
		
		$record_copy_parent = $this->Crm_personal_info_model->retrieve( array( "unique_id" => $record[0]->copy_parent_id ) );
		$record[0]->copy_parent_farcode=$record_copy_parent[0]->far_code;
		
		//print_r($record);
		
		$this->_nitro_send_post_to_view($record[0],$data);
		
		
		$sql_previous="select * from iboss_crm_previous_client_name where delete_log='False' AND unique_id ='".$unique_id."'";
		$result = $this->db->query($sql_previous);
		$data->previous_client_name_data = $result->result();
		
		
		$sql_consultant = "select role_id from ums_role_permissions where role_id ='".$this->session->userdata(role_id)."' AND data like '%iboss_consultant_change%'";
		$result_consultant = $this->db->query($sql_consultant);
		$data->role_id = $result_consultant->row()->role_id;
		
		}
		
		
		if(empty($unique_id))
		{
			if ( empty( $_POST ) ) {
			return $this->load->view( "iboss_master_crm/iboss_crm_personal_info_add_edit", $data );
			}else {
				$this->_nitro_set_rules();
				$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
				if ( $this->form_validation->run() == false ) {
					$this->_nitro_send_post_to_view( $_POST, $data );
					return $this->load->view( "iboss_master_crm/iboss_crm_personal_info_add_edit", $data );
				}

				         //Checking the Condition
				        $sql = "select * from iboss_crm_personal_info where identification_no='".$_POST['identification_no']."'  and  far_code='".$_POST['far_code']."'  and prefix_unique_id='Inv' ";
				        $result = $this->db->query($sql);
				        $data->unique_id = $result->row()->unique_id;

				        /************** Exists Client Checking Based on Fin ************/
				        
				        if( $_POST['fin_no'] != ''){
					        $sql = "select * from iboss_crm_personal_info where  fin_no='".trim($_POST['fin_no'])."' and  far_code='".$_POST['far_code']."'  and prefix_unique_id='Inv' ";
				        	$result = $this->db->query($sql);
				        	$fin_unique_id = $result->row()->unique_id;
				        	 if( !empty($fin_unique_id)){
				        	 	$this->session->set_flashdata('msg', 'Client  FIN Number Already Added Same Consultant');
				        		redirect( "iboss_master_crm_info/crm_personal_info/".$_POST_UNQ['unique_id']);
				        	 }
				    	}

				    	if( $_POST['passport_no'] != ''){
					        $sql = "select * from iboss_crm_personal_info where  passport_no='".trim($_POST['passport_no'])."' and  far_code='".$_POST['far_code']."'  and prefix_unique_id='Inv' ";
				        	$result = $this->db->query($sql);
				        	$passs_unique_id = $result->row()->unique_id;

				        	// print_r($this->db->last_query());
				        	// die();
				        	 if( !empty($passs_unique_id)){
				        	 	$this->session->set_flashdata('msg', 'Client  Passport Number Already Added Same Consultant');
				        		redirect( "iboss_master_crm_info/crm_personal_info/".$_POST_UNQ['unique_id']);
				        	 }
				    	}

						if((empty($data->unique_id)) or(empty($_POST['identification_no'])))
						{
						
							if($_POST['nationality_id'] == '3')
							 {
								$_POST['citizenship']=''; 
								$_POST['fin_no']='';
							 }
				 
							if($_POST['citizenship'] == '3')
							{
							$_POST['fin_no']=''; 
							}
							
			                $_POST['dob']=sg2iso($_POST['dob']);
							$_POST['prefix_unique_id']="Inv";
							$_POST['date_time']=current_date_time();
              $_POST['nric_name'] = ucwords($_POST['nric_name']);
			  $_POST['preferred_name'] = ucwords($_POST['preferred_name']);
			  
						  $_POST = array_map("trim", $_POST);
						  
				            $insert_id=$this->Crm_personal_info_model->set( $_POST );
				
							$sum_value = 000000 + $insert_id;

							$make_unique_id = str_pad($sum_value, 6, '0', STR_PAD_LEFT);
                 

				            //Update Unquie id
							 $_POST_UNQ['unique_id'] = 'Inv'.$make_unique_id ;
							 $this->db->where('id', $insert_id);
							 $this->db->update('iboss_crm_personal_info',$_POST_UNQ);
							//End Client Info

							$this->db->query("CALL sp_iboss_master_crm_update ('crm_personal_info' , '".$_POST_UNQ['unique_id']."' , 'insert')");
							
							iboss_master_crm_index($_POST_UNQ['unique_id'], 'crm_personal_info', 'new');
						   
							 //iboss Client Info table Store
							 /*****************AML Seach**************/
							 $this->client_details_unique_id($_POST_UNQ['unique_id']);
							 /***********End AML Seach ****************/
							 
							 $refer_url_page=$this->session->userdata('refer_url_page');
							 $refer_policy_owner_type =$this->session->userdata('refer_policy_owner_type');
							 $refer_iboss_client_info_table =$this->session->userdata('refer_iboss_client_info_table');
							 
							 if(!empty($refer_url_page) and (!empty($refer_iboss_client_info_table)))
							 {              
								     
									 if($refer_iboss_client_info_table=='iboss_acc_li_client_info')
									 {
                                                    $refer_data['iboss_crm_unique_id'] = $_POST_UNQ['unique_id'];
													$refer_data['client_type'] =(!empty($refer_policy_owner_type) and $refer_policy_owner_type=='owner')?"Joint":"Life Assured";
													$refer_data['far_code'] = $this->session->userdata('redirect_name_far_code'); 
													$refer_data['relationship'] = $this->session->userdata('refer_relationship');
													$refer_data['uuid'] = $this->session->userdata('iboss_acc_li_client_info_uuid');
													$refer_data['iboss_acc_li_policy_info_id'] = $this->session->userdata('iboss_life_policy_id');
													$this->db->insert('iboss_acc_li_client_info', $refer_data);	
													$this->session->unset_userdata('refer_iboss_client_info_table');
													$this->session->set_userdata('acc_crm_new_client',$_POST_UNQ['unique_id']);
													
                                     }
									 
									 if($refer_iboss_client_info_table=='iboss_acc_gi_client_info')
									 {
                                                    $refer_data['iboss_crm_unique_id'] = $_POST_UNQ['unique_id'];
													$refer_data['client_type'] =(!empty($refer_policy_owner_type) and $refer_policy_owner_type=='owner')?"Joint":"Life Assured";
													$refer_data['far_code'] = $this->session->userdata('redirect_name_far_code'); 
													$refer_data['relationship'] = $this->session->userdata('refer_relationship');
													$refer_data['uuid'] = $this->session->userdata('iboss_acc_gi_client_info_uuid');
													$refer_data['iboss_acc_gi_policy_info_id'] = $this->session->userdata('iboss_life_policy_id');
													$this->db->insert('iboss_acc_gi_client_info', $refer_data);	
													$this->session->unset_userdata('refer_iboss_client_info_table');
													$this->session->set_userdata('acc_crm_new_client_gi',$_POST_UNQ['unique_id']);
													
                                     }
									 
									 if($refer_iboss_client_info_table=='iboss_acc_group_client_info')
									 {
                                                    $refer_data['iboss_crm_unique_id'] = $_POST_UNQ['unique_id'];
													$refer_data['client_type'] =(!empty($refer_policy_owner_type) and $refer_policy_owner_type=='owner')?"Joint":"Life Assured";
													$refer_data['far_code'] = $this->session->userdata('redirect_name_far_code'); 
													$refer_data['relationship'] = $this->session->userdata('refer_relationship');
													$refer_data['uuid'] = $this->session->userdata('iboss_acc_group_client_info_uuid');
													$refer_data['iboss_acc_group_policy_info_id'] = $this->session->userdata('iboss_life_policy_id');
													$this->db->insert('iboss_acc_group_client_info', $refer_data);	
													$this->session->unset_userdata('refer_iboss_client_info_table');
													$this->session->set_userdata('acc_crm_new_client_group',$_POST_UNQ['unique_id']);
													
                                     }
									 
									 if($refer_iboss_client_info_table=='iboss_acc_other_services_client_info')
									 {
                                                    $refer_data['iboss_crm_unique_id'] = $_POST_UNQ['unique_id'];
													$refer_data['client_type'] =(!empty($refer_policy_owner_type) and $refer_policy_owner_type=='owner')?"Joint":"Life Assured";
													$refer_data['far_code'] = $this->session->userdata('redirect_name_far_code');
													$refer_data['relationship'] = $this->session->userdata('refer_relationship');
													$refer_data['uuid'] = $this->session->userdata('iboss_acc_other_services_client_info_uuid');
													$refer_data['iboss_acc_other_services_info_id'] = $this->session->userdata('crm_save_details');
													$this->db->insert('iboss_acc_other_services_client_info', $refer_data);	
													$this->session->unset_userdata('refer_iboss_client_info_table');
													$this->session->set_userdata('acc_crm_new_client_other',$_POST_UNQ['unique_id']);
													
                                     }



									if($refer_iboss_client_info_table=='iboss_acc_inv_client_info')
									 {
										 
													$this->load->helper("copy_paste_crm_info");
                                                    $refer_data['iboss_crm_unique_id'] = $_POST_UNQ['unique_id'];
													$refer_data['client_type'] ='Joint';
													$refer_data['far_code'] = $this->session->userdata('redirect_name_far_code'); 
													$refer_data['dob']=$_POST['dob'];
													$refer_data['status']='Active';
													$refer_data['iboss_crm_id']=$insert_id;
													$refer_data['relationship'] = $this->session->userdata('refer_relationship');
													$refer_data[$this->session->userdata('main_name')] = $this->session->userdata('main_id');
													
													$this->db->insert('iboss_acc_inv_client_info', $refer_data);	
													$last_insert_id=$this->db->insert_id();

													
													save_into_acc_crm($_POST_UNQ['unique_id'],'iboss_acc_inv_client_info','Joint',$last_insert_id,$this->session->userdata('main_name'),$this->session->userdata('main_id'));
												
													$this->session->unset_userdata('refer_iboss_client_info_table');
													
													
                                     }	
                                      									 
								
							 }
							 
							 
							 //End Client Info table Store
							 

					    //End Corporate Info

							 //print_r($_POST);
							 //die();
                          
									if(isset($_POST['savenext']))
									{
										//$pass_tab = $_POST['tab_number'];
										$refer_url_page=$this->session->userdata('refer_url_page');
										if(!empty($refer_url_page)){
											$client_type=$refer_data['client_type'];
											if($refer_data['client_type']=='Life Assured'){
											 $client_type='Life Insured';	
											}
										    $this->session->set_userdata('refer_flash', "Thank You.Added New $client_type Client Successfully");
										   
										}
										 // if(empty($pass_tab))
										// {
											// $pass_tab = 'crm_contact_info';
										// }
										
									redirect( "iboss_master_crm_info/crm_contact_info/".$_POST_UNQ['unique_id']);	
									


									
									}else{
										
										$refer_url_page=$this->session->userdata('refer_url_page');
										if(!empty($refer_url_page)){
											$client_type=$refer_data['client_type'];
											if($refer_data['client_type']=='Life Assured'){
											 $client_type='Life Insured';	
											}
										    $this->session->set_userdata('refer_flash', "Thank You.Added New $client_type Client Successfully");
										    redirect($this->session->userdata('refer_url_page'));	
										}
										 
										
									//$this->session->set_flashdata('msg', 'Thank You.Added Or Updated Information Successfully');									
									redirect( "iboss_master_crm_info/crm_personal_info/".$_POST_UNQ['unique_id']);
									
									}
						}else{
							
						$this->session->set_flashdata('msg', 'Client  NRIC Number Already Added Same Consultant');
				        redirect( "iboss_master_crm_info/crm_personal_info/".$_POST_UNQ['unique_id']);	
						}
						//End Condition
				
			}
			
		}else{
			if ( empty( $_POST ) ) {
				return $this->load->view( "iboss_master_crm/iboss_crm_personal_info_add_edit", $data );
			}else {
				
				
				$this->_nitro_set_rules();
				if ( $this->form_validation->run() == false ) {
					$this->_nitro_send_post_to_view( $_POST, $data );
					return $this->load->view( "iboss_master_crm/iboss_crm_personal_info_add_edit", $data );
				}
				
				
				//FARCOde
				if(!empty($_POST['identification_no']))
				{
					if(!empty($record[0]->copy_parent_farcode))
					{
							$sql = "select * from iboss_crm_personal_info where  identification_no='".$_POST['identification_no']."' and  far_code='".$_POST['far_code']."' and prefix_unique_id='Inv' ";
							$result = $this->db->query($sql);
							$data->unique_id = $result->row()->unique_id;
							
							if(!empty($data->unique_id))
							{
							$this->session->set_flashdata('msg', 'Client  NRIC Number Already Added Same Consultant');
							redirect( "iboss_master_crm_info/crm_personal_info/".$unique_id);		
							}
						
					}
				}
				
				//FARCOde
				if(!empty($_POST['identification_no']))
				{
					
				$sql = "select * from iboss_crm_personal_info where  identification_no='".$_POST['identification_no']."' and  far_code='".$_POST['far_code_check']."' and prefix_unique_id='Inv' ";
				$result = $this->db->query($sql);
				$data->unique_id = $result->row()->unique_id;
							
							if(!empty($data->unique_id))
							{
							$this->session->set_flashdata('msg', 'Client  NRIC Number Already Added Same Consultant');
							redirect( "iboss_acc_master_crm_info/crm_personal_info/".$unique_id."/".$acc_type."/".$acc_row_id);		
							}
						
					
				}
				//FARCode
				
				
				
				//FARCode
				
				if($_POST['nationality_id'] == '3')
				 {
					$_POST['citizenship']=''; 
					$_POST['fin_no']='';
				 }
				 
				 if($_POST['citizenship'] == '3')
				 {
					$_POST['fin_no']=''; 
				 } 
				
				$_POST['id'] = $id;
				$_POST['dob']=sg2iso($_POST['dob']);
				$_POST['copy_parent_id']='';
				$_POST['nric_name'] = ucwords($_POST['nric_name']);
				$_POST['preferred_name'] = ucwords($_POST['preferred_name']);
				//$this->Crm_personal_info_model->set( $_POST ); 		
				//iboss_master_crm_index($unique_id, 'crm_personal_info', 'edit');
		      /**************Kanagaraj*/
			  	if($_POST['nric_name'] !='')
                {		  
					if($this->uri->segment('4') != 'view')
					{
						$_POST = array_map("trim", $_POST);
					$this->Crm_personal_info_model->set( $_POST ); 
					iboss_master_crm_index($unique_id, 'crm_personal_info', 'edit');

					$this->db->query("CALL sp_iboss_master_crm_update ('crm_personal_info' , '$unique_id' , 'Update')");
										 
					}	
			    }
			   	   
			   
			    // //update_log							
				// $this->db->crm_table_audit_update("iboss_crm_personal_info",$_POST,'unique_id', 'faiths','insert');
				// //End
				
						     
				
				/******************************************************** update CRM Info******************/
				if($this->session->userdata('edit_crm_acc'))
				{
				     $edit_crm_type_acc=$this->session->userdata('edit_crm_type_acc');
                
													switch($edit_crm_type_acc){
													    case "LI":
														$ctype='li';
														$ctype1='iboss_acc_li_client_info_id';
														break;
													    case "GI":
													   	$ctype='gi';
														$ctype1='iboss_acc_gi_client_info_id';
														break;
														case "GROUP":
														$ctype='group';
														$ctype1='iboss_acc_group_client_info_id';
														break;
														case "OTHER":
														$ctype='other_services';
														$ctype1='iboss_acc_other_services_client_info_id';
														break;
														case "INV":
														$ctype='inv';
														$ctype1='iboss_acc_client_id';
														break;
													
													}				
					
					unset($_POST['id']);
				$this->refer_acc_crm_save('iboss_acc_'.$ctype.'_crm_personal_info',$unique_id,$ctype1,$this->session->userdata('edit_crm_acc'),$_POST,$edit_crm_type_acc);
				
				}
				
				/******************************************************** End update CRM Info******************/
				
				if(isset($_POST['savenext']))
				{
				$pass_tab = $_POST['tab_number'];
				if(empty($_POST['tab_number']))
				{
				$pass_tab = 'crm_contact_info';
				}
				
				redirect( "iboss_master_crm_info/".$pass_tab."/".$unique_id);
					
				}else{
					                    if($this->session->userdata('refer_url_page'))
										{
											
										    redirect($this->session->userdata('refer_url_page'));	
										}
					

				redirect( "iboss_master_crm_info/crm_personal_info/".$unique_id );					
				// echo "<script type='javascript/text'>";
				// echo "alert('There are no fields to generate a report');"
				// echo "window.location.href = '" . base_url() . "iboss_master_crm_info/crm_personal_info/".$unique_id."';"
				// echo "</script>";
				

				}
			}
			
		}
		
	}


	/**************************** Exists Client Check Based on Name*************/
	function exists_client_check()
	{

		$exists_name  = $this->iboss_read->query("SELECT * FROM iboss_crm_personal_info WHERE  nric_name='".$_POST['name']."' and  far_code='".$_POST['far_code']."' and prefix_unique_id='Inv'");
		$exists_result = $exists_name->result();
		
		echo $exists_result[0]->nric_name;
	}

	/**************************** End the Function ***************************/

	
//Start Corporate Personal Info
function crm_corporate_personal_info($unique_id=null) 
{ 
	    
		//if(isset($_POST['cancel'])) { 
		
		//redirect( "iboss_master_crm_info/authorised_person_info/".$data->corporate_unique); 
		
		//}
				//die();
		
		$data = $this->Crm_personal_info_model->init_data();
		$data->templates = array('datatables','datepicker','icheck','chosen','select2');
		
		//Common_data
		$data->main_crm_type="Auth";
		$data->crm_tab_type=9;
		$data->unique_id=$unique_id;
		//Common Data
		$data->corporate_unique=$this->session->userdata('auth_crm_unique_id');
		//$data->far_code=$this->session->userdata('redirect_name_far_code');
         
		//Selector Options
		//$data->country_id_options = array(""=>"-- Please Select The Country --");
		//$data->country_id_options = $this->_selector_options('Iboss_dict_country_model','id','name',array('id'=>'asc'));

		//$data->nationality_id_options = array(""=>"-- Please Select Nationality --");
		//$data->nationality_id_options = $this->_selector_options('Iboss_dict_nationality_model','id','name',array('id'=>'asc'),array('status'=>"Active"));

		//$data->race_id_options = array(""=>"-- Please Select Race --");
		//$data->race_id_options = $this->_selector_options('Iboss_dict_race_model','id','name',array('id'=>'asc'),array('status'=>"Active"));

		//$data->religion_id_options = array(""=>"-- Please Select Religion --");
		//$data->religion_id_options = $this->_selector_options('Iboss_dict_religion_model','id','name',array('id'=>'asc'),array('status'=>"Active"));
     	//End 
		
		
		$data->nationality_id_options = array(""=>"Select an Option");
		$nationality_id = $this->_selector_options('Iboss_dict_nationality_model', 'id', 'name', array('id' => "asc"),array('status'=>"Active"));
        foreach ($nationality_id as $key => $val) {
            $data->nationality_id_options[$key] = ucwords(strtolower($val));
			
        }
		
		$data->preferred_language_id_options = array(""=>"Select an Option");
		$preferred_language_id = $this->_selector_options('Iboss_dict_preferred_language_model', 'id', 'name', array('id' => "asc"),array('status'=>"Active"));
        foreach ($preferred_language_id as $key => $val) {
            $data->preferred_language_id_options[$key] = ucwords(strtolower($val));
			
        }
		
		
		
		$data->country_id_options = array(""=>"Select an Option");
		$country_id = $this->_selector_options('Iboss_dict_country_model', 'id', 'name', array('id' => "asc"),array('status'=>"Active"));
        foreach ($country_id as $key => $val) {
            $data->country_id_options[$key] = ucwords(strtolower($val));
			
        }
		
		$data->race_id_options = array(""=>"Select an Option");
		$race_id = $this->_selector_options('Iboss_dict_race_model', 'id', 'name', array('id' => "asc"),array('status'=>"Active"));
        foreach ($race_id as $key => $val) {
            $data->race_id_options[$key] = ucwords(strtolower($val));
			
        }
		
		//new add dictionary		
		$data->salutation_options = array(""=>"Select an Option");
		$salutation_id = $this->_selector_options('Iboss_dict_salutation_model', 'id', 'name', array('id' => "asc"),array('status'=>"Active"));
        foreach ($salutation_id as $key => $val) {
            $data->salutation_options[$key] = ucwords(strtolower($val));
			
        }
		
		$data->gender_options = array(""=>"Select an Option");
		$gender_id = $this->_selector_options('Iboss_dict_gender_model', 'id', 'name', array('id' => "asc"),array('status'=>"Active"));
        foreach ($gender_id as $key => $val) {
            $data->gender_options[$key] = ucwords(strtolower($val));
        }
		
		$data->marital_status_options = array(""=>"Select an Option");
		$marital_status_id = $this->_selector_options('Iboss_dict_marital_status_model', 'id', 'name', array('id' => "asc"),array('status'=>"Active"));
        foreach ($marital_status_id as $key => $val) {
            $data->marital_status_options[$key] = ucwords(strtolower($val));
        }
		
		$data->entry_pass_options = array(""=>"Select an Option");
		$entry_pass_id = $this->_selector_options('Iboss_dict_entry_pass_model', 'id', 'name', array('id' => "asc"),array('status'=>"Active"));
        foreach ($entry_pass_id as $key => $val) {
            $data->entry_pass_options[$key] = ucwords(strtolower($val));
        }
//new end dictionary				
		
        
		$data->religion_id_options = array(""=>"Select an Option");
		$religion_id = $this->_selector_options('Iboss_dict_religion_model', 'id', 'name', array('id' => "asc"),array('status'=>"Active"));
        foreach ($religion_id as $key => $val) {
            $data->religion_id_options[$key] = ucwords(strtolower($val));
			
        }

		//NRIC Name
		$data->nric_name_options = $this->_selector_options('Crm_personal_info_model','id','nric_name',array('id'=>'asc'),array('status'=>"Active",'relationship'=>"self",'delete_log'=>"False"));
        //End 
		
		
		$data->far_id_options = array("" => "-- Select FAR --");
        $far_id = $this->_selector_farcode();
        foreach ($far_id as $key => $val) {
            $data->far_id_options[$key] = $val;
        }
		
		
		
		$rec = $this->Crm_corporate_info_model->retrieve( array( "unique_id" => $data->corporate_unique ) );
		$data->business_name_display=$rec[0]->business_name;
	    $data->corp_far_code=$rec[0]->far_code;
		
		
		
		if(!empty($unique_id)){
			
		$record = $this->Crm_personal_info_model->retrieve( array( "unique_id" => $unique_id ) );
		$data->corporate_unique=$record[0]->corporate_unique_id;
		$id=$record[0]->id;
		
		$record[0]->dob=iso2sg($record[0]->dob);
		$record[0]->last_birth_date=$this->chek_the_name($record[0]->unique_id,'','r4');
		$record[0]->next_birth_date= $this->chek_the_name($record[0]->unique_id,'','r5');
		
		$this->_nitro_send_post_to_view($record[0],$data);
		
	    $rec = $this->Crm_corporate_info_model->retrieve( array( "unique_id" => $data->corporate_unique ) );
		$data->business_name_display=$rec[0]->business_name;
		$data->corp_far_code=$rec[0]->far_code;
		}
		
		
		if(empty($unique_id))
		{
			if ( empty( $_POST ) ) {
			return $this->load->view( "iboss_master_crm/iboss_crm_corporate_personal_info_add_edit", $data );
			}else {
				$this->_nitro_set_rules();
				$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
				if ( $this->form_validation->run() == false ) {
					$this->_nitro_send_post_to_view( $_POST, $data );
					return $this->load->view( "iboss_master_crm/iboss_crm_corporate_personal_info_add_edit", $data );
				}
				
				        $sql = "select * from iboss_crm_personal_info where  identification_no='".$_POST['identification_no']."' and  far_code='".$_POST['far_code']."' and prefix_unique_id='Auth' ";
				        $result = $this->db->query($sql);
				        $data->unique_id = $result->row()->unique_id;
						if((empty($data->unique_id)) or(empty($_POST['identification_no'])))
						{
						if($_POST['nationality_id'] == '3')
							 {
								$_POST['citizenship']=''; 
								$_POST['fin_no']='';
							 }
				 
							if($_POST['citizenship'] == '3')
							{
							$_POST['fin_no']=''; 
							}
							
						
						
			                $_POST['dob']=sg2iso($_POST['dob']);
							$_POST['relationship']=$_POST['relationship_to_corporate'];
							$_POST['prefix_unique_id']="Auth";
							$_POST['date_time']=current_date_time();							
				            $insert_id=$this->Crm_personal_info_model->set( $_POST );							
				
							$sum_value = 000000 + $insert_id;

							$make_unique_id = str_pad($sum_value, 6, '0', STR_PAD_LEFT);
                 
				             
				            //Update Unquie id
							 $_POST_UNQ['unique_id'] = 'Auth'.$make_unique_id ;
							 $_POST_UNQ['corporate_unique_id'] = $this->session->userdata('auth_crm_unique_id');
							 $_POST_UNQ['far_code'] =$data->corp_far_code;
							 $this->db->where('id', $insert_id);
							 $this->db->update('iboss_crm_personal_info',$_POST_UNQ);
							//End Client Info
							//$Insert_val=$this->db->insert_id();	
							
							//$this->db->crm_table_audit_insert("iboss_crm_personal_info",array("unique_id" =>$this->session->userdata('auth_crm_unique_id')),$this->session->userdata('name'),'insert');
							
							
						
                          
							if(isset($_POST['savenext']))
							{
							redirect( "iboss_master_crm_info/crm_contact_info/".$_POST_UNQ['unique_id']);	
								
							}else{
							//$this->session->set_flashdata('msg', 'Thank You.Added Or Updated Information Successfully');
							redirect( "iboss_master_crm_info/crm_corporate_personal_info/".$_POST_UNQ['unique_id']); 
							
							}
							
						}else{
							
						$this->session->set_flashdata('msg', 'Thank You.Client NRIC Number Already Added Same Consultant');
				        redirect( "iboss_master_crm_info/index" );
						}
						//End Condition	
						
				
				
			}
			
		}else
		{
			if ( empty( $_POST ) ) {
				return $this->load->view( "iboss_master_crm/iboss_crm_corporate_personal_info_add_edit", $data );
			}else 
			{
				
				
				$this->_nitro_set_rules();
				if ( $this->form_validation->run() == false ) {
					$this->_nitro_send_post_to_view( $_POST, $data );
					return $this->load->view( "iboss_master_crm/iboss_crm_corporate_personal_info_add_edit", $data );
				}
				
				if($_POST['nationality_id'] == '3')
							 {
								$_POST['citizenship']=''; 
								$_POST['fin_no']='';
							 }
				 
							if($_POST['citizenship'] == '3')
							{
							$_POST['fin_no']=''; 
							}
							
				unset($_POST['far_code']);
				$_POST['id'] = $id;
				$_POST['dob']=sg2iso($_POST['dob']);
				$_POST['relationship']=$_POST['relationship_to_corporate'];
				$this->Crm_personal_info_model->set( $_POST ); 
				
				
				if(isset($_POST['savenext']))
				{
				$pass_tab = $_POST['tab_number'];
				if(empty($_POST['tab_number']))
				{
				$pass_tab = 'crm_contact_info';
				}				
				redirect( "iboss_master_crm_info/".$pass_tab."/".$unique_id);	
					
				}
				else
				{
				//$this->session->set_flashdata('msg', 'Thank You.Added Or Updated Information Successfully');
				redirect( "iboss_master_crm_info/crm_corporate_personal_info/".$unique_id); 
				
				}
			}
			
		}
		
	}

	
	
// 	function ($unique_id=null) { 
		
		
// 		$data = $this->Crm_personal_info_model->init_data();
// 		$data->templates = array('datatables','datepicker','icheck','chosen','select2');
		
		
// 		//Common Data
// 		 $data->unique_id=$unique_id;
// 		$data->main_crm_type=unqiue_id_spilit($unique_id);
// 		$data->crm_tab_type=8;
//         $data->title_corp='';
// 		if($data->main_crm_type=='Corp')
// 		{
// 			$data->title_corp='Corp';
// 		}
// 		//End Common Data
		
//             $this->session->set_userdata('auth_crm_unique_id',$data->unique_id);
			

// 		//Selector Options
// 		//$data->country_id_options = array(""=>"-- Please Select The Country --");
// 		$data->country_id_options = $this->_selector_options('Iboss_dict_country_model','id','name',array('id'=>'asc'));

// 		//$data->nationality_id_options = array(""=>"-- Please Select Nationality --");
// 		$data->nationality_id_options = $this->_selector_options('Iboss_dict_nationality_model','id','name',array('id'=>'asc'),array('status'=>"Active"));

// 		//$data->race_id_options = array(""=>"-- Please Select Race --");
// 		$data->race_id_options = $this->_selector_options('Iboss_dict_race_model','id','name',array('id'=>'asc'),array('status'=>"Active"));
		
// //new add dictionary				
// 		$data->salutation_options = $this->_selector_options('Iboss_dict_salutation_model', 'id', 'name', array('id' => "asc"),array('status'=>"Active"));        
		
		
// 		$data->gender_options = $this->_selector_options('Iboss_dict_gender_model', 'id', 'name', array('id' => "asc"),array('status'=>"Active"));
        
		
// 		$data->marital_status_options = $this->_selector_options('Iboss_dict_marital_status_model', 'id', 'name', array('id' => "asc"),array('status'=>"Active"));
		
		
// 		$data->entry_pass_options = $this->_selector_options('Iboss_dict_entry_pass_model', 'id', 'name', array('id' => "asc"),array('status'=>"Active"));
        
// //new end dictionary				

// 		//$data->religion_id_options = array(""=>"-- Please Select Religion --");
// 		$data->religion_id_options = $this->_selector_options('Iboss_dict_religion_model','id','name',array('id'=>'asc'),array('status'=>"Active"));
//      	//End 
// 		$data->auth_person_info = $this->Crm_personal_info_model->retrieve( array( "corporate_unique_id" => $unique_id ) );
		
// 		if(!empty($unique_id)){
			
// 		//$record = $this->Crm_personal_info_model->retrieve( array( "unique_id" => $unique_id ) );
// 		$record =  $this->Crm_corporate_info_model->retrieve( array( "unique_id" => $unique_id ) );	
// 		$farcode = $record[0]->far_code;
// 		$id=$record[0]->id;
// 		$this->_nitro_send_post_to_view($record[0],$data);
		
		
		
				
// 		}
// 		$data->primary_crm_contact =function($unique_id,$field_name){
				
//                 $sql = "select * from iboss_crm_contact_info where  unique_id='".$unique_id."'";
// 				$result = $this->db->query($sql);
// 				$li_result = $result->row()->$field_name;
				
// 				return  $li_result;
				
// 				};
		
		
		
// 		if(empty($unique_id))
// 		{
			
			
// 		}else{
// 			if ( empty( $_POST ) ) {
// 				return $this->load->view( "iboss_master_crm/iboss_crm_authorised_person_info_add_edit", $data );
// 			}else {
// 				$this->_nitro_set_rules();
// 				if ( $this->form_validation->run() == false ) {
// 					$this->_nitro_send_post_to_view( $_POST, $data );
// 					return $this->load->view( "iboss_master_crm/iboss_crm_authorised_person_info_add_edit", $data );
// 				}
// 				$_POST['id'] = $id;
// 				$this->Crm_personal_info_model->set( $_POST );
				
// 				if(isset($_POST['savenext']))
// 				{
// 				redirect( "iboss_master_crm_info/crm_contact_info/".$unique_id);	
					
// 				}else{

// 						if(isset($_POST['save_account_summary'])) {
// 							redirect( "iboss_master_crm_info/authorized_info/".$unique_id."/".$farcode);
// 						} else {
// 						$this->session->set_flashdata('msg', 'Thank You.Added Or Updated Information Successfully');
// 						redirect( "iboss_master_crm_info/index" );
// 						}
				
// 				}
				

// 			}
			
// 		}
		
// 	}

	function view_auth_info()
	{
		
		                        if(!empty($_POST['row_id']))
								{			
									$res = $this->Crm_personal_info_model->retrieve(['id'=>$_POST['row_id'],'delete_log'=>"False"]);
									$index =json_encode($res);
									$str = trim($index,']');
									echo trim($str,'[');
									
								}
	}
	
	
	
//End Corporate Personal Info




	
	
	function crm_corporate_info($unique_id=null) { 
	
		
		$data = $this->Crm_corporate_info_model->init_data();
		$data->templates = array('datatables','datepicker','icheck','chosen','select2');
		
		
		//Common_data
		$data->main_crm_type="Corp";
		$data->crm_tab_type=7;
		$data->unique_id=$unique_id;
		$data->title_corp='Corp';
		//Common Data
		

		//Importantant 
		          $data->far_code=trim($this->session->userdata('redirect_name_far_code'));
                  $data->business_name=trim($this->session->userdata('refer_client_name'));
				  
	    //End 
	  
		
		
		//Selector Options
		//$data->country_id_options = array(""=>"-- Please Select The Country --");
		$data->country_id_options = $this->_selector_options('Iboss_dict_country_model','id','name',array('id'=>'asc'));

		//$data->nationality_id_options = array(""=>"-- Please Select Nationality --");
		$data->nationality_id_options = $this->_selector_options('Iboss_dict_nationality_model','id','name',array('id'=>'asc'),array('status'=>"Active"));

		//$data->race_id_options = array(""=>"-- Please Select Race --");
		$data->race_id_options = $this->_selector_options('Iboss_dict_race_model','id','name',array('id'=>'asc'),array('status'=>"Active"));
		
//new add dictionary				
		$data->salutation_options = $this->_selector_options('Iboss_dict_salutation_model', 'id', 'name', array('id' => "asc"),array('status'=>"Active"));        
		
		
		$data->gender_options = $this->_selector_options('Iboss_dict_gender_model', 'id', 'name', array('id' => "asc"),array('status'=>"Active"));
        
		
		$data->marital_status_options = $this->_selector_options('Iboss_dict_marital_status_model', 'id', 'name', array('id' => "asc"),array('status'=>"Active"));
		
		
		$data->entry_pass_options = $this->_selector_options('Iboss_dict_entry_pass_model', 'id', 'name', array('id' => "asc"),array('status'=>"Active"));
        
//new end dictionary				

		//$data->religion_id_options = array(""=>"-- Please Select Religion --");
		$data->religion_id_options = $this->_selector_options('Iboss_dict_religion_model','id','name',array('id'=>'asc'),array('status'=>"Active"));
     	//End 
		
		$data->nature_of_business_options = array(""=>"-- Select The Nature Of Business--");
		$nature_of_business_id = $this->_selector_options('Iboss_dict_nature_of_business_model', 'id', 'name', array('id' => "asc"),array('status'=>"Active"));
        foreach ($nature_of_business_id as $key => $val) {
            $data->nature_of_business_options[$key] = ucwords(strtolower($val));
			
        }
		
		
		$data->far_id_options = array("" => "-- Select FAR --");
        $far_id = $this->_selector_farcode();
        foreach ($far_id as $key => $val) {
            $data->far_id_options[$key] = $val;
        }
		
		
		if(!empty($unique_id)){
			
		$record = $this->Crm_corporate_info_model->retrieve( array( "unique_id" => $unique_id ) );
		$record[0]->biz_reg_date=iso2sg($record[0]->biz_reg_date);
		$id=$record[0]->id;
		$record_copy_parent = $this->Crm_corporate_info_model->retrieve( array( "unique_id" => $record[0]->copy_parent_id ) );
		$record[0]->copy_parent_farcode=$record_copy_parent[0]->far_code;
		$record[0]->autosync_fileds = explode("," , $record[0]->autosync_fileds);
		
		$this->_nitro_send_post_to_view($record[0],$data);
		
		$sql_previous="select * from iboss_crm_previous_client_name where delete_log='False' AND unique_id ='".$unique_id."'";
		$result = $this->db->query($sql_previous);
		$data->previous_client_name_data = $result->result();
		
		$sql_consultant = "select role_id from ums_role_permissions where role_id ='".$this->session->userdata(role_id)."' AND data like '%iboss_consultant_change%'";
		$result_consultant = $this->db->query($sql_consultant);
		$data->role_id = $result_consultant->row()->role_id;
	
		}
		
		
		
		if(empty($unique_id))
		{
			if ( empty( $_POST ) ) {
			return $this->load->view( "iboss_master_crm/iboss_crm_corporate_info_add_edit", $data );
			}else {
				$this->_nitro_set_rules();
				$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
				if ( $this->form_validation->run() == false ) {
					$this->_nitro_send_post_to_view( $_POST, $data );
					return $this->load->view( "iboss_master_crm/iboss_crm_corporate_info_add_edit", $data );
				}
				            
							$_POST['biz_reg_date'] =sg2iso($_POST['biz_reg_date']); 
							$_POST['date_time']=current_date_time();
							$_POST = array_map("trim", $_POST);
				            $insert_id=$this->Crm_corporate_info_model->set( $_POST );
							
							$sum_value = 000000 + $insert_id;
							$make_unique_id = str_pad($sum_value, 6, '0', STR_PAD_LEFT);
                 
				             
				            //Update Unquie id
							 $_POST_UNQ['unique_id'] = 'Corp'.$make_unique_id ;
							 
							 $this->db->where('id', $insert_id);
							 $this->db->update('iboss_crm_corporate_info',$_POST_UNQ);
							//End Client Info
							$this->db->query("CALL sp_iboss_master_crm_update ('crm_corporate_info' , '".$_POST_UNQ['unique_id']."' , 'Insert')");

							iboss_master_crm_index($_POST_UNQ['unique_id'], 'crm_corporate_info', 'new');
							

							
						
						    //iboss Client Info table Store
							
							/*****************AML Seach**************/
							 $this->client_details_unique_id($_POST_UNQ['unique_id']);
							 /***********End AML Seach ****************/
							
							 $refer_url_page=$this->session->userdata('refer_url_page');
							 $refer_policy_owner_type =$this->session->userdata('refer_policy_owner_type');
							 $refer_iboss_client_info_table =$this->session->userdata('refer_iboss_client_info_table');
							 
							 if(!empty($refer_url_page) and (!empty($refer_iboss_client_info_table)))
							 {              
								     
									 if($refer_iboss_client_info_table=='iboss_acc_li_client_info')
									 {
                                                    $refer_data['iboss_crm_unique_id'] = $_POST_UNQ['unique_id'];
													$refer_data['client_type'] =(!empty($refer_policy_owner_type) and $refer_policy_owner_type=='owner')?"Joint":"Life Assured";
													$refer_data['far_code'] = $this->session->userdata('redirect_name_far_code'); 
													$refer_data['relationship'] = $this->session->userdata('refer_relationship');
													$refer_data['uuid'] = $this->session->userdata('iboss_acc_li_client_info_uuid');
													$refer_data['iboss_acc_li_policy_info_id'] = $this->session->userdata('iboss_life_policy_id');
													$this->db->insert('iboss_acc_li_client_info', $refer_data);	
													$this->session->set_userdata('acc_crm_new_client',$_POST_UNQ['unique_id']);
													$this->session->unset_userdata('refer_iboss_client_info_table');
													
                                     }

										if($refer_iboss_client_info_table=='iboss_acc_gi_client_info')
									 {
                                                    $refer_data['iboss_crm_unique_id'] = $_POST_UNQ['unique_id'];
													$refer_data['client_type'] =(!empty($refer_policy_owner_type) and $refer_policy_owner_type=='owner')?"Joint":"Life Assured";
													$refer_data['far_code'] = $this->session->userdata('redirect_name_far_code'); 
													$refer_data['relationship'] = $this->session->userdata('refer_relationship');
													$refer_data['uuid'] = $this->session->userdata('iboss_acc_gi_client_info_uuid');
													$refer_data['iboss_acc_gi_policy_info_id'] = $this->session->userdata('iboss_life_policy_id');
													$this->db->insert('iboss_acc_gi_client_info', $refer_data);	
													$this->session->set_userdata('acc_crm_new_client_gi',$_POST_UNQ['unique_id']);
													$this->session->unset_userdata('refer_iboss_client_info_table');
													
													
                                     }

									if($refer_iboss_client_info_table=='iboss_acc_group_client_info')
									 {
                                                    $refer_data['iboss_crm_unique_id'] = $_POST_UNQ['unique_id'];
													$refer_data['client_type'] =(!empty($refer_policy_owner_type) and $refer_policy_owner_type=='owner')?"Joint":"Life Assured";
													$refer_data['far_code'] = $this->session->userdata('redirect_name_far_code'); 
													$refer_data['relationship'] = $this->session->userdata('refer_relationship');
													$refer_data['uuid'] = $this->session->userdata('iboss_acc_group_client_info_uuid');
													$refer_data['iboss_acc_group_policy_info_id'] = $this->session->userdata('iboss_life_policy_id');
													$this->db->insert('iboss_acc_group_client_info', $refer_data);
													$this->session->set_userdata('acc_crm_new_client_group',$_POST_UNQ['unique_id']);													
													$this->session->unset_userdata('refer_iboss_client_info_table');
													
                                     }
									 
									 if($refer_iboss_client_info_table=='iboss_acc_other_services_client_info')
									 {
                                                    $refer_data['iboss_crm_unique_id'] = $_POST_UNQ['unique_id'];
													$refer_data['client_type'] =(!empty($refer_policy_owner_type) and $refer_policy_owner_type=='owner')?"Joint":"Life Assured";
													$refer_data['far_code'] = $this->session->userdata('redirect_name_far_code');
													$refer_data['relationship'] = $this->session->userdata('refer_relationship');
													$refer_data['uuid'] = $this->session->userdata('iboss_acc_other_services_client_info_uuid');
													$refer_data['iboss_acc_other_services_info_id'] = $this->session->userdata('crm_save_details');
													$this->db->insert('iboss_acc_other_services_client_info', $refer_data);	
													$this->session->unset_userdata('refer_iboss_client_info_table');
													$this->session->set_userdata('acc_crm_new_client_other',$_POST_UNQ['unique_id']);
													
                                     }

									 		
									 
									 
									 
									 
									 if($refer_iboss_client_info_table=='iboss_acc_inv_client_info')
									 {
										 
													$this->load->helper("copy_paste_crm_info");
                                                    $refer_data['iboss_crm_unique_id'] = $_POST_UNQ['unique_id'];
													$refer_data['client_type'] ='Joint';
													$refer_data['far_code'] = $this->session->userdata('redirect_name_far_code'); 
													$refer_data['dob']=$_POST['dob'];
													$refer_data['status']='Active';
													$refer_data['iboss_crm_id']=$insert_id;
													$refer_data['relationship'] = $this->session->userdata('refer_relationship');
													$refer_data[$this->session->userdata('main_name')] = $this->session->userdata('main_id');

													$this->db->insert('iboss_acc_inv_client_info', $refer_data);	
													$last_insert_id=$this->db->insert_id();
													
													save_into_acc_crm($_POST_UNQ['unique_id'],'iboss_acc_inv_client_info','Joint',$last_insert_id,$this->session->userdata('main_name'),$this->session->userdata('main_id'));
												
													$this->session->unset_userdata('refer_iboss_client_info_table');
													
													
                                     }	
									 
                                      									 
								
							 }
							 
							 
							 //End Client Info table Store
							 
						
                          
				if(isset($_POST['savenext']))
				{
					
				                  	$refer_url_page=$this->session->userdata('refer_url_page');
										if(!empty($refer_url_page)){
											$client_type=$refer_data['client_type'];
											if($refer_data['client_type']=='Life Assured'){
											 $client_type='Life Insured';	
											}
										    $this->session->set_userdata('refer_flash', "Thank You.Added New $client_type Client Successfully");
										   
										}
					
				redirect( "iboss_master_crm_info/crm_contact_info/".$_POST_UNQ['unique_id']);	
					
				}else{
					
					
					                $refer_url_page=$this->session->userdata('refer_url_page');
										if(!empty($refer_url_page)){
											$client_type=$refer_data['client_type'];
											if($refer_data['client_type']=='Life Assured'){
											 $client_type='Life Insured';	
											}
										    $this->session->set_userdata('refer_flash', "Thank You.Added New $client_type Client Successfully");
										    redirect($this->session->userdata('refer_url_page'));	
										}
					
				//$this->session->set_flashdata('msg', 'Thank You.Added Or Updated Information Successfully');
				redirect( "iboss_master_crm_info/crm_corporate_info/".$_POST_UNQ['unique_id'] );
				
				}
				
				
				
			}
			
		}else{
			if ( empty( $_POST ) ) {
				return $this->load->view( "iboss_master_crm/iboss_crm_corporate_info_add_edit", $data );
			}else {
				$this->_nitro_set_rules();
				if ( $this->form_validation->run() == false ) {
					$this->_nitro_send_post_to_view( $_POST, $data );
					return $this->load->view( "iboss_master_crm/iboss_crm_corporate_info_add_edit", $data );
				}
				//Update 
				
				/* if(empty($_POST['copy_parent_id']))
				{
				unset($_POST['far_code_edit']);
				} */
				
				
				$_POST['biz_reg_date'] =sg2iso($_POST['biz_reg_date']); 
				$_POST['copy_parent_id']='';
				$_POST['id'] = $id;
				$_POST = array_map("trim", $_POST);
				$this->Crm_corporate_info_model->set( $_POST );

				
				
				iboss_master_crm_index($unique_id, 'crm_corporate_info', 'edit');

				$this->db->query("CALL sp_iboss_master_crm_update ('crm_corporate_info' , '$unique_id' , 'Update')");
				
				if(empty($_POST['copy_parent_id']))
				{
				unset($_POST['far_code_edit']);
				}
				
				
				/******************************************************** update CRM Info******************/
				if($this->session->userdata('edit_crm_acc'))
				{
				     $edit_crm_type_acc=$this->session->userdata('edit_crm_type_acc');
                
													switch($edit_crm_type_acc){
													    case "LI":
														$ctype='li';
														$ctype1='iboss_acc_li_client_info_id';
														break;
													    case "GI":
													   	$ctype='gi';
														$ctype1='iboss_acc_gi_client_info_id';
														break;
														case "GROUP":
														$ctype='group';
														$ctype1='iboss_acc_group_client_info_id';
														break;
														case "OTHER":
														$ctype='other_services';
														$ctype1='iboss_acc_other_services_client_info_id';
														break;
														case "INV":
														$ctype='inv';
														$ctype1='iboss_acc_client_id';
														break;
													
													}				
					
					unset($_POST['id']);
				$this->refer_acc_crm_save('iboss_acc_'.$ctype.'_crm_corporate_info',$unique_id,$ctype1,$this->session->userdata('edit_crm_acc'),$_POST,$edit_crm_type_acc);
				
				}
				
				/******************************************************** End update CRM Info******************/
				
				
				
				
				
				//End Update
				if(isset($_POST['savenext']))
				{
				redirect( "iboss_master_crm_info/crm_contact_info/".$unique_id);	
					
				}else{
				//$this->session->set_flashdata('msg', 'Thank You.Added Or Updated Information Successfully');				
				redirect( "iboss_master_crm_info/crm_corporate_info/".$unique_id );
				
				}
				
				
			}
			
		}
		
	}

	
	
	

	
//End New Design
	

	function crm_contact_info($unique_id=null) { 
	
		$data = $this->Crm_contact_info_model->init_data();
		$data->templates = array('datatables','datepicker','icheck','chosen','select2');
		
		//Common Data
		$data->unique_id=$unique_id;
		$data->main_crm_type=unqiue_id_spilit($unique_id);
		$data->crm_tab_type=2;
        $data->title_corp='';
		if($data->main_crm_type=='Corp')
		{
			$data->title_corp='Corp';
		}
		$data->corporate_uniques=$this->session->userdata('auth_crm_unique_id');
		//End Common Data
		
		
		//Selector Options
		//$data->overseas_country_id_options = array(""=>"-- Select List --");
		$data->overseas_country_id_options = $this->_selector_overseas_country();
		
		
		$data->country_id_options = $this->_selector_options('Iboss_dict_country_model','id','name',array('id'=>'asc'));
		
		$data->phonecode_id_options = $this->_selector_phonecode('Iboss_dict_country_model','id','name',array('id'=>'asc'));

		
        
		 //**************************************************address_list*********************************/
		$data->contact_labels = $this->Crm_contact_info_model->get_field_comments();
		$data->enum_contact = $this->Crm_contact_info_model->get_enum();#enum data to be included
		//********************************************address_list**********************************/
		
		
		 //**************************************************address_list*********************************/
		$data->address_labels = $this->Crm_address_info_model->get_field_comments();
		$data->enum_address = $this->Crm_address_info_model->get_enum();#enum data to be included
		//********************************************address_list**********************************/
		
		$rec = $this->Crm_corporate_info_model->retrieve( array( "unique_id" => $data->corporate_uniques ) );
		$data->business_name_display=$rec[0]->business_name;
		
		//print_r($data->business_name_display);die();
		if(!empty($unique_id)){
			
	     $record = $this->Crm_contact_info_model->retrieve( array( "unique_id" => $unique_id ,'delete_log'=>'False') );
			
		$record[0]->primary_con_given_date=iso2sg($record[0]->primary_con_given_date);
    $record[0]->secondary_con_given_date=iso2sg($record[0]->secondary_con_given_date);
		$record[0]->home_con_given_date=iso2sg($record[0]->home_con_given_date);
		$record[0]->office_con_given_date=iso2sg($record[0]->office_con_given_date);
		
		$record[0]->primary_office_con_given_date=iso2sg($record[0]->primary_office_con_given_date);
		$record[0]->secondary_office_given_date=iso2sg($record[0]->secondary_office_given_date);
    $record[0]->primary_email_given_date=iso2sg($record[0]->primary_email_given_date);
    $record[0]->secondary_email_given_date=iso2sg($record[0]->secondary_email_given_date);
		$record[0]->contact_id = 'Contact-'.$record[0]->id;
		
		$address = $this->Crm_address_info_model->retrieve( array( "unique_id" => $unique_id ,'delete_log'=>'False') );
		
		  
		  
		  
		
		
		foreach($address as $row){
			
			
		             /*New add */
					 if(!empty($row->address_type))
					 {
						 
					    if($row->address_type =='residential')
						{
						$row->address_type='local_mail';	
						}
						if($row->address_type =='overseas')
						{
					      $row->address_type='overseas_mail';
						}
				        if($row->address_type =='mailing')
						{
					     $row->address_type='send_mail';
						}

            $record[0]->mailing_dnc=$row->mailing_dnc;      
            $record[0]->mailing_dnc_effect_date=iso2sg($row->mailing_dnc_effect_date);
					 }
					/*end*/	
					
					   /*New add */
					   if(!empty($row->send_mail))
					   {
							if($row->send_mail =='residential')
							{
							$row->send_mail='local_mail';	
							}
							if($row->send_mail =='overseas')
							{
							$row->send_mail ='overseas_mail';
							}
              
				       } 
					/*end*/	
			
			
			
			if($row->address_type=='local_mail'){
			$record[0]->postal_code_1=$row->postal_code;
			$record[0]->unit_1=$row->unit;				
			$record[0]->block_1=$row->block;		
			$record[0]->building_1=$row->building;				
			$record[0]->street_1=$row->street;				
			$record[0]->city_1=$row->city;
			$record[0]->state_1=$row->state;										
			$record[0]->country_id_1=$row->country_id;
			$record[0]->send_mail=$row->send_mail;
			$record[0]->address_id_1='local_mail_addrs-'.$row->id;
      }
			
			if($row->address_type=='overseas_mail'){
			$record[0]->postal_code_2=$row->postal_code;
			$record[0]->unit_2=$row->unit;				
			$record[0]->block_2=$row->block;		
			$record[0]->building_2=$row->building;				
			$record[0]->street_2=$row->street;				
			$record[0]->city_2=$row->city;
			$record[0]->state_2=$row->state;										
			$record[0]->country_id_2=$row->country_id;
			$record[0]->send_mail=$row->send_mail;
			$record[0]->address_id_2='overseas_mail_addrs-'.$row->id;
     	}
			
			if($row->address_type=='send_mail'){
			$record[0]->postal_code_3=$row->postal_code;
			$record[0]->unit_3=$row->unit;				
			$record[0]->block_3=$row->block;		
			$record[0]->building_3=$row->building;				
			$record[0]->street_3=$row->street;				
			$record[0]->city_3=$row->city;
			$record[0]->state_3=$row->state;										
			$record[0]->country_id_3=$row->country_id;
			$record[0]->send_mail=$row->send_mail;
			$record[0]->address_id_3='send_mail_addrs-'.$row->id;
			}
			
			// $record[0]->mailing_dnc=$row->mailing_dnc;     
   //    $record[0]->mailing_dnc_effect_date=iso2sg($row->mailing_dnc_effect_date);
			
			
			
		 }


		$this->_nitro_send_post_to_view($record[0],$data);
	     
		       if($data->main_crm_type=='Auth')
				{
				$record = $this->Crm_personal_info_model->retrieve( array( "unique_id" => $unique_id ) );
				$data->corporate_unique=$record[0]->corporate_unique_id;
				}
				
				$rec = $this->Crm_corporate_info_model->retrieve( array( "unique_id" => $data->corporate_uniques ) );
				$data->business_name_display=$rec[0]->business_name;		
		 
		}
		//print_r($_POST);
		//die();
		
		if(empty($unique_id))
		{
			
			
		}else{
			if ( empty( $_POST ) ) {
				return $this->load->view( "iboss_master_crm/iboss_crm_contact_info_add_edit", $data );
			}else {
				$this->_nitro_set_rules();
				if ( $this->form_validation->run() == false ) {
					$this->_nitro_send_post_to_view( $_POST, $data );
					return $this->load->view( "iboss_master_crm/iboss_crm_contact_info_add_edit", $data );
				}
             
				//Delete The Record
				//$this->db->where('unique_id', $unique_id);
			    //$this->db->delete('iboss_crm_contact_info');
				//End Delete Record	

				
				//Auth,Inv
				$_POST_CONTACT['primary_code']=$_POST['primary_code'];
				$_POST_CONTACT['primary_contact']=$_POST['primary_contact'];
				$_POST_CONTACT['primary_dnc']=$_POST['primary_dnc'];
				$_POST_CONTACT['primary_con_given_date']=sg2iso($_POST['primary_con_given_date']);


        $_POST_CONTACT['secondary_code']=$_POST['secondary_code'];
        $_POST_CONTACT['secondary_contact']=$_POST['secondary_contact'];
        $_POST_CONTACT['secondary_dnc']=$_POST['secondary_dnc'];
        $_POST_CONTACT['secondary_con_given_date']=sg2iso($_POST['secondary_con_given_date']);




				
				$_POST_CONTACT['home_code']=$_POST['home_code'];
				$_POST_CONTACT['home_contact']=$_POST['home_contact'];
				$_POST_CONTACT['home_dnc']=$_POST['home_dnc'];
				$_POST_CONTACT['home_con_given_date']=sg2iso($_POST['home_con_given_date']);
				
				$_POST_CONTACT['office_code']=$_POST['office_code'];				
				$_POST_CONTACT['office_contact']=$_POST['office_contact'];
				$_POST_CONTACT['office_contact_ext']=$_POST['office_contact_ext'];
				$_POST_CONTACT['office_dnc']=$_POST['office_dnc'];
				$_POST_CONTACT['office_con_given_date']=sg2iso($_POST['office_con_given_date']);
				//End 
				
				
				//Corporate
				$_POST_CONTACT['primary_office_code']=$_POST['primary_office_code'];
				$_POST_CONTACT['primary_office']=$_POST['primary_office'];
				$_POST_CONTACT['primary_office_dnc']=$_POST['primary_office_dnc'];
				$_POST_CONTACT['primary_office_con_given_date']=sg2iso($_POST['primary_office_con_given_date']);
				
				$_POST_CONTACT['secondary_office_code']=$_POST['secondary_office_code'];
				$_POST_CONTACT['secondary_office']=$_POST['secondary_office'];
				$_POST_CONTACT['secondary_office_dnc']=$_POST['secondary_office_dnc'];
				$_POST_CONTACT['secondary_office_given_date']=sg2iso($_POST['secondary_office_given_date']);
                //End Corporate
				 
				$_POST_CONTACT['primary_email']=$_POST['primary_email'];
        $_POST_CONTACT['primary_email_dnc'] = $_POST['primary_email_dnc'];
        $_POST_CONTACT['primary_email_given_date'] = sg2iso($_POST['primary_email_given_date']);
        $_POST_CONTACT['secondary_email']=$_POST['secondary_email'];
        $_POST_CONTACT['secondary_email_dnc'] = $_POST['secondary_email_dnc'];
        $_POST_CONTACT['secondary_email_given_date'] =sg2iso($_POST['secondary_email_given_date']);
				$_POST_CONTACT['unique_id']=$unique_id;	
				
				$_POST_CONTACT['date_time']=current_date_time();
				$get_contact_id = explode('-', $_POST['contact']);

				($get_contact_id[1]!='')?$_POST_CONTACT['id'] = $get_contact_id[1]:'';
				$this->Crm_contact_info_model->set( $_POST_CONTACT );
				
				
				
				/******************************************************** update CRM Info******************/
				if($this->session->userdata('edit_crm_acc'))
				{
				     $edit_crm_type_acc=$this->session->userdata('edit_crm_type_acc');
                
													switch($edit_crm_type_acc){
													    case "LI":
														$ctype='li';
														$ctype1='iboss_acc_li_client_info_id';
														break;
													    case "GI":
													   	$ctype='gi';
														$ctype1='iboss_acc_gi_client_info_id';
														break;
														case "GROUP":
														$ctype='group';
														$ctype1='iboss_acc_group_client_info_id';
														break;
														case "OTHER":
														$ctype='other_services';
														$ctype1='iboss_acc_other_services_client_info_id';
														break;
														case "INV":
														$ctype='inv';
														$ctype1='iboss_acc_client_id';
														break;
													
													}				
					
					
				$this->refer_acc_crm_save('iboss_acc_'.$ctype.'_crm_contact_info',$unique_id,$ctype1,$this->session->userdata('edit_crm_acc'),$_POST_CONTACT,$edit_crm_type_acc);
				
				}
				
				/******************************************************** End update CRM Info******************/
				
				
				
				
				
								
				//Delete The Record
				//$this->db->where('unique_id', $unique_id);
			    //$this->db->delete('iboss_crm_address_info');
				//End Delete Record	
                 
				
				for($i=1;$i<=3;$i++){
					
					
					if(!empty($_POST['postal_code_'.$i]))
					{    
				      /*New add */
					   if(!empty($_POST['address_type_'.$i]))
					   {
							if($_POST['address_type_'.$i] =='local_mail')
							{
							$_POST['address_type_'.$i]='residential';	
							}
							if($_POST['address_type_'.$i] =='overseas_mail')
							{
							  $_POST['address_type_'.$i]='overseas';
							}
							if($_POST['address_type_'.$i] =='send_mail')
							{
							 $_POST['address_type_'.$i]='mailing';
							}
					   }
					/*end*/	
					
					   /*New add */
					   if(!empty($_POST['send_mail']))
					   {
							if($_POST['send_mail'] =='local_mail')
							{
							$_POST['send_mail']='residential';	
							}
							if($_POST['send_mail'] =='overseas_mail')
							{
							  $_POST['send_mail']='overseas';
							}
				       } 
					/*end*/	
						
						$_POST_ADDRESS['postal_code']=$_POST['postal_code_'.$i];
						$_POST_ADDRESS['unit']=$_POST['unit_'.$i];
						$_POST_ADDRESS['block']=$_POST['block_'.$i];
						$_POST_ADDRESS['building']=$_POST['building_'.$i];
						$_POST_ADDRESS['street']=$_POST['street_'.$i];
						$_POST_ADDRESS['city']=$_POST['city_'.$i];
						$_POST_ADDRESS['state']=$_POST['state_'.$i];
						$_POST_ADDRESS['country_id']=$_POST['country_id_'.$i];
						$_POST_ADDRESS['address_type']=$_POST['address_type_'.$i];
						$_POST_ADDRESS['send_mail']=$_POST['send_mail'];
						$_POST_ADDRESS['mailing_dnc']=$_POST['mailing_dnc'];
						$_POST_ADDRESS['mailing_dnc_effect_date']=sg2iso($_POST['mailing_dnc_effect_date']);
						$_POST_ADDRESS['unique_id']=$unique_id;	
						$_POST_ADDRESS['date_time']=current_date_time();

						$get_address_id = explode('-', $_POST['address_'.$i]);
            
						($get_address_id[1]!='')?$_POST_ADDRESS['id'] = $get_address_id[1]:'';

						$this->Crm_address_info_model->set( $_POST_ADDRESS );
						$this->db->query("CALL sp_iboss_master_crm_update ('crm_contact_info' , '$unique_id' , 'Update')");	
						
			/******************************************************** update CRM Info******************/
				if($this->session->userdata('edit_crm_acc'))
				{
				     $edit_crm_type_acc=$this->session->userdata('edit_crm_type_acc');
                
													switch($edit_crm_type_acc){
													    case "LI":
														$ctype='li';
														$ctype1='iboss_acc_li_client_info_id';
														break;
													    case "GI":
													   	$ctype='gi';
														$ctype1='iboss_acc_gi_client_info_id';
														break;
														case "GROUP":
														$ctype='group';
														$ctype1='iboss_acc_group_client_info_id';
														break;
														case "OTHER":
														$ctype='other_services';
														$ctype1='iboss_acc_other_services_client_info_id';
														break;
														case "INV":
														$ctype='inv';
														$ctype1='iboss_acc_client_id';
														break;
													
													}				
					
					
				$this->refer_acc_crm_save('iboss_acc_'.$ctype.'_crm_contact_info',$unique_id,$ctype1,$this->session->userdata('edit_crm_acc'),$_POST_ADDRESS,$edit_crm_type_acc);
				
				}
				
				/******************************************************** End update CRM Info******************/
				
				
				
						
						
					}
					
				}
			
				
				

				
				if(isset($_POST['savenext']))
				{
						$pass_tab = $_POST['tab_number'];	//Corporate Info
						if($data->main_crm_type=='Corp')
						{	
							if(empty($pass_tab))
							{
								$pass_tab = 'crm_compliance_info';
							}
							redirect( "iboss_master_crm_info/".$pass_tab."/".$unique_id);
						}
					    //End Corporate Info
					    if(empty($pass_tab))
						{
							$pass_tab = 'crm_educational_info';
						}
						
						redirect( "iboss_master_crm_info/".$pass_tab."/".$unique_id);	
					
				}else{
					
					   //Auth Info
						if($data->main_crm_type=='Auth')
						{
							//$this->session->set_flashdata('msg', 'Thank You.Added Or Updated Information Successfully');
							redirect( "iboss_master_crm_info/crm_contact_info/".$unique_id);
						}
					    //End Auth Info
					    
						
						              $refer_url_page=$this->session->userdata('refer_url_page');
										if(!empty($refer_url_page)){
											$client_type=$refer_data['client_type'];
											if($refer_data['client_type']=='Life Assured'){
											 $client_type='Life Insured';	
											}
										    $this->session->set_userdata('refer_flash', "Thank You.Added New $client_type Client Successfully");
										    redirect($this->session->userdata('refer_url_page'));	
										}
						
				
				       redirect( "iboss_master_crm_info/crm_contact_info/".$unique_id);
				
				}
				
				
				//$this->Crm_contact_info_model->set( $_POST );
				//redirect( "iboss_master_crm_info/index" );
			}
			
		}
		
	}
	
	
	
//End New Design	


	
	function crm_educational_info($unique_id=null) { 
	
		
		   
		
		$data = $this->Iboss_crm_edu_and_emp_info_model->init_data();
		$data->templates = array('datatables','datepicker','icheck','chosen','select2');
		
		
				
		//Common Data
		$data->unique_id=$unique_id;
		$data->main_crm_type=unqiue_id_spilit($unique_id);
		$data->crm_tab_type=3;
        $data->title_corp='';
		if($data->main_crm_type=='Corp')
		{
			$data->title_corp='Corp';
		}
		$data->corporate_uniques=$this->session->userdata('auth_crm_unique_id');
		//End Common Data
		
		
        
		//Selector Options
		//$data->country_id_options = array(""=>"-- Please Select The Country --");
		//$data->country_id_options = $this->_selector_options('Iboss_dict_country_model','id','name',array('id'=>'asc'));

		//$data->occupation_id_options = $this->_selector_options('Iboss_dict_occupation_model','id','name',array('id'=>'asc'));
	
		///$data->qualification_id_options = $this->_selector_options('Iboss_dict_qualification_model','id','name',array('id'=>'asc'));
		
		//$data->education_id_options = $this->_selector_options('Crm_educational_info_model','id','name',array('id'=>'asc'));
		
		//$data->source_of_fund_options = $this->_selector_options('Iboss_dict_fund_source_model','id','name',array('id'=>'asc'));
		
		$data->nature_of_business_options = array("" => "Select Option");
        $nature_of_business = $this->_selector_options('iboss_dict_nature_of_business_model', 'id', 'name', array('name' => "asc"),array('status' => "Active"));
        foreach ($nature_of_business as $key => $val) {
            $data->nature_of_business_options[$key] = ucwords(strtolower($val));
        }
         
		 
		$data->nature_of_employment_options = array("" => "Select Option");
        $nature_of_employment = $this->_selector_options('iboss_dict_nature_of_employment_model', 'id', 'name', array('name' => "asc"),array('status' => "Active"));
        foreach ($nature_of_employment as $key => $val) {
            $data->nature_of_employment_options[$key] = ucwords(strtolower($val));
        }
		
		$rec = $this->Crm_corporate_info_model->retrieve( array( "unique_id" => $data->corporate_uniques ) );
		$data->business_name_display=$rec[0]->business_name;
		
		if(!empty($unique_id)){
			
		$record = $this->Iboss_crm_edu_and_emp_info_model->retrieve( array( "unique_id" => $unique_id ) );
		$id=$record[0]->id;
		
		
		 
		
		$this->_nitro_send_post_to_view($record[0],$data);
		
		
		       if($data->main_crm_type=='Auth')
		   		{
				$record = $this->Crm_personal_info_model->retrieve( array( "unique_id" => $unique_id ) );
				$data->corporate_unique=$record[0]->corporate_unique_id;
				}
				
				$rec = $this->Crm_corporate_info_model->retrieve( array( "unique_id" => $data->corporate_uniques ) );
				$data->business_name_display=$rec[0]->business_name;
		 
	
		}
		
		
		if(empty($unique_id))
		{
			
			
		}else{
			if ( empty( $_POST ) ) {
				return $this->load->view( "iboss_master_crm/iboss_crm_educational_info_add_edit", $data );
			}else {
				$this->_nitro_set_rules();
				if ( $this->form_validation->run() == false ) {
					$this->_nitro_send_post_to_view( $_POST, $data );
					return $this->load->view( "iboss_master_crm/iboss_crm_educational_info_add_edit", $data );
				}
				
				//Add and Update
					if(!empty($id))
					{
					$_POST['id']=$id;
					}else{
					$_POST['date_time']=current_date_time();
					$_POST['unique_id']=$unique_id;	
					}
				//End	
					
				$this->Iboss_crm_edu_and_emp_info_model->set( $_POST );
				$this->db->query("CALL sp_iboss_master_crm_update ('crm_educational_info' , '$unique_id' , 'Update')");
				
				/******************************************************** update CRM Info******************/
				if($this->session->userdata('edit_crm_acc'))
				{
				     $edit_crm_type_acc=$this->session->userdata('edit_crm_type_acc');
                
													switch($edit_crm_type_acc){
													    case "LI":
														$ctype='li';
														$ctype1='iboss_acc_li_client_info_id';
														break;
													    case "GI":
													   	$ctype='gi';
														$ctype1='iboss_acc_gi_client_info_id';
														break;
														case "GROUP":
														$ctype='group';
														$ctype1='iboss_acc_group_client_info_id';
														break;
														case "OTHER":
														$ctype='other_services';
														$ctype1='iboss_acc_other_services_client_info_id';
														break;
														case "INV":
														$ctype='inv';
														$ctype1='iboss_acc_client_id';
														break;
													
													}				
					
					
				//$this->refer_acc_crm_save('iboss_acc_'.$ctype.'_crm_edu_and_emp_info',$unique_id,$ctype1,$this->session->userdata('edit_crm_acc'),$_POST,$edit_crm_type_acc);
				
				}
				
				/******************************************************** End update CRM Info******************/
				
				
				
				
				
				
				if(isset($_POST['savenext']))
				{
				redirect( "iboss_master_crm_info/crm_compliance_info/".$unique_id);	
					
				}else{
					
					 //Auth Info
						if($data->main_crm_type=='Auth')
						{
							//$this->session->set_flashdata('msg', 'Thank You.Added Or Updated Information Successfully');
							redirect( "iboss_master_crm_info/crm_educational_info/".$unique_id);
						}
					    //End Auth Info
						
										$refer_url_page=$this->session->userdata('refer_url_page');
										if(!empty($refer_url_page)){
											$client_type=$refer_data['client_type'];
											if($refer_data['client_type']=='Life Assured'){
											 $client_type='Life Insured';	
											}
										    $this->session->set_userdata('refer_flash', "Thank You.Added New $client_type Client Successfully");
										    redirect($this->session->userdata('refer_url_page'));	
										}
						
						
						
				//$this->session->set_flashdata('msg', 'Thank You.Added Or Updated Information Successfully');
				redirect( "iboss_master_crm_info/crm_educational_info/".$unique_id );
				
				}
				
				
				//$this->Crm_contact_info_model->set( $_POST );
				//redirect( "iboss_master_crm_info/index" );
			}
			
		}
		
	}
	
	




//End New Design	


function crm_compliance_info($unique_id=null) { 
	
		 $this->load->model("Iboss_acc_li_client_info_model");
		
		$data = $this->Crm_compliance_info_model->init_data();
		$data->templates = array('datatables','datepicker','icheck','chosen','select2');
		
		
		//Common Data
		$data->unique_id=$unique_id;
		$data->main_crm_type=unqiue_id_spilit($unique_id);
		$data->crm_tab_type=4;
        $data->title_corp='';
		if($data->main_crm_type=='Corp')
		{
			$data->title_corp='Corp';
		}
		$data->corporate_uniques=$this->session->userdata('auth_crm_unique_id');
		//End Common Data
		

		
        //**************************************************Compliance_list*********************************/
		$data->compliance_labels = $this->Crm_compliance_info_model->get_field_comments();
		$data->enum_compliance = $this->Crm_compliance_info_model->get_enum();#enum data to be included
		//********************************************address_list**********************************/
		$data->department_options=$this->_selector_options('Ums_department_info_model','id','name','name');
		$data->cdd_outcome_options = $this->_selector_options('Iboss_dict_crm_outcome_model','id','name',null,array('outcome_type'=>'CDD'));
		$data->ecdd_outcome_options = $this->_selector_options('Iboss_dict_crm_outcome_model','id','name',null,array('outcome_type'=>'ECDD'));
		$data->ecdd_reporting_outcome_options = $this->_selector_options('Iboss_dict_crm_outcome_model','id','name',null,array('outcome_type'=>'ECDD Reporting'));
		
		$data->username_options=$this->_selector_options('Ums_user_model','id','name','name');
		
		
		$data->username=$this->session->userdata('id');
		
		$data->department=$this->session->userdata('ums_fa_biz_class_info_id');
		
		//$data->cdd_officer_incharge_options=
															
					$data->enum_acc_li_client_info = $this->Iboss_acc_li_client_info_model->get_enum();#enum data to be included
											
		
		//Selector Options
		//$data->country_id_options = array(""=>"-- Please Select The Country --");
		//$data->country_id_options = $this->_selector_options('Iboss_dict_country_model','id','name',array('id'=>'asc'));
		
		$data->country_id_options = array(""=>"Select an Option");
		$country_id = $this->_selector_options('Iboss_dict_country_model', 'id', 'name', array('id' => "asc"),array('status'=>"Active"));
        foreach ($country_id as $key => $val) {
            $data->country_id_options[$key] = ucwords(strtolower($val));
			
        }
		
		$rec = $this->Crm_corporate_info_model->retrieve( array( "unique_id" => $data->corporate_uniques ) );
		$data->business_name_display=$rec[0]->business_name;
		
		
		if(!empty($unique_id)){
		$data->compilance_details = $this->Crm_compliance_info_model->retrieve( array( "unique_id" => $unique_id ,'delete_log'=>'False') );
		$record = $this->Crm_compliance_info_model->retrieve( array( "unique_id" => $unique_id ) );
		
		$this->_nitro_send_post_to_view($record[0],$data);
		
				if($data->main_crm_type=='Auth')
		   		{
				$record = $this->Crm_personal_info_model->retrieve( array( "unique_id" => $unique_id ) );
				$data->corporate_unique=$record[0]->corporate_unique_id;
				}
				
				$rec = $this->Crm_corporate_info_model->retrieve( array( "unique_id" => $data->corporate_uniques ) );
				$data->business_name_display=$rec[0]->business_name;
		 
	
		}
		
		
		if(empty($unique_id))
		{
			
			
		}else{
			if ( empty( $_POST ) ) {
				return $this->load->view( "iboss_master_crm/iboss_crm_compliance_info_add_edit", $data );
			}else {
				$this->_nitro_set_rules();
				if ( $this->form_validation->run() == false ) {
					$this->_nitro_send_post_to_view( $_POST, $data );
					return $this->load->view( "iboss_master_crm/iboss_crm_compliance_info_add_edit", $data );
				}
				
				
				if(isset($_POST['savenext']))
				{
				redirect( "iboss_master_crm_info/crm_marketing_info/".$unique_id);	
					
				}else{
					
					
					 //Auth Info
						if($data->main_crm_type=='Auth')
						{
							//$this->session->set_flashdata('msg', 'Thank You.Added Or Updated Information Successfully');
							redirect( "iboss_master_crm_info/crm_compliance_info/".$unique_id);
						}
					    //End Auth Info
					
				//$this->session->set_flashdata('msg', 'Thank You.Added Or Updated Information Successfully');
				redirect( "iboss_master_crm_info/crm_compliance_info/".$unique_id );
				
				}
				
				
				//$this->Crm_contact_info_model->set( $_POST );
				//redirect( "iboss_master_crm_info/index" );
			}
			
		}
		
	}
	
	
	function add_edit_compilance_info()
	{

					  if(!empty($_POST['row_id']))
								{			
									$res = $this->Crm_compliance_info_model->retrieve(['id'=>$_POST['row_id'],'delete_log'=>"False"]);
									$index =json_encode($res);
									$str = trim($index,']');
									echo trim($str,'[');
									
								}
								else{
									
										if($_POST['edit_compilance_info']=='')
										  {	
									        $_POSTFI['ai']=$_POST['ai'];
											$_POSTFI['oi']=$_POST['oi'];											
											$_POSTFI['ai_declaration_date']=sg2iso($_POST['ai_declaration_date']);
											$_POSTFI['oi_country_id']=$_POST['oi_country_id'];
											
											$_POSTFI['ii']=$_POST['ii'];
											$_POSTFI['ii_country_id']=$_POST['ii_country_id'];
											
											
											$_POSTFI['pep']=$_POST['pep'];
											$_POSTFI['pep_person_name']=$_POST['pep_person_name'];
											$_POSTFI['pep_prominent']=$_POST['pep_prominent'];
											$_POSTFI['pep_country_id']=$_POST['pep_country_id'];
											$_POSTFI['pep_relationship']=$_POST['pep_relationship'];
											
											$_POSTFI['cdd_date_search']=sg2iso($_POST['cdd_date_search']);
											$_POSTFI['cdd_hit']=$_POST['cdd_hit'];
											$_POSTFI['cdd_date_verification']=sg2iso($_POST['cdd_date_verification']);
											$_POSTFI['cdd_outcome']=$_POST['cdd_outcome'];
											$_POSTFI['cdd_check_officer']=$_POST['cdd_check_officer'];											
											$_POSTFI['cdd_officer_incharge']=$_POST['cdd_officer_incharge'];
											$_POSTFI['comment']=$_POST['comment'];
											
											$_POSTFI['ecdd_date_search']=sg2iso($_POST['ecdd_date_search']);
											$_POSTFI['ecdd_date_verification']=sg2iso($_POST['ecdd_date_verification']);
											$_POSTFI['ecdd_outcome']=$_POST['ecdd_outcome'];
											$_POSTFI['ecdd_compliance_approval']=$_POST['ecdd_compliance_approval'];
											$_POSTFI['ecdd_additional_comment']=$_POST['ecdd_additional_comment'];
											$_POSTFI['ecdd_approving_officer']=$_POST['ecdd_approving_officer'];
											$_POSTFI['ecdd_approved_date']=sg2iso($_POST['ecdd_approved_date']);
											$_POSTFI['ecdd_authorised_report']=$_POST['ecdd_authorised_report'];
											$_POSTFI['ecdd_reporting_date']=sg2iso($_POST['ecdd_reporting_date']);
											$_POSTFI['ecdd_reporting_outcome']=$_POST['ecdd_reporting_outcome'];
											$_POSTFI['ecdd_check_officer']=$_POST['ecdd_check_officer'];
											
											
											$_POSTFI['unique_id']=$_POST['unique_id'];
                                           	date_default_timezone_set('Asia/Singapore');
											$date=date('Y-m-d H:i:s');




                //$sql="insert into crm_log(`page_name`,`table_id`,`unique_id`,`username`,`action_name`,`new_value`,`current_date_time`)values('iboss_crm_compliance_info','$_POST['unique_id']','$_POST['unique_id']','$this->session->userdata('username')','insert','$_POSTFI', '$date')";

											 $current_val=serialize($_POSTFI);

                  $sql="insert into crm_log(`page_name`,`table_id`,`unique_id`,`username`,`action_name`,`new_value`,`current_date_time`)values('iboss_crm_compliance_info','".$_POST['unique_id']."','".$_POST['unique_id']."','".$this->session->userdata('username')."','insert','".$current_val."', '".$date."')";
  			 								$this->db->query($sql);  

											/*$this->db->crm_table_audit_insert('iboss_crm_compliance_info',$_POST['unique_id'],$this->session->userdata('username'),'insert',$_POSTFI);*/
										
											
											$insert_val=$this->Crm_compliance_info_model->set($_POSTFI);
					
											
										  }
										  else{
									  
											  
											$_POSTFI['ai']=$_POST['ai'];
											$_POSTFI['oi']=$_POST['oi'];											
											$_POSTFI['ai_declaration_date']=sg2iso($_POST['ai_declaration_date']);
											$_POSTFI['oi_country_id']=$_POST['oi_country_id'];
											
											$_POSTFI['ii']=$_POST['ii'];
											$_POSTFI['ii_country_id']=$_POST['ii_country_id'];
											
											
											$_POSTFI['pep']=$_POST['pep'];
											$_POSTFI['pep_person_name']=$_POST['pep_person_name'];
											$_POSTFI['pep_prominent']=$_POST['pep_prominent'];
											$_POSTFI['pep_country_id']=$_POST['pep_country_id'];
											$_POSTFI['pep_relationship']=$_POST['pep_relationship'];
											
											$_POSTFI['cdd_date_search']=sg2iso($_POST['cdd_date_search']);
											$_POSTFI['cdd_hit']=$_POST['cdd_hit'];
											$_POSTFI['cdd_date_verification']=sg2iso($_POST['cdd_date_verification']);
											$_POSTFI['cdd_outcome']=$_POST['cdd_outcome'];
											$_POSTFI['cdd_check_officer']=$_POST['cdd_check_officer'];											
											$_POSTFI['cdd_officer_incharge']=$_POST['cdd_officer_incharge'];
											$_POSTFI['comment']=$_POST['comment'];
											
											$_POSTFI['ecdd_date_search']=sg2iso($_POST['ecdd_date_search']);
											$_POSTFI['ecdd_date_verification']=sg2iso($_POST['ecdd_date_verification']);
											$_POSTFI['ecdd_outcome']=$_POST['ecdd_outcome'];
											$_POSTFI['ecdd_compliance_approval']=$_POST['ecdd_compliance_approval'];
											$_POSTFI['ecdd_additional_comment']=$_POST['ecdd_additional_comment'];
											$_POSTFI['ecdd_approving_officer']=$_POST['ecdd_approving_officer'];
											$_POSTFI['ecdd_approved_date']=sg2iso($_POST['ecdd_approved_date']);
											$_POSTFI['ecdd_authorised_report']=$_POST['ecdd_authorised_report'];
											$_POSTFI['ecdd_reporting_date']=sg2iso($_POST['ecdd_reporting_date']);
											$_POSTFI['ecdd_reporting_outcome']=$_POST['ecdd_reporting_outcome'];
											$_POSTFI['ecdd_check_officer']=$_POST['ecdd_check_officer'];
											
												
											$_POSTFI['id']=$_POST['edit_compilance_info'];
											// 	date_default_timezone_set('Asia/Singapore');
											// $date=date('Y-m-d H:i:s');



                //$sql="insert into crm_log(`page_name`,`table_id`,`unique_id`,`username`,`action_name`,`new_value`,`current_date_time`)values('iboss_crm_compliance_info','$_POST['unique_id']','$_POST['unique_id']','$this->session->userdata('username')','insert','$_POSTFI', '$date')";

											 // $current_val=serialize($_POSTFI);

            //       $sql="insert into crm_log(`page_name`,`table_id`,`unique_id`,`username`,`action_name`,`new_value`,`current_date_time`)values('iboss_crm_compliance_info','".$_POST['unique_id']."','".$_POST['unique_id']."','".$this->session->userdata('username')."','insert','".$current_val."', '".$date."')";
  			 						// 		$this->db->query($sql);  
											$unique_id_log = array('unique_id'=> $_POST['unique_id']);
										//print_r($unique_id_log);


  			 								
  			 								// $this->db->acc_crm_table_audit_update('iboss_crm_compliance_info',$_POST['edit_compilance_info'],$_POSTFI,$unique_id_log,$this->session->userdata('username'),'update',$_POSTFI['id']);
  			 								$id_log = array('id'=> $_POST['edit_compilance_info']);
											


  			 								
  			 								// $this->db->acc_crm_table_audit_update('iboss_crm_compliance_info',$_POSTFI,$id_log,$unique_id_log,$this->session->userdata('username'),'update',$_POSTFI['id']);

								
											
											$this->Crm_compliance_info_model->set($_POSTFI);
								
											  
											  
										    }					  
										  
						
									$this->db->query("CALL sp_iboss_master_crm_update ('crm_compliance_info' , '".$_POST['unique_id']."' , 'Update')");
								 
					  
				  }
				  
				 
	}
	
	
	
	
	
//End New Design	



//End New Design	


function crm_marketing_info($unique_id=null) { 
	
		
		
		$data = $this->Crm_markerting_info_model->init_data();
		$data->templates = array('datatables','datepicker','icheck','chosen','select2');
		
        //Common Data
		$data->unique_id=$unique_id;
		$data->main_crm_type=unqiue_id_spilit($unique_id);
		$data->crm_tab_type=5;
        $data->title_corp='';
		if($data->main_crm_type=='Corp')
		{
			$data->title_corp='Corp';
		}
		
		$data->corporate_uniques=$this->session->userdata('auth_crm_unique_id');
		//End Common Data
		//$data->corporate_unique = $unique_id;

		//Selector Options
		//$data->country_id_options = array(""=>"-- Please Select The Country --");
		$data->country_id_options = $this->_selector_options('Iboss_dict_country_model','id','name',array('id'=>'asc'));
		
		
		$rec = $this->Crm_corporate_info_model->retrieve( array( "unique_id" => $data->corporate_uniques ) );
		$data->business_name_display=$rec[0]->business_name;

		
		if(!empty($unique_id)){
			
		
		$rec = $this->Crm_personal_info_model->retrieve( array( "unique_id" => $unique_id ) );
		$farcode=$rec[0]->far_code;
		
		$get_dnc = $this->Crm_address_info_model->retrieve( array( "unique_id" => $unique_id ,'delete_log'=>'False') );
    $data->get_mailling_dnc = $get_dnc[0]->mailing_dnc; 
		
		$record = $this->Crm_markerting_info_model->retrieve( array( "unique_id" => $unique_id ) );
		$id=$record[0]->id;
		
		  
		
		
		$record[0]->call_consent_date=iso2sg($record[0]->call_consent_date);
		$record[0]->sms_consent_date=iso2sg($record[0]->sms_consent_date);
		$record[0]->letter_consent_date=iso2sg($record[0]->letter_consent_date);
		$record[0]->email_consent_date=iso2sg($record[0]->email_consent_date);
		$record[0]->fax_consent_date=iso2sg($record[0]->fax_consent_date);
		$record[0]->eversion_consent_date=iso2sg($record[0]->eversion_consent_date);
		
		$this->_nitro_send_post_to_view($record[0],$data);
		
		
		       if($data->main_crm_type=='Auth')
		   		{
				$record = $this->Crm_personal_info_model->retrieve( array( "unique_id" => $unique_id ) );
				$data->corporate_unique=$record[0]->corporate_unique_id;
				}
				
				$rec = $this->Crm_corporate_info_model->retrieve( array( "unique_id" => $data->corporate_uniques ) );
				$data->business_name_display=$rec[0]->business_name;
		 
	
		}
		
		
		if(empty($unique_id))
		{
			
			
		}else{
			if ( empty( $_POST ) ) {
				return $this->load->view( "iboss_master_crm/iboss_crm_marketing_info_add_edit", $data );
			}else {
				$this->_nitro_set_rules();
				if ( $this->form_validation->run() == false ) {
					$this->_nitro_send_post_to_view( $_POST, $data );
					return $this->load->view( "iboss_master_crm/iboss_crm_marketing_info_add_edit", $data );
				}
				
				$_POST['call_consent_date']=sg2iso($_POST['call_consent_date']);
				$_POST['sms_consent_date']=sg2iso($_POST['sms_consent_date']);
				$_POST['letter_consent_date']=sg2iso($_POST['letter_consent_date']);
				$_POST['email_consent_date']=sg2iso($_POST['email_consent_date']);
				$_POST['fax_consent_date']=sg2iso($_POST['fax_consent_date']);
				$_POST['eversion_consent_date']=sg2iso($_POST['eversion_consent_date']);

				//Add and Update
					if(!empty($id))
					{
					$_POST['id']=$id;
					}else{
					$_POST['date_time']=current_date_time();
					$_POST['unique_id']=$unique_id;	
					}

				// $unique_id_log = array('unique_id'=> $unique_id);
				// 	$id_log = array('id'=> $id);						
				// 	$this->db->acc_crm_table_audit_update('iboss_crm_marketing_info',$_POST,$id_log,$unique_id_log,$this->session->userdata('username'),'update',$id);

				$this->Crm_markerting_info_model->set( $_POST );

				$this->db->query("CALL sp_iboss_master_crm_update ('crm_marketing_info' , '$unique_id' , 'Update')");

				//End	
				
				
				/******************************************************** update CRM Info******************/
				if($this->session->userdata('edit_crm_acc'))
				{
				     $edit_crm_type_acc=$this->session->userdata('edit_crm_type_acc');
                
													switch($edit_crm_type_acc){
													    case "LI":
														$ctype='li';
														$ctype1='iboss_acc_li_client_info_id';
														break;
													    case "GI":
													   	$ctype='gi';
														$ctype1='iboss_acc_gi_client_info_id';
														break;
														case "GROUP":
														$ctype='group';
														$ctype1='iboss_acc_group_client_info_id';
														break;
														case "OTHER":
														$ctype='other_services';
														$ctype1='iboss_acc_other_services_client_info_id';
														break;
														case "INV":
														$ctype='inv';
														$ctype1='iboss_acc_client_id';
														break;
													
													}				
					
					
				//$this->refer_acc_crm_save('iboss_acc_'.$ctype.'_crm_marketing_info',$unique_id,$ctype1,$this->session->userdata('edit_crm_acc'),$_POST,$edit_crm_type_acc);

				}
				
				/******************************************************** End update CRM Info******************/
				
				
				$refer_url_page=$this->session->userdata('refer_url_page');
										if(!empty($refer_url_page)){
											$client_type=$refer_data['client_type'];
											if($refer_data['client_type']=='Life Assured'){
											 $client_type='Life Insured';	
											}
										    $this->session->set_userdata('refer_flash', "Thank You.Added New $client_type Client Successfully");
										    redirect($this->session->userdata('refer_url_page'));	
										}
				
				// print_r($_POST);
				// die();
				if(isset($_POST['savenext']))
				{
					if($data->main_crm_type=='Corp')
					{
				    redirect( "iboss_master_crm_info/authorised_person_info/".$unique_id);	
					}
					
				    //redirect( "iboss_master_crm_info/life_policy_info/".$unique_id);	
					
				}else{
					
					if(isset($_POST['save_account_summary']))
					{
					
					if(in_array(1,$this->ums_fa_biz_class_info_id)){$function = 'life_policy_info'; $type = 'LI';};
					if(in_array(7,$this->ums_fa_biz_class_info_id)){$function = 'gi_policy_info'; $type = 'GI';};
					if(in_array(8,$this->ums_fa_biz_class_info_id)){$function = 'group_policy_info'; $type = 'GROUP';};
					if(in_array(9,$this->ums_fa_biz_class_info_id)){$function = 'investment_info'; $type = 'INV';};
					if(in_array(10,$this->ums_fa_biz_class_info_id)){$function = 'other_services_info'; $type = '';};
					if(in_array(3,$this->ums_fa_biz_class_info_id)){$function = 'life_policy_info'; $type = 'LI';};	
					//$this->session->set_flashdata('msg', 'Thank You.Added Or Updated Information Successfully');
					//redirect( "iboss_master_crm_info/license_info/".$unique_id);
					//redirect( "iboss_master_crm_info/life_policy_info/".$unique_id);
					redirect( "iboss_master_crm_info/".$function."/".$unique_id."/".$farcode."/".$type);
					}
					
					 //Auth Info
						if($data->main_crm_type=='Auth')
						{
							//$this->session->set_flashdata('msg', 'Thank You.Added Or Updated Information Successfully');
							redirect( "iboss_master_crm_info/crm_marketing_info/".$unique_id);
						}
					    //End Auth Info
					if($data->main_crm_type=='Corp')
					{
					//$this->session->set_flashdata('msg', 'Thank You.Added Or Updated Information Successfully');
					redirect( "iboss_master_crm_info/crm_marketing_info/".$unique_id);
					}
					
					
					redirect( "iboss_master_crm_info/crm_marketing_info/".$unique_id);
					
					
				}
				
					
				
				
				
				//$this->Crm_contact_info_model->set( $_POST );
				//redirect( "iboss_master_crm_info/index" );
			}
			
		}
		
	}
	
	
	
	
	
	
//End New Design	






function validateNRIC() 
   {
	    $nric=trim($_POST['nric']);
	
	 if(preg_match("/(S|T)/", $nric)==false){
	  echo '0';
      return false; 
	 }
	   
    if ( preg_match('/^[ST][0-9]{7}[JZIHGFEDCBA]$/', $nric) ){ // NRIC
      $check = "JZIHGFEDCBA";
	  
    }else {

      echo '0';
      return false;
    }
 

    

    $total = $nric[1]*2
      + $nric[2]*7
      + $nric[3]*6
      + $nric[4]*5
      + $nric[5]*4
      + $nric[6]*3
      + $nric[7]*2;

    if ( $nric[0] == "T" OR $nric[0] == "G" ) 
    {
      // shift 4 places for after year 2000
      $total = $total + 4; 
    }

    if ( $nric[8] == $check[$total % 11] ) {

     echo  '1';
      return TRUE;
    } else {

      echo '0';
      return FALSE;
    }

  }


function validateFin() 
   {
	 $nric=trim($_POST['fin']);
		
	   
    if(preg_match("/(F|G)/", $nric)==false){
	  echo 'Not Match with First Code';
      return false; 
	 }
    if ( preg_match('/^[FG][0-9]{7}[XWUTRQPNMLK]$/', $nric) ) 
    { // FIN
  
      $check = "XWUTRQPNMLK";
	  
    }else {

      echo '0';
      return false;
    }
 

    

    $total = $nric[1]*2
      + $nric[2]*7
      + $nric[3]*6
      + $nric[4]*5
      + $nric[5]*4
      + $nric[6]*3
      + $nric[7]*2;

    if ( $nric[0] == "T" OR $nric[0] == "G" ) 
    {
      // shift 4 places for after year 2000
      $total = $total + 4; 
    }

    if ( $nric[8] == $check[$total % 11] ) {

     echo  '1';
      return TRUE;
    } else {

      echo '0';
      return FALSE;
    }

  }


	



	function srch_postal_code()
 	{
 		$data = new stdClass();
		$like=$_REQUEST["query"];
			
		$limit='10';
		
		
		
        
		 $sql = "select * from add_postcode where delete_log='False' and ( postcode LIKE '$like%') order by postcode asc limit 8";
	
			
	   //$sql = "select * from iboss_crm_personal_info where nric_name like '%$keysearch%'limit 10";

		$result = $this->db->query($sql);
		
		$total_postal=count($result->result());
			    
		$json = [];
		$json_array = [];
			
	    if($total_postal!=0)
	    {
		    foreach($result->result() as $postal_data)
		    {        
					 
                     $result_like ='';
					if(!empty($postal_data->postcode))
					 {
					   $result_like .= $postal_data->postcode.'-';
					 }
					if(!empty($postal_data->building_no))
					 {
					   $result_like .= $postal_data->building_no.'-';
					 }
					if (!empty($postal_data->building_name)) 
					 {
					   $result_like .= $postal_data->building_name.'-';
					 }
					if (!empty($postal_data->street_name)) 
					 {
					   $result_like .= $postal_data->street_name;
					 }
					 
					 
             $json['name']= $result_like;	
		     $json['id']= $postal_data->id; 
			 $json['block']= $postal_data->building_no; 
			 $json['unit']= "#".$postal_data->unit;
			 $json['street']= $postal_data->street_name;
			 $json['building']= $postal_data->building_name;
			 $json['postcode']= $postal_data->postcode;
			 $json['city_state']= "Singapore";
		     $json_array[]=$json;
		    }
	    }
	    else
	    {
	    	
	    	$json['name']= "No Data Found";
	    	 $json_array[]=$json;
	    }
		header('Content-Type" => application/json');
		echo json_encode($json_array);
			   

 	}

	
	
	
	
	
	
	function srch_pep_prominent()
 	{
 		$data = new stdClass();
		$like=$_REQUEST["query"];
			
		$limit='10';

	   $sql = "select * from iboss_dict_pep_prominent where ( name LIKE '%$like%') order by name asc limit 8";
		
	   //$sql = "select * from iboss_crm_personal_info where nric_name like '%$keysearch%'limit 10";

		$result = $this->db->query($sql);
		
		$total_school=count($result->result());
			    
		$json = [];
		$json_array = [];
			
	    if($total_school!=0)
	    {
		    foreach($result->result() as $school_data)
		    {        
					 
             $json['name']= $school_data->name;	

		     $json_array[]=$json;
		    }
	    }
	    else
	    {
	    	
	    	$json['name']= "No Data Found";
	    	 $json_array[]=$json;
	    }
		header('Content-Type" => application/json');
		echo json_encode($json_array);
			   

 	}
	
	function consultant_session()
	{
					 $this->session->set_userdata('session_far_code',$_POST['far_code']);

	}

	 
	
	function srch_nric_no()
 	{
 		$data = new stdClass();
		$like=$_REQUEST["query"];
			
		$limit='10';
		
		
		
			
       // if($this->session->userdata('session_far_code')){
			
		//$sql = "select * from iboss_crm_personal_info where delete_log='False'  and  far_code='".$this->session->userdata('session_far_code')."' and ( identification_no LIKE '$like%') order by id asc limit 8";	
		//}else{
			$sql = "select * from iboss_crm_personal_info where delete_log='False' and prefix_unique_id='Auth'  and ( identification_no LIKE '$like%') order by id asc limit 8";
		//}
		
        //$sql = "select * from iboss_crm_personal_info where nric_name like '%$keysearch%'limit 10";
		$result = $this->db->query($sql);
		$total_personal=count($result->result());
		$json = [];
		$json_array = [];
			
	    if($total_personal!=0)
	    {
		    foreach($result->result() as $personal_data)
		    {        
					 
             $json['name']= $personal_data->identification_no;	
		     $json['id']= $personal_data->id; 
			 $json['nric_name']= $personal_data->nric_name; 
			 $json['saluation']= $personal_data->saluation;
			 $json['preferred_name']= $personal_data->preferred_name;
			 $json['nationality_id']= $personal_data->nationality_id;
			 $json['country_of_residence']= $personal_data->country_of_residence;
			 $json['passport_no']= $personal_data->passport_no;
			 $json['citizenship']= $personal_data->citizenship;
			 $json['fin_no']= $personal_data->fin_no;
			 $json['dob']= $personal_data->dob;
     		 $json['marital_status']= $personal_data->marital_status;
			 $json['race_id']= $personal_data->race_id;
			 $json['last_birth_date']=$this->chek_the_name($personal_data->unique_id,$personal->id,'r4');
			 $json['next_birth_date']= $this->chek_the_name($personal_data->unique_id,$personal->id,'r5');
			 $json['gender']= $personal_data->gender;
			 $json['religion_id']= $personal_data->religion_id;
			 $json['preferred_language']=$personal_data->preferred_language;
			 $json['smoker']= $personal_data->smoker;
			 $json['faiwa_client']= $personal_data->faiwa_client;
			 $json['unique_id']= $personal_data->unique_id;
			 
			
			
		     $json_array[]=$json;
		    }
	    }
	    else
	    {
	    	
	    	 $json['name']= "No Data Found";
	    	 $json_array[]=$json;
	    }
		header('Content-Type" => application/json');
		echo json_encode($json_array);
			   

 	}
	
	
	
	function srch_nric_no_auth()
 	{
 		$data = new stdClass();
		$like=$_REQUEST["query"];
			
		$limit='10';
		
		
		
        
		$sql = "select * from iboss_crm_personal_info where delete_log='False' and prefix_unique_id='Inv'  and ( identification_no LIKE '$like%') order by id asc limit 8";
        //$sql = "select * from iboss_crm_personal_info where nric_name like '%$keysearch%'limit 10";
		$result = $this->db->query($sql);
		$total_personal=count($result->result());
		$json = [];
		$json_array = [];
			
	    if($total_personal!=0)
	    {
		    foreach($result->result() as $personal_data)
		    {        
					 
             $json['name']= $personal_data->identification_no;	
		     $json['id']= $personal_data->id; 
			 $json['nric_name']= $personal_data->nric_name; 
			 $json['saluation']= $personal_data->saluation;
			 $json['preferred_name']= $personal_data->preferred_name;
			 $json['nationality_id']= $personal_data->nationality_id;
			 $json['country_of_residence']= $personal_data->country_of_residence;
			 $json['passport_no']= $personal_data->passport_no;
			 $json['citizenship']= $personal_data->citizenship;
			 $json['fin_no']= $personal_data->fin_no;
			 $json['dob']= $personal_data->dob;
     		 $json['marital_status']= $personal_data->marital_status;
			 $json['race_id']= $personal_data->race_id;
			 $json['last_birth_date']=$this->chek_the_name($personal_data->unique_id,$personal->id,'r4');
			 $json['next_birth_date']= $this->chek_the_name($personal_data->unique_id,$personal->id,'r5');
			 $json['gender']= $personal_data->gender;
			 $json['religion_id']= $personal_data->religion_id;
			 $json['preferred_language']=$personal_data->preferred_language;
			 $json['smoker']= $personal_data->smoker;
			 $json['faiwa_client']= $personal_data->faiwa_client;
			 $json['unique_id']= $personal_data->unique_id;
			 $this->session->set_userdata('session_unique_id',$personal_data->unique_id);
			
		     $json_array[]=$json;
		    }
	    }
	    else
	    {
	    	
	    	$json['name']= "No Data Found";
	    	 $json_array[]=$json;
	    }
		header('Content-Type" => application/json');
		echo json_encode($json_array);
			   

 	}
	
	
	function authorized_info($unique_id,$far_code) {
		
		$this->load->model("Iboss_acc_li_policy_info_model");
		$data = $this->Iboss_acc_li_policy_info_model->init_data();
		$data->templates = array('datatables');
		$data->unique_id=$unique_id;
		$data->main_far_code=$far_code;
		$data->account_tab_type=7;
		$data->license_kk=biz_licensing_farcode_result($far_code);
    $data->passport=$this->chek_the_name($unique_id,'','r6');
    $data->fin_no=$this->chek_the_name($unique_id,'','r7');
    $data->nric_no=$this->chek_the_name($unique_id,'','r2');
		
		$farcode = $this->_selector_farcode_policy();
        foreach ($farcode as $key => $val) {
            $data->farcode_options[$key] = $val;
        } 
		
		
	$this->load->view("iboss_master_crm/iboss_license_info_account_summary", $data);
		
		return;	
		
	}

 function life_policy_info($unique_id,$far_code){
	$data = new stdClass();
	$data->templates = array('datatables');
	
	$data->unique_id=$unique_id;
	$data->main_far_code=$far_code;
	$data->client_nric_name=$this->chek_the_name($unique_id,'','r1');
  $data->passport=$this->chek_the_name($unique_id,'','r6');
  $data->fin_no=$this->chek_the_name($unique_id,'','r7');
   $data->nric_no=$this->chek_the_name($unique_id,'','r2');
	$data->account_tab_type=1;
	$data->license=biz_licensing_farcode_result($far_code);

$farcode = $this->_selector_farcode_policy();
        foreach ($farcode as $key => $val) {
            $data->farcode_options[$key] = $val;
        } 


		$sql="SELECT   t2.name as policy_status,t1.source_from as source_from,t1.id as id,t1.iboss_crm_unique_id as iboss_crm_unique_id,t1.far_code as far_code,t1.policy_number as policy_number ,t3.iboss_preferred_name as iboss_preferred_name ,t1.autosync_uuid as uuid,  (CASE
        WHEN LEFT(t1.iboss_crm_unique_id, 1) = 'C' THEN t7.biz_reg_no
        WHEN LEFT(t1.iboss_crm_unique_id, 1) = 'I' THEN t8.identification_no
        ELSE ''
    END) AS identification_no,
    (CASE
        WHEN LEFT(t1.iboss_crm_unique_id, 1) = 'C' THEN t7.business_name
        WHEN LEFT(t1.iboss_crm_unique_id, 1) = 'I' THEN t8.nric_name
        ELSE ''
    END) AS nric_name, t1.writing_far as writing_far,t1.servicing_far as servicing_far ,t5.name as iboss_product_li_info_id, t3.iboss_status as status , t1.inforce_date AS inforce_date from  iboss_acc_li_policy_info  as t1 left join iboss_dict_policy_status as t2 on t1.policy_status=t2.id left join iboss_farops_far_info as t3 on t1.servicing_far=t3.iboss_far_code left join iboss_acc_li_crm_corporate_info t7 on (t7.unique_id=t1.iboss_crm_unique_id and t7.iboss_acc_li_policy_info_id = t1.id) left join iboss_acc_li_crm_personal_info t8 on (t8.unique_id=t1.iboss_crm_unique_id and t8.iboss_acc_li_policy_info_id = t1.id) left join iboss_product_li_info as t5 on t1.iboss_product_li_info_id=t5.id where t1.delete_log='False' and t1.iboss_crm_unique_id='".$unique_id."' and t1.servicing_far = '".$far_code."' ORDER BY id DESC " ;


              $rs = $this->iboss_read->query($sql);
               $data->index= $rs->result();
			   /* print_r($this->iboss_read->last_query());
               print_r($data->index);
               die(); */

  $this->load->view("iboss_master_crm/iboss_li_policy_info_account_summary", $data);
		
		// return;
 
	}
	


	function life_policy_info_old($unique_id,$far_code) {
		
		$this->load->model("Iboss_acc_li_policy_info_model");

		$data = $this->Iboss_acc_li_policy_info_model->init_data();
		
		$data->templates = array('datatables');
		$data->unique_id=$unique_id;
		$data->main_far_code=$far_code;

		$data->client_nric_name=$this->chek_the_name($unique_id,'','r1');
		$data->account_tab_type=1;
		$data->license=biz_licensing_farcode_result($far_code);
		
		
		$_selector_FARname_options = selector_consultans_FARname();	
		foreach ($_selector_FARname_options as $key => $val) {
            $data->farname_options[$key] = $val;
        }
		
		
		$farcode = $this->_selector_farcode_policy();
        foreach ($farcode as $key => $val) {
            $data->farcode_options[$key] = $val;
        } 
		 
        $bi_id = $this->_selector_options('Iboss_product_li_info_model', 'id', 'name', array('id' => "asc"));
        foreach ($bi_id as $key => $val) {
            $data->bi_id_options[$key] = $val;
			
        }
		 
		 
		 
			
              $iboss_dict_li_product_type_id = $this->_selector_options('Iboss_dict_li_product_type_model', 'id', 'name', array('id' => "asc"));
				foreach ($iboss_dict_li_product_type_id as $key => $val) {
					$data->iboss_dict_li_product_type_id_options[$key] = $val;
				}
				
				
				$iboss_product_li_insurer_id =$this->_selector_options_product('Iboss_product_li_info_model', 'id', 'name', array('id' => "asc"),array("type"=>'BI Product'),'dict_insurer_products');
        foreach ($iboss_product_li_insurer_id as $key => $val) {
            $data->iboss_product_li_insurer_id_options[$key] = $val;
        }
		
		
		
        $policy_status_id = $this->_selector_options('Iboss_dict_policy_status_model', 'id', 'name', array('id' => "asc"),array('business_class_id'=>'1','status' => "Active"));
        foreach ($policy_status_id as $key => $val) {
            $data->policy_status_options[$key] = $val;
        }
		
		
		//Business Status
		$data->business_status_options = array("0" => "-- Select Business Status --");
        $business_status_id = $this->_selector_options('Iboss_dict_business_status_model', 'id', 'name', array('id' => "asc"),array('business_class_id'=>'1','status' => "Active"));
        foreach ($business_status_id as $key => $val) {
            $data->business_status_options[$key] = $val;
        }
		
		$data->iboss_acc_policy_owner_row =function($row_unique_id,$policy_id,$filed_name,$type){
				
				$row_value_return=  $this->chek_the_name_with_policy($row_unique_id,$policy_id,$filed_name,$type) ;

				
				return $row_value_return;
				
				};
				
		if($unique_id=='ALL'){
		$data->index = $this->Iboss_acc_li_policy_info_model->retrieve(array('delete_log'=>"False"));	
		}else{
			
			
			/* $sql = "select * from iboss_acc_li_policy_info  where id IN (select distinct iboss_acc_li_policy_info_id from iboss_acc_li_far_details where far_code ='".$far_code."' and  delete_log='False' )";
		$result = $this->db->query($sql);
		$data->index=$result->result(); */
		$data->index = $this->Iboss_acc_li_policy_info_model->retrieve(array('delete_log'=>"False",'iboss_crm_unique_id'=>$unique_id, 'far_code'=>$far_code));	
		
		//print_r($this->db->last_query());

//print_r($this->db->last_query())		;
		}		
		
		
		$this->load->view("iboss_master_crm/iboss_li_policy_info_account_summary", $data);
		
		return;
	}

	function gi_policy_info($unique_id,$far_code){
		$data = new stdClass();

		

		$data->templates = array('datatables');
		$data->unique_id=$unique_id;
		$data->main_far_code=$far_code;
		$data->account_tab_type=2;
		$data->license=biz_licensing_farcode_result($far_code);
		
		$data->client_nric_name=$this->chek_the_name($unique_id,'','r1');
    $data->passport=$this->chek_the_name($unique_id,'','r6');
    $data->fin_no=$this->chek_the_name($unique_id,'','r7');
    $data->nric_no=$this->chek_the_name($unique_id,'','r2');
		
		 
		 $farcode = $this->_selector_farcode_policy();
        foreach ($farcode as $key => $val) {
            $data->farcode_options[$key] = $val;
        } 

		/*$sql="SELECT t2.name as policy_status,t1.id as id,t1.iboss_crm_unique_id as iboss_crm_unique_id,t1.servicing_farcode as far_code,t1.policy_number as policy_number ,t3.iboss_preferred_name as iboss_preferred_name, 
		(CASE
        WHEN LEFT(t1.iboss_crm_unique_id, 1) = 'C' THEN t7.biz_reg_no
        WHEN LEFT(t1.iboss_crm_unique_id, 1) = 'I' THEN t8.identification_no
        ELSE ''
    END) AS identification_no,
    (CASE
        WHEN LEFT(t1.iboss_crm_unique_id, 1) = 'C' THEN t7.business_name
        WHEN LEFT(t1.iboss_crm_unique_id, 1) = 'I' THEN t8.nric_name
        ELSE ''
    END) AS nric_name, t5.name as iboss_product_gi_info_id, t1.inforce_date as inforce_date, t1.submission_date  as submission_date,t6.name as company ,t1.policy_issue_date as policy_issue_date,t3.iboss_status as status  from  iboss_acc_gi_policy_info  as t1 left join iboss_dict_policy_status as t2 on t1.policy_status=t2.id left join iboss_farops_far_info as t3 on t1.servicing_farcode=t3.iboss_far_code left join iboss_acc_gi_crm_corporate_info t7 on (t7.unique_id=t1.iboss_crm_unique_id and t7.iboss_acc_gi_policy_info_id = t1.id)  left join iboss_acc_gi_crm_personal_info t8 on (t8.unique_id=t1.iboss_crm_unique_id and t8.iboss_acc_gi_policy_info_id = t1.id) left join iboss_product_gi_info as t5 on t1.iboss_product_gi_info_id=t5.id left join iboss_dict_fa_company as t6 on t6.id=t1.iboss_dict_fa_company_id
			where t1.delete_log='False' and t1.iboss_crm_unique_id='".$unique_id."' and t1.servicing_farcode = '".$far_code."' ORDER BY id DESC" ;*/

			$sql="SELECT t2.name as policy_status,t1.id as id,t1.iboss_crm_unique_id as iboss_crm_unique_id,t1.servicing_farcode as far_code,t1.policy_number as policy_number ,t3.iboss_preferred_name as iboss_preferred_name,t9.identification_no as identification_no,t9.nric_name as nric_name,
			 	t5.name as iboss_product_gi_info_id, t1.inforce_date as inforce_date, t1.submission_date  as submission_date,t6.name as company ,t1.policy_issue_date as policy_issue_date,t3.iboss_status as status  from  iboss_acc_gi_policy_info  as t1 left join iboss_dict_policy_status as t2 on t1.policy_status=t2.id left join iboss_farops_far_info as t3 on t1.servicing_farcode=t3.iboss_far_code 
				-- left join iboss_acc_gi_crm_corporate_info t7 on (t7.unique_id=t1.iboss_crm_unique_id and t7.iboss_acc_gi_policy_info_id = t1.id)  
				-- left join iboss_acc_gi_crm_personal_info t8 on (t8.unique_id=t1.iboss_crm_unique_id and t8.iboss_acc_gi_policy_info_id = t1.id) 
				left join iboss_acc_gi_crm_info t9 on t9.unique_id=t1.iboss_crm_unique_id and t1.id=t9.id
				left join iboss_product_gi_info as t5 on t1.iboss_product_gi_info_id=t5.id left join iboss_dict_fa_company as t6 on t6.id=t1.iboss_dict_fa_company_id
			where t1.delete_log='False' and t1.iboss_crm_unique_id='".$unique_id."' and t1.servicing_farcode = '".$far_code."' ORDER BY id DESC" ;

			 $rs = $this->iboss_read->query($sql);
               $data->index= $rs->result();

               $this->load->view("iboss_master_crm/iboss_gi_policy_info_account_summary", $data);

	}


	
	
	function gi_policy_info_old($unique_id,$far_code) {
		
		$this->load->model("Iboss_acc_gi_policy_info_model");

		$data = $this->Iboss_acc_gi_policy_info_model->init_data();
		
		$data->templates = array('datatables');
		$data->unique_id=$unique_id;
		$data->main_far_code=$far_code;
		$data->account_tab_type=2;
		$data->license=biz_licensing_farcode_result($far_code);
		
		$data->client_nric_name=$this->chek_the_name($unique_id,'','r1');
		
		 
		 $farcode = $this->_selector_farcode_policy();
        foreach ($farcode as $key => $val) {
            $data->farcode_options[$key] = $val;
        } 
		 
        $bi_id = $this->_selector_options('Iboss_product_gi_info_model', 'id', 'name', array('id' => "asc"));
        foreach ($bi_id as $key => $val) {
            $data->bi_id_options[$key] = $val;
			
        }
		 
			
            /*$iboss_dict_gi_product_type_id = $this->_selector_options('Iboss_dict_gi_product_type_model', 'id', 'name', array('id' => "asc"));
				foreach ($iboss_dict_gi_product_type_id as $key => $val) {
					$data->iboss_dict_gi_product_type_id_options[$key] = $val;
				}*/

			$data->insurer_id_options = array("" => "-- Select Insurer  --");
        	$insurer_id = $this->_selector_options('Iboss_dict_fa_company_model', 'id', 'name', array('id' => "asc"),array('iboss_dict_biz_class_id'=>'3','status' => "Active"));
        foreach ($insurer_id as $key => $val) {
            $data->insurer_id_options[$key] = $val;
        }
				
				
				$iboss_product_gi_insurer_id =$this->_selector_options_product('Iboss_product_gi_info_model', 'id', 'name', array('id' => "asc"),array("type"=>'FA Product'),'product_gi_insurer');
        foreach ($iboss_product_gi_insurer_id as $key => $val) {
            $data->iboss_product_gi_insurer_id_options[$key] = $val;
        }
		
		
		
        $policy_status_id = $this->_selector_options('Iboss_dict_policy_status_model', 'id', 'name', array('id' => "asc"),array('business_class_id'=>'3','status' => "Active"));
        foreach ($policy_status_id as $key => $val) {
            $data->policy_status_options[$key] = $val;
        }
		
		
		//Business Status
		$data->business_status_options = array("0" => "-- Select Business Status --");
        $business_status_id = $this->_selector_options('Iboss_dict_business_status_model', 'id', 'name', array('id' => "asc"),array('business_class_id'=>'3','status' => "Active"));
        foreach ($business_status_id as $key => $val) {
            $data->business_status_options[$key] = $val;
        }
		
		$data->iboss_acc_policy_owner_row =function($row_unique_id,$row_id,$filed_name){
				
				$row_value_return=  $this->chek_the_name($row_unique_id,$row_id,$filed_name);

				
				return $row_value_return;
				
				};
				
		if($unique_id=='ALL'){
		$data->index = $this->Iboss_acc_gi_policy_info_model->retrieve(array('delete_log'=>"False"));	
		}else{
		$data->index = $this->Iboss_acc_gi_policy_info_model->retrieve(array('delete_log'=>"False",'iboss_crm_unique_id'=>$unique_id));
		}		
			
		
		
		$this->load->view("iboss_master_crm/iboss_gi_policy_info_account_summary", $data);
		
		return;
	}
	
	function group_policy_info($unique_id,$far_code) {

		$data = new stdClass();
		$this->load->model("Iboss_acc_group_policy_info_model");

		$data = $this->Iboss_acc_group_policy_info_model->init_data();
           $data = $this->Iboss_acc_group_policy_info_model->init_data();
		

		$data->templates = array('datatables');
		$data->unique_id=$unique_id;
		$data->main_far_code=$far_code;
		$data->account_tab_type=3;
		$data->license=biz_licensing_farcode_result($far_code);
		$data->client_nric_name=$this->chek_the_name($unique_id,'','r1');
    $data->passport=$this->chek_the_name($unique_id,'','r6');
    $data->fin_no=$this->chek_the_name($unique_id,'','r7');
    $data->nric_no=$this->chek_the_name($unique_id,'','r2');
		
		
		 $farcode = $this->_selector_farcode_policy();
        foreach ($farcode as $key => $val) {
            $data->farcode_options[$key] = $val;
        } 


		/*$sql="SELECT t2.name as policy_status,t1.id as id,t1.iboss_crm_unique_id as iboss_crm_unique_id,t1.servicing_farcode as far_code,t1.policy_number as policy_number ,t3.iboss_preferred_name as iboss_preferred_name, (CASE
        WHEN LEFT(t1.iboss_crm_unique_id, 1) = 'C' THEN t7.biz_reg_no
        WHEN LEFT(t1.iboss_crm_unique_id, 1) = 'I' THEN t8.identification_no
        ELSE ''
    END) AS identification_no,
    (CASE
        WHEN LEFT(t1.iboss_crm_unique_id, 1) = 'C' THEN t7.business_name
        WHEN LEFT(t1.iboss_crm_unique_id, 1) = 'I' THEN t8.nric_name
        ELSE ''
    END) AS nric_name, t5.name as iboss_product_group_info_id, t1.policy_issue_date as policy_issue_date , t6.name as company, t1.inforce_date as inforce_date, t1.submission_date  as submission_date,t1.policy_issue_date as policy_issue_date from  iboss_acc_group_policy_info  as t1 left join iboss_dict_policy_status as t2 on t1.policy_status=t2.id left join iboss_farops_far_info as t3 on t1.servicing_farcode=t3.iboss_far_code left join iboss_acc_group_crm_corporate_info t7 on (t7.unique_id=t1.iboss_crm_unique_id and t7.iboss_acc_group_policy_info_id = t1.id) left join iboss_acc_group_crm_personal_info t8 on (t8.unique_id=t1.iboss_crm_unique_id and t8.iboss_acc_group_policy_info_id = t1.id) left join iboss_product_group_info as t5 on t1.iboss_product_group_info_id=t5.id 
	left join iboss_dict_fa_company as t6 on t6.id=t1.iboss_dict_fa_company_id	where t1.delete_log='False' and t1.iboss_crm_unique_id='".$unique_id."' and t1.servicing_farcode = '".$far_code."' ORDER BY id DESC" ;*/

	$sql="SELECT t2.name as policy_status,t1.id as id,t1.iboss_crm_unique_id as iboss_crm_unique_id,t1.servicing_farcode as far_code,t1.policy_number as policy_number ,t3.iboss_preferred_name as iboss_preferred_name, t9.identification_no as identification_no ,t9.nric_name as nric_name,
      t5.name as iboss_product_group_info_id, t1.policy_issue_date as policy_issue_date , t6.name as company, t1.inforce_date as inforce_date, t1.submission_date  as submission_date,t1.policy_issue_date as policy_issue_date from  iboss_acc_group_policy_info  as t1 left join iboss_dict_policy_status as t2 on t1.policy_status=t2.id left join iboss_farops_far_info as t3 on t1.servicing_farcode=t3.iboss_far_code 
     /* left join iboss_acc_group_crm_corporate_info t7 on (t7.unique_id=t1.iboss_crm_unique_id and t7.iboss_acc_group_policy_info_id = t1.id) 
      left join iboss_acc_group_crm_personal_info t8 on (t8.unique_id=t1.iboss_crm_unique_id and t8.iboss_acc_group_policy_info_id = t1.id) */
      left join iboss_acc_group_crm_info as t9 on t9.unique_id=t1.iboss_crm_unique_id and t9.id=t1.id
      left join iboss_product_group_info as t5 on t1.iboss_product_group_info_id=t5.id 
	left join iboss_dict_fa_company as t6 on t6.id=t1.iboss_dict_fa_company_id	where t1.delete_log='False' and t1.iboss_crm_unique_id='".$unique_id."' and t1.servicing_farcode = '".$far_code."' ORDER BY id DESC" ;

				$rs = $this->iboss_read->query($sql);
               $data->index= $rs->result();

               $this->load->view("iboss_master_crm/iboss_group_policy_info_account_summary", $data);
	}
		

public function delete_gi($policy_id)
  {
  
    $db = $this->load->database('default', TRUE);

    $table_delete_name = ["0"=>"iboss_acc_gi_client_info","1"=>"iboss_acc_gi_far_details","2"=>"iboss_acc_gi_endorsement_info","3"=>"iboss_acc_gi_policy_info_rider","4"=>"iboss_acc_gi_document_view_by_far","5"=>"iboss_acc_gi_claim_info_uploads","6"=>"iboss_acc_gi_production_exclusion","7"=>"iboss_acc_gi_policy_financial","8"=>"iboss_acc_gi_policy_transfer","9"=>"iboss_acc_gi_claim_info"];

    $this->Iboss_acc_gi_policy_info_model->delete($policy_id);

    for ($i=0; $i <count($table_delete_name) ; $i++) 
    { 
             $sql = "UPDATE ".$table_delete_name[$i]." SET `delete_log` = 'True' WHERE `iboss_acc_gi_policy_info_id` = '".$policy_id."'";
             $db->query($sql);
      
    }
  }

  public function delete_group($policy_id)
  {
  
    $db = $this->load->database('default', TRUE);

    $table_delete_name = ["0"=>"iboss_acc_group_client_info","1"=>"iboss_acc_group_far_details","2"=>"iboss_acc_group_endorsement_info","3"=>"iboss_acc_group_policy_info_rider","4"=>"iboss_acc_group_document_view_by_far","5"=>"iboss_acc_group_claim_info_uploads","6"=>"iboss_acc_group_production_exclusion","7"=>"iboss_acc_group_policy_financial","8"=>"iboss_acc_group_policy_transfer","9"=>"iboss_acc_group_claim_info"];

    $this->Iboss_acc_group_policy_info_model->delete($policy_id);

    for ($i=0; $i <count($table_delete_name) ; $i++) 
    { 
             $sql = "UPDATE ".$table_delete_name[$i]." SET `delete_log` = 'True' WHERE `iboss_acc_group_policy_info_id` = '".$policy_id."'";
             $db->query($sql);
      
    }
  }


public function delete_others($policy_id)
  {
	  
    $db = $this->load->database('default', TRUE);



    $table_delete_name = ["0"=>"iboss_acc_other_services_transfer","1"=>"iboss_acc_other_services_client_info","2"=>"iboss_acc_other_services_far_details","3"=>"iboss_acc_other_services_attachable_policy","4"=>"iboss_acc_other_services_document_view_by_far","5"=>"iboss_acc_other_services_production_exclusion","6"=>"iboss_acc_other_services_case_administration","7"=>"iboss_acc_other_services_crm_personal_info","8"=>"iboss_acc_other_services_crm_corporate_info"];

    $this->Iboss_acc_other_services_info_model->delete($policy_id);

    for ($i=0; $i <count($table_delete_name) ; $i++) 
    { 
             $sql = "UPDATE ".$table_delete_name[$i]." SET delete_log = 'True' WHERE iboss_acc_other_services_info_id = '".$policy_id."'";
             $db->query($sql);
      
    }
  }

public function delete_group_id($account_id)
  {
    $table_name = ['0'=>"Iboss_acc_inv_client_info_model","1"=>"Iboss_acc_inv_far_details_model","2"=>"Iboss_acc_inv_transaction_model","3"=>"Iboss_acc_inv_transfer_model","4"=>"Iboss_acc_inv_financial_model","5"=>"Iboss_acc_inv_portfoilo_value_model","6"=>"Iboss_acc_inv_far_transaction_details_model"];

    $this->Iboss_acc_inv_info_model->delete($account_id);

    for ($i=0; $i <count($table_name) ; $i++) 
    { 
      $result_id = $this->$table_name[$i]->retrieve(['iboss_acc_inv_account_id'=>$account_id]);

      for ($j=0; $j <count($result_id) ; $j++) 
      { 
        $this->$table_name[$i]->delete($result_id[$j]->id);
      }
      
    }
  }

  function iboss_acc_li_delete( $id = 0){
    $db = $this->load->database('default', TRUE);
    $this->Iboss_acc_li_policy_info_model->delete( $id );
    
    
    $table_delete_name = ["0"=>"iboss_acc_li_client_info","1"=>"iboss_acc_li_far_details","2"=>"iboss_acc_li_policy_info_rider","3"=>"iboss_acc_li_document_view_by_far","4"=>"iboss_acc_li_production_exclusion","5"=>"iboss_acc_li_policy_financial","6"=>"iboss_acc_li_policy_transfer","7"=>"iboss_acc_li_claim_info","8"=>"iboss_acc_li_claim_info_uploads","9"=>"iboss_acc_li_report","10"=>"iboss_acc_li_crm_personal_info"];


    for ($i=0; $i <count($table_delete_name) ; $i++) 
    { 
             $sql = "UPDATE ".$table_delete_name[$i]." SET delete_log = 'True' WHERE iboss_acc_li_policy_info_id = '".$id."'";
             $db->query($sql);
      
    }
    
    
    
    //redirect( "iboss_acc_li_policy_info/index" );
  }



	function group_policy_info_old($unique_id,$far_code) {
		
		$this->load->model("Iboss_acc_group_policy_info_model");

		$data = $this->Iboss_acc_group_policy_info_model->init_data();
		
		$data->templates = array('datatables');
		$data->unique_id=$unique_id;
		$data->main_far_code=$far_code;
		$data->account_tab_type=3;
		$data->license=biz_licensing_farcode_result($far_code);
		$data->client_nric_name=$this->chek_the_name($unique_id,'','r1');
		
		
		 $farcode = $this->_selector_farcode_policy();
        foreach ($farcode as $key => $val) {
            $data->farcode_options[$key] = $val;
        } 
		 
        $bi_id = $this->_selector_options('Iboss_product_li_info_model', 'id', 'name', array('id' => "asc"));
        foreach ($bi_id as $key => $val) {
            $data->bi_id_options[$key] = $val;
			
        }
		 
			
            $iboss_dict_group_product_type_id = $this->_selector_options('Iboss_dict_group_product_type_model', 'id', 'name', array('id' => "asc"));
				foreach ($iboss_dict_group_product_type_id as $key => $val) {
					$data->iboss_dict_group_product_type_id_options[$key] = $val;
				}
				
				
				$iboss_product_group_insurer_id =$this->_selector_options_product('Iboss_product_group_info_model', 'id', 'name', array('id' => "asc"),array("type"=>'FA Product'),'product_group_insurer');
        foreach ($iboss_product_group_insurer_id as $key => $val) {
            $data->iboss_product_group_insurer_id_options[$key] = $val;
        }
		
		
		
        $policy_status_id = $this->_selector_options('Iboss_dict_policy_status_model', 'id', 'name', array('id' => "asc"),array('business_class_id'=>'1','status' => "Active"));
        foreach ($policy_status_id as $key => $val) {
            $data->policy_status_options[$key] = $val;
        }
		
		
		//Business Status
		$data->business_status_options = array("0" => "-- Select Business Status --");
        $business_status_id = $this->_selector_options('Iboss_dict_business_status_model', 'id', 'name', array('id' => "asc"),array('business_class_id'=>'4','status' => "Active"));
        foreach ($business_status_id as $key => $val) {
            $data->business_status_options[$key] = $val;
        }
		
		$data->iboss_acc_policy_owner_row =function($row_unique_id,$row_id,$filed_name){
				
				$row_value_return=  $this->chek_the_name($row_unique_id,$row_id,$filed_name);

				
				return $row_value_return;
				
				};
				
				
		
		
		if($unique_id=='ALL'){
		$data->index = $this->Iboss_acc_group_policy_info_model->retrieve(array('delete_log'=>"False"));	
		}else{
		$data->index = $this->Iboss_acc_group_policy_info_model->retrieve(array('delete_log'=>"False",'iboss_crm_unique_id'=>$unique_id));
		}		
			
		$this->load->view("iboss_master_crm/iboss_group_policy_info_account_summary", $data);
		
		return;
	}
	

		function investment_info($unique_id,$far_code) {
		
		$this->load->model("Iboss_acc_inv_info_model");
        
		
		
		$data = $this->Iboss_acc_inv_info_model->init_data();
		$data->license=biz_licensing_farcode_result($far_code);
		$data->templates = array('datatables');
		$data->unique_id=$unique_id;
		$data->account_tab_type=4;
		$data->main_far_code=$far_code;
		$data->client_nric_name=$this->chek_the_name($unique_id,'','r1');
    $data->passport=$this->chek_the_name($unique_id,'','r6');
    $data->fin_no=$this->chek_the_name($unique_id,'','r7');
    $data->nric_no=$this->chek_the_name($unique_id,'','r2');
		
		$farcode = $this->_selector_farcode_policy();
        foreach ($farcode as $key => $val) {
            $data->farcode_options[$key] = $val;
        } 
		
		$this->load->view("iboss_master_crm/iboss_inv_info_account_summary", $data);
		
		return;
	}

	function other_services_info($unique_id,$far_code){

		$this->load->model("Iboss_acc_other_services_info_model");

		$data = $this->Iboss_acc_other_services_info_model->init_data();
		$data->license=biz_licensing_farcode_result($far_code);
		$data->templates = array('datatables');
		$data->unique_id=$unique_id;
		$data->account_tab_type=5;
		$data->main_far_code=$far_code;
		$data->client_nric_name=$this->chek_the_name($unique_id,'','r1');
    $data->passport=$this->chek_the_name($unique_id,'','r6');
    $data->fin_no=$this->chek_the_name($unique_id,'','r7');
    $data->nric_no=$this->chek_the_name($unique_id,'','r2');
		
		
		 $farcode = $this->_selector_farcode_policy();
        foreach ($farcode as $key => $val) {
            $data->farcode_options[$key] = $val;
        } 

      $business_status = $this->_selector_options('Iboss_dict_business_status_model', 'id', 'name', array('id' => "asc"),array('business_class_id'=>'5','status' => "Active"));
        foreach ($business_status as $key => $val) {
            $data->business_status_options[$key] = $val;
        }

      $product_status = $this->_selector_options('Iboss_product_other_info_model', 'id', 'name', array('id' => "asc"));
        foreach ($product_status as $key => $val) {
            $data->product_options[$key] = $val;
        }  


	$sql="SELECT t1.id as id,t1.iboss_crm_unique_id as iboss_crm_unique_id,t1.servicing_far as far_code,t3.iboss_preferred_name as iboss_preferred_name , t4.identification_no as identification_no,t4.nric_name as nric_name,t1.case_reference_number as case_reference_number,t1.business_status as  business_status ,t1.name_of_services as product from  iboss_acc_other_services_info  as t1 left join iboss_farops_far_info as t3 on t1.far_code=t3.iboss_far_code left join vw_iboss_acc_other_services_crm_info as t4 on (t4.unique_id=t1.iboss_crm_unique_id and t4.id = t1.id) 
where t1.delete_log='False' and t1.iboss_crm_unique_id='".$unique_id."' and t1.servicing_far = '".$far_code."' ORDER BY id DESC" ;


				$rs = $this->iboss_read->query($sql);
               $data->index= $rs->result();

$this->load->view("iboss_master_crm/iboss_other_services_info_account_summary", $data);

	}
	
	
	function other_services_info_old($unique_id,$far_code) {
		
		$this->load->model("Iboss_acc_other_services_info_model");

		$data = $this->Iboss_acc_other_services_info_model->init_data();
		$data->license=biz_licensing_farcode_result($far_code);
		$data->templates = array('datatables');
		$data->unique_id=$unique_id;
		$data->account_tab_type=5;
		$data->main_far_code=$far_code;
		$data->client_nric_name=$this->chek_the_name($unique_id,'','r1');
		
		
		 $farcode = $this->_selector_farcode_policy();
        foreach ($farcode as $key => $val) {
            $data->farcode_options[$key] = $val;
        } 
		 
        $bi_id = $this->_selector_options('Iboss_product_li_info_model', 'id', 'name', array('id' => "asc"));
        foreach ($bi_id as $key => $val) {
            $data->bi_id_options[$key] = $val;
			
        }
		 
			
            $iboss_dict_li_product_type_id = $this->_selector_options('Iboss_dict_li_product_type_model', 'id', 'name', array('id' => "asc"));
				foreach ($iboss_dict_li_product_type_id as $key => $val) {
					$data->iboss_dict_li_product_type_id_options[$key] = $val;
				}
				
				
				/* $iboss_product_li_insurer_id =$this->_selector_options_product('Iboss_product_li_info_model', 'id', 'name', array('id' => "asc"),array("type"=>'FA Product'),'product_li_insurer');
        foreach ($iboss_product_li_insurer_id as $key => $val) {
            $data->iboss_product_li_insurer_id_options[$key] = $val;
        }
		 */
		
		
        $policy_status_id = $this->_selector_options('Iboss_dict_policy_status_model', 'id', 'name', array('id' => "asc"),array('business_class_id'=>'1','status' => "Active"));
        foreach ($policy_status_id as $key => $val) {
            $data->policy_status_options[$key] = $val;
        }
		
		
		//Business Status
		$data->business_status_options = array("0" => "-- Select Business Status --");
        $business_status_id = $this->_selector_options('Iboss_dict_business_status_model', 'id', 'name', array('id' => "asc"),array('business_class_id'=>'1','status' => "Active"));
        foreach ($business_status_id as $key => $val) {
            $data->business_status_options[$key] = $val;
        }
		
		$data->iboss_acc_policy_owner_row =function($row_unique_id,$row_id,$filed_name){
				
				$row_value_return=  $this->chek_the_name($row_unique_id,$row_id,$filed_name);

				
				return $row_value_return;
				
				};
				
				
		
		if($unique_id=='ALL'){
		$data->index = $this->Iboss_acc_other_services_info_model->retrieve(array('delete_log'=>"False"));	
		}else{
		$data->index = $this->Iboss_acc_other_services_info_model->retrieve(array('delete_log'=>"False",'iboss_crm_unique_id'=>$unique_id));
		}	
		$this->load->view("iboss_master_crm/iboss_other_services_info_account_summary", $data);
		
		return;
	}

	
public function upload_documents($unique_id,$far_code)
 {
 	$this->load->model("Iboss_doc_mgt_info_model");


	$data->templates = array('datatables','icheck','chosen','select2','datepicker');
	$data->unique_id=$unique_id;
	$data->account_tab_type=6;
	$data->main_far_code=$far_code;
	$data->client_nric_name=$this->chek_the_name($unique_id,'','r1');
  $data->passport=$this->chek_the_name($unique_id,'','r6');
  $data->fin_no=$this->chek_the_name($unique_id,'','r7');
  $data->nric_no=$this->chek_the_name($unique_id,'','r2');
	
	
	 $farcode = $this->_selector_farcode_policy();
    foreach ($farcode as $key => $val) {
        $data->far_name[$key] = $val;
    } 

    $data->biz_class = array("" => "-- Select List  --");
	$data->biz_class += biz_class_index_result('yes');

    $data->document_type_options = array("" => "-- Select List  --");
    $document_type = $this->_selector_options('Iboss_dict_document_type_model', 'id', 'name', array('id' => "asc"),array('status' => "Active"));
    foreach ($document_type as $key => $val) 
    {
        $data->document_type_options[$key] = $val;
    }

    $data->get_task_details = $this->_selector_options('Iboss_dict_doc_task_model', 'id', 'name', array('id' => "asc"),array('status' => "Active"));

    $data->get_biz_partner_name_options = $this->_selector_options('Iboss_dict_fa_company_model', 'id', 'name', array('id' => "asc"),array('status' => "Active"));
    
	$data->iboss_provider_name = $this->_selector_provider_details();
	 
	$data->license=biz_licensing_farcode_result($far_code);

	$data->other_services_type= $this->_selector_options('Iboss_dict_type_of_services_model', 'id', 'name', array('name' => "asc"),array('status' => "Active",'iboss_dict_biz_class_id'=>5));

	// $data->index = $this->Iboss_doc_mgt_info_model->retrieve(['far_code'=>$far_code,'iboss_unique_id'=>$unique_id,'restricted_document'=>'0']);
	$data->index = $this->Iboss_doc_mgt_info_model->retrieve(['iboss_unique_id'=>$unique_id,'restricted_document'=>'0'],null,null,['upload_on'=>'desc']);
	
	$this->load->view("iboss_master_crm/iboss_upload_documents_account_summary", $data);
		
	return;
 }
	
	
function chek_the_name($row_unique_id,$row_id,$filed_name){
		
		        $check = preg_match("/Corp/", $row_unique_id);
				if($check==true)
				{

$sql="SELECT business_name,biz_reg_no,biz_reg_date FROM iboss_crm_corporate_info where unique_id='".$row_unique_id."'" ;

				$rs = $this->db->query($sql);
               $get_data= $rs->result();

					//$get_data = $this->Crm_corporate_info_model->retrieve(['unique_id'=>$row_unique_id]);
					if($filed_name=='r1')
					{
					$row_value_return=$get_data[0]->business_name;
				    }
					if($filed_name=='r2')
					{
					$row_value_return=$get_data[0]->biz_reg_no;
				    }
					if($filed_name=='r3')
					{
					$row_value_return=$get_data[0]->biz_reg_date;
				    }
					if($filed_name=='r4')
					{
					$row_value_return='';
				    }
					if($filed_name=='r5')
					{
					$row_value_return='';
				    }
					
									
				}else{
					$sql="SELECT nric_name,identification_no,dob,passport_no,fin_no FROM iboss_crm_personal_info where unique_id='".$row_unique_id."'" ;

				$rs = $this->iboss_read->query($sql);
               $get_data= $rs->result();

					//$get_data = $this->Crm_personal_info_model->retrieve(['unique_id'=>$row_unique_id]);
					if($filed_name=='r1')
					{
					$row_value_return=$get_data[0]->nric_name;
				    }
					if($filed_name=='r2')
					{
					$row_value_return=$get_data[0]->identification_no;
				    }
					if($filed_name=='r3')
					{
					$row_value_return=$get_data[0]->dob;
				    }
					if($filed_name=='r4')
					{
					           /*  if(($get_data[0]->dob !='0000-00-00')&&(!empty($get_data[0]->dob)))
									 {
										$bday = new DateTime($get_data[0]->dob);
										$today = new DateTime(date('Y-m-d').' 00:00:00');
										$diff = $today->diff($bday);
										$row_value_return=$diff->y;
									 } */
						$row_value_return= age_last_birthday($get_data[0]->dob);	 
						
				    }
					if($filed_name=='r5')
					{
						
						
									/*  if(($get_data[0]->dob !='0000-00-00')&&(!empty($get_data[0]->dob)))
									 {	
										$bday = new DateTime($get_data[0]->dob);
										$today = new DateTime(date('Y-m-d').' 00:00:00');
										$diff = $today->diff($bday);
										$row_value_return=$diff->y+1;
									 }
					 */
					 
					 $row_value_return= age_next_birthday($get_data[0]->dob);	 
					 
					
				    }

            if($filed_name=='r6')
          {
            $row_value_return=$get_data[0]->passport_no;
            }

              if($filed_name=='r7')
          {
            $row_value_return=$get_data[0]->fin_no;
            }
					
					
					
				}
		
		return $row_value_return;
		
}

	
	
function chek_the_name_with_policy($row_unique_id,$policy_id,$filed_name,$type)
{
	
					if(empty($policy_id))
					{
					return 'Row Id Empty';
					}
					
				 
				  $phonecode_id_options = $this->_selector_phonecode('Iboss_dict_country_model','id','name',array('id'=>'asc'));
				
				  $check = preg_match("/Corp/", $row_unique_id);
				
				
		            $record= $this->Iboss_acc_master_crm_info_model->retrieve( array( "iboss_acc_".$type."_policy_info_id" => $policy_id,'iboss_crm_unique_id'=>$row_unique_id ),null,null,null,"iboss_acc_".$type."_client_info");
		        
					$policy_filed_name= "iboss_acc_".$type."_policy_info_id";
					
					if(!empty($record[0]->$policy_filed_name) and $record[0]->$policy_filed_name !='0')
					{
					$client_info_policy_or_uuid=$policy_filed_name;
					$client_info_policy_or_uuid_value=$record[0]->$policy_filed_name;
					
				
					}else{
                     
					return ;

					}
				
				if($check==true)
				{
					
$get_data = $this->Iboss_acc_master_crm_info_model->retrieve( array( "unique_id" => $row_unique_id ,$client_info_policy_or_uuid=>$client_info_policy_or_uuid_value,'delete_log'=>'False'),null,null,null,'iboss_acc_li_crm_corporate_info');

$get_contact_data = $this->Iboss_acc_master_crm_info_model->retrieve( array( "unique_id" => $row_unique_id ,$client_info_policy_or_uuid=>$client_info_policy_or_uuid_value,'delete_log'=>'False'),null,null,null,'iboss_acc_li_crm_contact_info');

					if($filed_name=='r1')
					{
					$row_value_return=$get_data[0]->business_name;
				    }
					if($filed_name=='r2')
					{
					$row_value_return=$get_data[0]->biz_reg_no;
				    }
					if($filed_name=='r3')
					{
					$row_value_return=$get_data[0]->biz_reg_date;
				    }
					if($filed_name=='r4')
					{
					$row_value_return='';
				    }
					if($filed_name=='r5')
					{
					$row_value_return='';
				    }
					
					if($filed_name=='r6')
					{
						$row_value_return='';
						if(!empty($get_contact_data)){	
						$row_value_return=$phonecode_id_options[$get_contact_data[0]->primary_office_code].' '.$get_contact_data[0]->primary_office;
						}
				    }
					
					
									
				}else{
					$get_data = $this->Iboss_acc_master_crm_info_model->retrieve( array( "unique_id" => $row_unique_id ,$client_info_policy_or_uuid=>$client_info_policy_or_uuid_value,'delete_log'=>'False'),null,null,null,'iboss_acc_li_crm_personal_info');
					
$get_contact_data = $this->Iboss_acc_master_crm_info_model->retrieve( array( "unique_id" => $row_unique_id ,$client_info_policy_or_uuid=>$client_info_policy_or_uuid_value,'delete_log'=>'False'),null,null,null,'iboss_acc_li_crm_contact_info');
					if($filed_name=='r1')
					{
					$row_value_return=$get_data[0]->nric_name;
				    }
					if($filed_name=='r2')
					{
					$row_value_return=$get_data[0]->identification_no;
				    }
					if($filed_name=='r3')
					{
					$row_value_return=$get_data[0]->dob;
				    }
					if($filed_name=='r4')
					{
					
								$bday = new DateTime($get_data[0]->dob);
								$today = new DateTime(date('Y-m-d').' 00:00:00');
								$diff = $today->diff($bday);
							    $row_value_return=$diff->y;
						
				    }
					if($filed_name=='r5')
					{
										
								$bday = new DateTime($get_data[0]->dob);
								$today = new DateTime(date('Y-m-d').' 00:00:00');
								$diff = $today->diff($bday);
								$row_value_return=$diff->y+1;
					
					
				    }
					
					if($filed_name=='r6')
					{
						$row_value_return='';
						if(!empty($get_contact_data)){	
							$row_value_return=$phonecode_id_options[$get_contact_data[0]->primary_code].''.$get_contact_data[0]->primary_contact;
						}
				    }
					
					
					
					
				}
		
		return $row_value_return;	
	
}

	function _selector_farcode_policy()
	{
		if($this->session->userdata('consult_selector_options'))
		{
		
		$selector_options = $this->session->userdata('consult_selector_options');
			
		}else{
		 $selector_options = selector_consultans();	
		 $this->session->set_userdata('consult_selector_options',$selector_options);
		}
		Return $selector_options;
	}


function _selector_options_product($model,$index,$option,$orderby,$where=null,$function_to_call) {
		$this->load->model($model);
		$result = $this->$model->$function_to_call($where, null, 0, $orderby);
		$selector_options = array();
		foreach($result as $key=>$val) {
			$selector_options[$val->$index] = $val->$option;
		}
		Return $selector_options;
	}
	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
//______________________________________________________________________________________________________________________//	
	
	
	
	
	
	
	
	
	
	
	
	
	
//View	
	
function crm_personal_info_view($unique_id=null) { 
	
		//print_r($unique_id);
		
			
		$data = $this->Crm_personal_info_model->init_data();
		
		
		if(!empty($unique_id)){
			
		$record = $this->Crm_personal_info_model->retrieve( array( "unique_id" => $unique_id ) );
		$this->_nitro_send_post_to_view($record[0],$data);
		
		
		$data->templates = array('datatables','datepicker','icheck','chosen','select2');
		
		
		$data->main_crm_type='view';
		$data->crm_tab_type=1;
		//$data->id=$id;
		$data->far_code=$this->session->userdata('redirect_name_far_code');
         
		//Selector Options
		//$data->country_id_options = array(""=>"-- Please Select The Country --");
		$data->country_id_options = $this->_selector_options('Iboss_dict_country_model','id','name',array('id'=>'asc'));

		//$data->nationality_id_options = array(""=>"-- Please Select Nationality --");
		$data->nationality_id_options = $this->_selector_options('Iboss_dict_nationality_model','id','name',array('id'=>'asc'),array('status'=>"Active"));

		//$data->race_id_options = array(""=>"-- Please Select Race --");
		$data->race_id_options = $this->_selector_options('Iboss_dict_race_model','id','name',array('id'=>'asc'),array('status'=>"Active"));

//new add dictionary				
		$data->salutation_options = $this->_selector_options('Iboss_dict_salutation_model', 'id', 'name', array('id' => "asc"),array('status'=>"Active"));        
		
		
		$data->gender_options = $this->_selector_options('Iboss_dict_gender_model', 'id', 'name', array('id' => "asc"),array('status'=>"Active"));
        
		
		$data->marital_status_options = $this->_selector_options('Iboss_dict_marital_status_model', 'id', 'name', array('id' => "asc"),array('status'=>"Active"));
		
		
		$data->entry_pass_options = $this->_selector_options('Iboss_dict_entry_pass_model', 'id', 'name', array('id' => "asc"),array('status'=>"Active"));
        
//new end dictionary		

		//$data->religion_id_options = array(""=>"-- Please Select Religion --");
		$data->religion_id_options = $this->_selector_options('Iboss_dict_religion_model','id','name',array('id'=>'asc'),array('status'=>"Active"));
     	//End 
		
		
		//NRIC Name
		$data->nric_name_options = $this->_selector_options('Crm_personal_info_model','id','nric_name',array('id'=>'asc'),array('status'=>"Active",'relationship'=>"self",'delete_log'=>"False"));
        //End 
		
		//$data->view_details = $this->Crm_personal_info_model->retrieve( array( "unique_id" => $unique_id) );
		
		
		$data->far_id_options = array("" => "-- Select FAR --");
        $far_id = $this->_selector_farcode();
        foreach ($far_id as $key => $val) {
            $data->far_id_options[$key] = $val;
        }
		
		
		
	
		}
		
		
		if(empty($unique_id))
		{
			
		}else{
			if ( empty( $_POST ) ) {
				return $this->load->view( "iboss_master_crm/view/iboss_crm_personal_info_add_edit", $data );
			}else {
				
				//print_r($_POST );
				//die();
				$this->_nitro_set_rules();
				if ( $this->form_validation->run() == false ) {
					$this->_nitro_send_post_to_view( $_POST, $data );
					return $this->load->view( "iboss_master_crm/iboss_crm_personal_info_add_edit", $data );
				}
				//$_POST['id'] = $id;
				//$this->Crm_personal_info_model->set( $_POST ); 
				
				
				
			}
			
		}
		
	}




	

	function crm_contact_info_view($unique_id=null) { 
	
		
		$data = $this->Crm_contact_info_model->init_data();
		
		
		
		if(!empty($unique_id)){
			
		$record = $this->Crm_contact_info_model->retrieve( array( "unique_id" => $unique_id ) );
		$this->_nitro_send_post_to_view($record[0],$data);
		
		$data->templates = array('datatables','datepicker','icheck','chosen','select2');
		
		$data->main_crm_type=$main_crm_type;
        $data->title_corp='';
		if($main_crm_type=='CORP')
		{
			$data->title_corp='Corp';
		}

		$data->crm_tab_type=2;
		//$data->id=$id;
		$data->main_crm_type='view';
		//Selector Options
		//$data->country_id_options = array(""=>"-- Please Select The Country --");
		$data->country_id_options = $this->_selector_options('Iboss_dict_country_model','id','name',array('id'=>'asc'));
        
		 //**************************************************address_list*********************************/
		$data->contact_labels = $this->Crm_contact_info_model->get_field_comments();
		$data->enum_contact = $this->Crm_contact_info_model->get_enum();#enum data to be included
		//********************************************address_list**********************************/
		
		
		 //**************************************************address_list*********************************/
		$data->address_labels = $this->Crm_address_info_model->get_field_comments();
		$data->enum_address = $this->Crm_address_info_model->get_enum();#enum data to be included
		//********************************************address_list**********************************/
		
		
		}
		
		
		if(empty($unique_id))
		{
			
		}else{
			if ( empty( $_POST ) ) {
				return $this->load->view( "iboss_master_crm/view/iboss_crm_contact_info_add_edit", $data );
			}else {
				$this->_nitro_set_rules();
				if ( $this->form_validation->run() == false ) {
					$this->_nitro_send_post_to_view( $_POST, $data );
					return $this->load->view( "iboss_master_crm/iboss_crm_contact_info_add_edit", $data );
				}
				
			}
			
		}
		
	}
	
	
	
	
	
//End New Design	


	
	function crm_educational_info_view($id=null,$main_crm_type=null) { 
	
		
		   
		
		$data = $this->Crm_contact_info_model->init_data();
		$data->templates = array('datatables','datepicker','icheck','chosen','select2');
		
        $data->main_crm_type=$main_crm_type;
		$data->crm_tab_type=3;
		$data->id=$id;
		if($main_crm_type=='CORP')
		{
			$data->title_corp='Corp';
		}
		$data->main_crm_type='view';
		//Selector Options
		//$data->country_id_options = array(""=>"-- Please Select The Country --");
		$data->country_id_options = $this->_selector_options('Iboss_dict_country_model','id','name',array('id'=>'asc'));

		
		if(!empty($id)){
			
		$record = $this->Crm_contact_info_model->retrieve( array( "id" => $id ) );
		$this->_nitro_send_post_to_view($record[0],$data);
	
		}
		
		
		if(empty($id))
		{
			if ( empty( $_POST ) ) {
			return $this->load->view( "iboss_master_crm/iboss_crm_educational_info_add_edit", $data );
			}else {
				$this->_nitro_set_rules();
				$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
				if ( $this->form_validation->run() == false ) {
					$this->_nitro_send_post_to_view( $_POST, $data );
					return $this->load->view( "iboss_master_crm/iboss_crm_educational_info_add_edit", $data );
				}
				$this->Crm_contact_info_model->set( $_POST );
				redirect( "iboss_master_crm_info/index" );
			}
			
		}else{
			if ( empty( $_POST ) ) {
				return $this->load->view( "iboss_master_crm/view/iboss_crm_educational_info_add_edit", $data );
			}else {
				$this->_nitro_set_rules();
				if ( $this->form_validation->run() == false ) {
					$this->_nitro_send_post_to_view( $_POST, $data );
					return $this->load->view( "iboss_master_crm/iboss_crm_educational_info_add_edit", $data );
				}
				$_POST['id'] = $id;
				$this->Crm_contact_info_model->set( $_POST );
				redirect( "iboss_master_crm_info/index" );
			}
			
		}
		
	}
	
	




//End New Design	


function crm_compliance_info_view($id=null,$main_crm_type=null) { 
	
		 
		
		$data = $this->Crm_compliance_info_model->init_data();
		$data->templates = array('datatables','datepicker','icheck','chosen','select2');
		
		$data->main_crm_type=$main_crm_type;
     	$data->crm_tab_type=4;
		$data->id=$id;
		
		if($main_crm_type=='CORP')
		{
			$data->title_corp='Corp';
		}
		$data->main_crm_type='view';
        //**************************************************Compliance_list*********************************/
		$data->compliance_labels = $this->Crm_compliance_info_model->get_field_comments();
		$data->enum_compliance = $this->Crm_compliance_info_model->get_enum();#enum data to be included
		//********************************************address_list**********************************/
		$data->department_options=$this->_selector_options('Ums_department_info_model','id','name','name');
		$data->cdd_outcome_options = $this->_selector_options('Iboss_dict_crm_outcome_model','id','name',null,array('outcome_type'=>'CDD'));
		$data->ecdd_outcome_options = $this->_selector_options('Iboss_dict_crm_outcome_model','id','name',null,array('outcome_type'=>'ECDD'));
		$data->ecdd_reporting_outcome_options = $this->_selector_options('Iboss_dict_crm_outcome_model','id','name',null,array('outcome_type'=>'ECDD Reporting'));
															
														
		
		//Selector Options
		//$data->country_id_options = array(""=>"-- Please Select The Country --");
		$data->country_id_options = $this->_selector_options('Iboss_dict_country_model','id','name',array('id'=>'asc'));

		
		if(!empty($id)){
			
		$record = $this->Crm_contact_info_model->retrieve( array( "id" => $id ) );
		$this->_nitro_send_post_to_view($record[0],$data);
	
		}
		
		
		if(empty($id))
		{
			if ( empty( $_POST ) ) {
			return $this->load->view( "iboss_master_crm/iboss_crm_compliance_info_add_edit", $data );
			}else {
				$this->_nitro_set_rules();
				$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
				if ( $this->form_validation->run() == false ) {
					$this->_nitro_send_post_to_view( $_POST, $data );
					return $this->load->view( "iboss_master_crm/iboss_crm_compliance_info_add_edit", $data );
				}
				$this->Crm_contact_info_model->set( $_POST );
				redirect( "iboss_master_crm_info/index" );
			}
			
		}else{
			if ( empty( $_POST ) ) {
				return $this->load->view( "iboss_master_crm/view/iboss_crm_compliance_info_add_edit", $data );
			}else {
				$this->_nitro_set_rules();
				if ( $this->form_validation->run() == false ) {
					$this->_nitro_send_post_to_view( $_POST, $data );
					return $this->load->view( "iboss_master_crm/iboss_crm_compliance_info_add_edit", $data );
				}
				$_POST['id'] = $id;
				$this->Crm_contact_info_model->set( $_POST );
				redirect( "iboss_master_crm_info/index" );
			}
			
		}
		
	}
	
	

	
//End New Design	



//End New Design	


function crm_marketing_info_view($id=null,$main_crm_type=null) { 
	
		
		
		$data = $this->Crm_compliance_info_model->init_data();
		$data->templates = array('datatables','datepicker','icheck','chosen','select2');
		
        $data->main_crm_type='view';
		$data->crm_tab_type=5;
		$data->id=$id;
		if($main_crm_type=='CORP')
		{
			$data->title_corp='Corp';
		}
		
		$data->main_crm_type='view';
		//Selector Options
		//$data->country_id_options = array(""=>"-- Please Select The Country --");
		$data->country_id_options = $this->_selector_options('Iboss_dict_country_model','id','name',array('id'=>'asc'));

		
		if(!empty($id)){
			
		$record = $this->Crm_contact_info_model->retrieve( array( "id" => $id ) );
		$this->_nitro_send_post_to_view($record[0],$data);
	
		}
		
		
		if(empty($id))
		{
			if ( empty( $_POST ) ) {
			return $this->load->view( "iboss_master_crm/iboss_crm_marketing_info_add_edit", $data );
			}else {
				$this->_nitro_set_rules();
				$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
				if ( $this->form_validation->run() == false ) {
					$this->_nitro_send_post_to_view( $_POST, $data );
					return $this->load->view( "iboss_master_crm/iboss_crm_marketing_info_add_edit", $data );
				}
				$this->Crm_contact_info_model->set( $_POST );
				redirect( "iboss_master_crm_info/index" );
			}
			
		}else{
			if ( empty( $_POST ) ) {
				return $this->load->view( "iboss_master_crm/view/iboss_crm_marketing_info_add_edit", $data );
			}else {
				$this->_nitro_set_rules();
				if ( $this->form_validation->run() == false ) {
					$this->_nitro_send_post_to_view( $_POST, $data );
					return $this->load->view( "iboss_master_crm/iboss_crm_marketing_info_add_edit", $data );
				}
				$_POST['id'] = $id;
				$this->Crm_contact_info_model->set( $_POST );
				redirect( "iboss_master_crm_info/index" );
			}
			
		}
		
	}
	
	
	
	
	
	
//End New Design	
	
 
	
	
function common_delete( $key = "",$tbl_name="", $policy_id="") 
	{


		
				$_POST_update['delete_log']='True';
				$this->db->where('id', $key);
				$this->db->update("$tbl_name", $_POST_update);				
				
				//log
				$this->db->crm_table_audit_delete($tbl_name, array("id" => $key), $this->session->userdata('name'),'delete');
				//End
	
		
	}	
	

	
	
	
//REfer Page




function refer_crm_info($policy_owner_type,$client_name,$relationship,$refer_crm_type,$main_name=null,$main_id=null) 
{
	
										$policy_owner_type=  urldecode($policy_owner_type);
										$client_name=  urldecode($client_name);
										if($client_name=='s2'){
										$client_name='';	
										}
										$relationship=  urldecode($relationship);
										if($relationship =='Select an Option')
										{
										$relationship='';	
										}
										$relationship=  urldecode($relationship);
										
										$refer_crm_type=  urldecode($refer_crm_type);
										
										$record_num = $this->agent->referrer();
										
										$this->session->unset_userdata('refer_url_page');
										$this->session->unset_userdata('refer_policy_owner_type');
										$this->session->unset_userdata('refer_client_name');
										$this->session->unset_userdata('refer_relationship');
										$this->session->unset_userdata('refer_iboss_client_info_table');


										
									    $check = preg_match("/iboss_acc_li_policy_info/", $record_num);
												if($check==true)
												{   
											        //Refer URL
													$this->session->set_userdata('refer_url_page',$record_num);
													//Owner or Life Insured
													$this->session->set_userdata('refer_policy_owner_type',$policy_owner_type);
													//NRIC Client Name
													$this->session->set_userdata('refer_client_name',$client_name);
													//Relation ship
													$this->session->set_userdata('refer_relationship',$relationship);
													//Store the Table
													$this->session->set_userdata('refer_iboss_client_info_table','iboss_acc_li_client_info');
													//Policy id
													$this->session->userdata('iboss_life_policy_id');
													//uuid
													$this->session->userdata('iboss_acc_li_client_info_uuid');
													
												    //Refer FAR Code
													$this->session->userdata('redirect_name_far_code');
												}
												
												
												$check_gi = preg_match("/iboss_acc_gi_policy_info/", $record_num);
												if($check_gi==true)
												{   
											        //Refer URL
													$this->session->set_userdata('refer_url_page',$record_num);
													//Owner or Life Insured
													$this->session->set_userdata('refer_policy_owner_type',$policy_owner_type);
													//NRIC Client Name
													$this->session->set_userdata('refer_client_name',$client_name);
													//Relation ship
													$this->session->set_userdata('refer_relationship',$relationship);
													//Store the Table
													$this->session->set_userdata('refer_iboss_client_info_table','iboss_acc_gi_client_info');
													//Policy id
													$this->session->userdata('iboss_life_policy_id');
													//uuid
													$this->session->userdata('iboss_acc_gi_client_info_uuid');
													
												    //Refer FAR Code
													$this->session->userdata('redirect_name_far_code');
												}
												
												
												$check_group = preg_match("/iboss_acc_group_policy_info/", $record_num);
												if($check_group==true)
												{   
											        //Refer URL
													$this->session->set_userdata('refer_url_page',$record_num);
													//Owner or Life Insured
													$this->session->set_userdata('refer_policy_owner_type',$policy_owner_type);
													//NRIC Client Name
													$this->session->set_userdata('refer_client_name',$client_name);
													//Relation ship
													$this->session->set_userdata('refer_relationship',$relationship);
													//Store the Table
													$this->session->set_userdata('refer_iboss_client_info_table','iboss_acc_group_client_info');
													//Policy id
													$this->session->userdata('iboss_life_policy_id');
													//uuid
													$this->session->userdata('iboss_acc_group_client_info_uuid');
													
												    //Refer FAR Code
													$this->session->userdata('redirect_name_far_code');
												}
												
												$check_other = preg_match("/iboss_acc_other_services_info/", $record_num);
												if($check_other==true)
												{   
											        //Refer URL
													$this->session->set_userdata('refer_url_page',$record_num);
													//Owner or Life Insured
													$this->session->set_userdata('refer_policy_owner_type',$policy_owner_type);
													//NRIC Client Name
													$this->session->set_userdata('refer_client_name',$client_name);
													//Relation ship
													$this->session->set_userdata('refer_relationship',$relationship);
													//Store the Table
													$this->session->set_userdata('refer_iboss_client_info_table','iboss_acc_other_services_client_info');
													//Policy id
													$this->session->userdata('crm_save_details');
													//uuid
													$this->session->userdata('iboss_acc_other_services_client_info_uuid');
													
												    //Refer FAR Code
													$this->session->userdata('redirect_name_far_code');
												}
												
												
												
												$check_other = preg_match("/iboss_acc_inv_info/", $record_num);
												if($check_other==true)
												{   
											        //Refer URL
													$this->session->set_userdata('refer_url_page',$record_num);
													//Owner or Life Insured
													$this->session->set_userdata('refer_policy_owner_type',$policy_owner_type);
													//NRIC Client Name
													$this->session->set_userdata('refer_client_name',$client_name);
													//Relation ship
													$this->session->set_userdata('refer_relationship',$relationship);
													//Store the Table
													$this->session->set_userdata('refer_iboss_client_info_table','iboss_acc_inv_client_info');
													//Policy id
													$this->session->set_userdata('main_name',$main_name);
													$this->session->set_userdata('main_id',$main_id);
													//uuid
													$this->session->userdata('check_uuid');
													
												    //Refer FAR Code
													$this->session->userdata('redirect_name_far_code');
												}
												
												
												if($refer_crm_type=='personal')	
												{											
												redirect( "iboss_master_crm_info/crm_personal_info" );
												}else{
													redirect( "iboss_master_crm_info/crm_corporate_info" );
												}
												
												
												
	
}






function refer_acc_crm_save($table,$unique_id,$iboss_client_info_name,$row_id,$set,$edit_crm_type_acc)
{
	

			   $audit_update= $this->db->get_where("$table", array("unique_id"=>$unique_id,$iboss_client_info_name=>$row_id));
               $id=$audit_update->row()->id;

               if(!empty($id))
			   {
				   $array = array();
				   foreach ($audit_update->row() as $key=>$kk)
				   {
					 $array[$key]=$kk;
				   }
		
				$result=array_diff_assoc($array,$set);
				foreach($result as $key=>$value)
				{
					foreach($set as $k=>$val)
					{
						if($key == $k)
					{   
				//echo "<pre>"	;
				$_update[$key]=$val;
		//$sql="insert into iboss_product_log(`page_name`,`table_id`,`field_name`,`old_value`,`new_value`,`username`,`action_name`,`current_date_time`,`biz_class`,`iboss_product_id`)values('$table','$table_id','$key','$value','$val','$username','$action','$date','$biz_class','$product_id')";
		//$this->query($sql);
							
						}				
					 
					}	
					
				}

				
				                                       switch($edit_crm_type_acc){
													    case "LI":
														$this->db->where('iboss_acc_li_policy_id', $audit_update->row()->iboss_acc_li_policy_id);
														$this->db->where('unique_id', $audit_update->row()->unique_id);
														$this->db->update($table, $_update);
														break;
													    case "GI":
													   	$this->db->where('iboss_acc_gi_policy_id', $audit_update->row()->iboss_acc_gi_policy_id);
														$this->db->where('unique_id', $audit_update->row()->unique_id);
														$this->db->update($table, $_update);
														break;
														case "GROUP":
														$this->db->where('iboss_acc_group_policy_id', $audit_update->row()->iboss_acc_group_policy_id);
														$this->db->where('unique_id', $audit_update->row()->unique_id);
														$this->db->update($table, $_update);
														break;
														case "OTHER":
														$this->db->where('iboss_acc_other_services_id', $audit_update->row()->iboss_acc_other_services_id);
														$this->db->where('unique_id', $audit_update->row()->unique_id);
														$this->db->update($table, $_update);
														break;
														case "INV":
														$this->db->where('iboss_acc_group_id', $audit_update->row()->iboss_acc_group_id);
														$this->db->where('unique_id', $audit_update->row()->unique_id);
														$this->db->update($table, $_update);
														break;
													
													}		
				
				
				
				
					//$this->db->where('id', $id);
					//$this->db->update($table, $_update);
			   }
		return ;

	
	
	
	
}


function edit_crm_info($redirect_controller_type,$crm_unique_id,$edit_crm_acc,$edit_crm_type_acc) 
{
$record_num = $this->agent->referrer();	
//Refer URL
$this->session->set_userdata('refer_url_page',$record_num);	
$this->session->set_userdata('edit_crm_acc',$edit_crm_acc);	
$this->session->set_userdata('edit_crm_type_acc',$edit_crm_type_acc);
redirect( "iboss_master_crm_info/".$redirect_controller_type."/".$crm_unique_id);	
	
}

	/*public function search($column_name,$table_name)
	{

 		$data = new stdClass();

		$like=$_REQUEST["query"];
			
		$limit='10';
		
        
		 //$sql = "select * from iboss_dict_$table_name where $column_name like '%$keysearch%'limit 10";
		 $sql = "select * from iboss_dict_$table_name where $column_name like '%$keysearch%'limit 10";
	
			
	   //$sql = "select * from iboss_crm_personal_info where nric_name like '%$keysearch%'limit 10";

		$result = $this->db->query($sql);
		
		$total_clients=count($result->result());
			    
		$json = [];
		$json_array = [];
			
	    if($total_clients!=0)
	    {
		    foreach($result->result() as $clients_data)
		    {     
					 
             $json['name']= $clients_data->name;	
			 //$json['name']=$clients_data->nric_name;
		    
		     $json_array[]=$json;
		    }
	    }
	    else
	    {
	    	
	    	$json['name']= "No Data Found";
	    	$json_array[]=$json;
	    }

		header('Content-Type" => application/json');
		echo json_encode($json_array);
	}*/

	public function search($column_name,$table_name,$length)
	{

 		$data = new stdClass();

		$like=$_REQUEST["query"];
			
		$limit='10';
		if($table_name != 'relationship')
		{
			if($length > 0 )
			{
				//$sql = "select * from iboss_dict_$table_name where $column_name like '%$keysearch%'limit 10";
			 $sql = "select * from iboss_dict_$table_name where $column_name like '%$like%' limit 10";
			}
			else{
				$sql = "select * from iboss_dict_$table_name  limit 10";
			}	
	    }else{
		
			        if($length > 0 )
					{
						//$sql = "select * from iboss_dict_$table_name where $column_name like '%$keysearch%'limit 10";
					 $sql = "select * from iboss_dict_$table_name where $column_name like '%$like%' and relationship_type='Personal' and status='Active' limit 10";
					}
					else{
						$sql = "select * from iboss_dict_$table_name  where relationship_type='Personal' and status='Active' limit 10";
					}	

      		
		} 
	
			
	   //$sql = "select * from iboss_crm_personal_info where nric_name like '%$keysearch%'limit 10";

		$result = $this->db->query($sql);
		
		$total_clients=count($result->result());
			    
		$json = [];
		$json_array = [];
			
	    if($total_clients!=0)
	    {
		    foreach($result->result() as $clients_data)
		    {     
					 
             $json['name']= ucwords(strtolower($clients_data->name));
			 //$json['name']=$clients_data->nric_name;
		    
		     $json_array[]=$json;
		    }
	    }
	    else
	    {
	    	
	    	$json['name']= "No Data Found";
	    	$json_array[]=$json;
	    }

		header('Content-Type" => application/json');
		echo json_encode($json_array);
	}
	
	
	
	function corporate_realation_search($column_name,$table_name,$length)
	{

 		$data = new stdClass();

		$like=$_REQUEST["query"];
		$limit='10';
		
		 if($length > 0 )
		 {
       //$sql = "select * from iboss_dict_$table_name where $column_name like '%$keysearch%'limit 10";
        $sql = "select * from iboss_dict_$table_name where $column_name like '%$like%' and relationship_type='Corporate' and status='Active' limit 10";
		}else{
	    $sql = "select * from iboss_dict_$table_name  where relationship_type='Corporate' and status='Active' limit 10";
		}	
		
		
			
	   //$sql = "select * from iboss_crm_personal_info where nric_name like '%$keysearch%'limit 10";

		$result = $this->db->query($sql);
		
		$total_clients=count($result->result());
			    
		$json = [];
		$json_array = [];
			
	    if($total_clients!=0)
	    {
		    foreach($result->result() as $clients_data)
		    {     
					 
             $json['name']= $clients_data->name;	
			 //$json['name']=$clients_data->nric_name;
		    
		     $json_array[]=$json;
		    }
	    }
	    else
	    {
	    	
	    	$json['name']= "No Data Found";
	    	$json_array[]=$json;
	    }

		header('Content-Type" => application/json');
		echo json_encode($json_array);
	}
	
	
	
	
	
	
	



	function copy_paste_crm($unique_id){
		
		
		$crm_type=unqiue_id_spilit($unique_id);
		
		                                           switch($crm_type){
													    case "Inv":
														$id=$this->db->select('id')->from('iboss_crm_personal_info')->limit(1)->order_by('id','DESC')->get()->row()->id;
														$last_insert_id=$id+1;
														$sum_value = 000000 + $last_insert_id;
						                            	$make_unique_id = str_pad($sum_value, 6, '0', STR_PAD_LEFT);
														$m_unique_id = 'Inv'.$make_unique_id ;
														$con_troller="crm_personal_info";
														break;
													    case "Auth":
													   	$id=$this->db->select('id')->from('iboss_crm_personal_info')->limit(1)->order_by('id','DESC')->get()->row()->id;
														$last_insert_id=$id+1;
														$sum_value = 000000 + $last_insert_id;
						                            	$make_unique_id = str_pad($sum_value, 6, '0', STR_PAD_LEFT);
														$m_unique_id = 'Inv'.$make_unique_id ;
														$con_troller="crm_personal_info";
     													break;
														case "Corp":
														$id=$this->db->select('id')->from('iboss_crm_corporate_info')->limit(1)->order_by('id','DESC')->get()->row()->id;
														$last_insert_id=$id+1;
														$sum_value = 000000 + $last_insert_id;
						                            	$make_unique_id = str_pad($sum_value, 6, '0', STR_PAD_LEFT);
														$m_unique_id = 'Corp'.$make_unique_id ;
														$con_troller="crm_corporate_info";
														break;
													    
													}
							  
		
		
		//echo $unique_id;
		save_into_acc_crm_index($unique_id,$m_unique_id,$crm_type);
		redirect( "iboss_master_crm_info/".$con_troller."/".$m_unique_id);
		
	}
	
	
	function acc_crm_contact_info($unique_id, $far_code)
	{
		$this->load->model("Iboss_acc_li_policy_info_model");
		$this->load->model("Iboss_acc_gi_policy_info_model");
		$this->load->model("Iboss_acc_group_policy_info_model");
		
		$data->main_crm_type=unqiue_id_spilit($unique_id);
		
		$data->templates = array('datatables','datepicker','icheck','chosen','select2');
		
		$data->contact_labels = $this->Crm_contact_info_model->get_field_comments();
		$data->enum_contact = $this->Crm_contact_info_model->get_enum();#enum data to be included
		
		$data->phonecode_id_options = $this->_selector_phonecode('Iboss_dict_country_model','id','name',array('id'=>'asc'));
		
		if(!empty($unique_id)){
			
		$record = $this->Crm_contact_info_model->retrieve( array( "unique_id" => $unique_id ,'delete_log'=>'False') );
			
		$record[0]->primary_con_given_date=iso2sg($record[0]->primary_con_given_date);
		$record[0]->home_con_given_date=iso2sg($record[0]->home_con_given_date);
		$record[0]->office_con_given_date=iso2sg($record[0]->office_con_given_date);
		
		$record[0]->primary_office_con_given_date=iso2sg($record[0]->primary_office_con_given_date);
		$record[0]->secondary_office_given_date=iso2sg($record[0]->secondary_office_given_date);
		
		$this->_nitro_send_post_to_view($record[0],$data);
		
		}
		
		$data->policy_number_li = $this->Iboss_acc_li_policy_info_model->retrieve(array('iboss_crm_unique_id'=>$unique_id, 'far_code' =>$far_code));
		
$data->contact_li = $this->Iboss_acc_master_crm_info_model->retrieve(array('unique_id'=>$unique_id, 'iboss_acc_li_policy_info_id' =>$data->policy_number_li[0]->id),null, null,null,'iboss_acc_li_crm_contact_info');		
		
		$data->policy_number_gi = $this->Iboss_acc_gi_policy_info_model->retrieve(array('iboss_crm_unique_id'=>$unique_id, 'far_code' =>$far_code));
		
$data->contact_gi = $this->Iboss_acc_master_crm_info_model->retrieve(array('unique_id'=>$unique_id, 'iboss_acc_gi_policy_info_id' =>$data->policy_number_gi[0]->id),null, null,null,'iboss_acc_gi_crm_contact_info');		
		
		$data->policy_number_group = $this->Iboss_acc_group_policy_info_model->retrieve(array('iboss_crm_unique_id'=>$unique_id, 'far_code' =>$far_code));
	
$data->contact_group = $this->Iboss_acc_master_crm_info_model->retrieve(array('unique_id'=>$unique_id, 'iboss_acc_group_policy_info_id' =>$data->policy_number_group[0]->id),null, null,null,'iboss_acc_group_crm_contact_info');	

$data->account_number_inv = $this->Iboss_acc_inv_info_model->retrieve(array('iboss_crm_unique_id'=>$unique_id));

$data->contact_inv = $this->Iboss_acc_master_crm_info_model->retrieve(array('unique_id'=>$unique_id, 'iboss_acc_group_id' =>$data->account_number_inv[0]->iboss_acc_group_id),null, null,null,'iboss_acc_inv_crm_contact_info');

		
		$this->load->view("iboss_master_crm/iboss_acc_crm_contact_info", $data);
	}
	
	function date_of_birth()
	{
		//print_r($_POST);
		if($_POST['for']=="date_of_birth")
		{
			$dob_last = sg2iso($_POST['dob']);
			$result_value['age_last_birthday'] = age_last_birthday($dob_last);
			$result_value['age_next_birthday'] = age_next_birthday($dob_last);
			
										$index =json_encode($result_value);
										$str = trim($index,']');
										echo trim($str,'[');
		}
		
	}
	
function acc_crm_value()
	{
		
		
		     if($_POST['for']=="acc_crm_value")
			 {
				 
				  if($_POST['save_type']=='acc_crm_type')
				  {
					  
					  if($_POST['type'] != "inv")
					  {
					  
					  if(!empty($_POST['row_id']))
								{			
									$res = $this->Iboss_acc_master_crm_info_model->retrieve(['unique_id'=>$_POST['row_id'], 'iboss_acc_'.$_POST['type'].'_policy_info_id'=>$_POST['main_policy_id']],null, null, null, 'iboss_acc_'.$_POST['type'].'_crm_contact_info');
									// print_r($this->db->last_query());
									// die();
									$index =json_encode($res);
									$str = trim($index,']');
									echo trim($str,'[');
									
								}
					  }
					  else
					  {
						
						if(!empty($_POST['row_id']))
								{			
									$res = $this->Iboss_acc_master_crm_info_model->retrieve(['unique_id'=>$_POST['row_id'], 'iboss_acc_group_id'=>$_POST['main_policy_id']],null, null, null, 'iboss_acc_'.$_POST['type'].'_crm_contact_info');
									// print_r($this->db->last_query());
									// die();
									$index =json_encode($res);
									$str = trim($index,']');
									echo trim($str,'[');
									
								}	
						
					  }
				  }
				  
				  if($_POST['save_type']=='acc_crm_type_address')
				  {
					
					if($_POST['type'] != "inv")
					  {
					  
					  if(!empty($_POST['row_id']))
								{			
									$res = $this->Iboss_acc_master_crm_info_model->retrieve(['unique_id'=>$_POST['row_id'], 'address_type'=>$_POST['address_type'], 'iboss_acc_'.$_POST['type'].'_policy_info_id'=>$_POST['main_policy_id']],null, null, null, 'iboss_acc_'.$_POST['type'].'_crm_address_info');
									//print_r($this->db->last_query());
									//die();
									$index =json_encode($res);
									$str = trim($index,']');
									echo trim($str,'[');
									
								}
					  }
					  else
					  {
						
						if(!empty($_POST['row_id']))
								{			
									$res = $this->Iboss_acc_master_crm_info_model->retrieve(['unique_id'=>$_POST['row_id'], 'address_type'=>$_POST['address_type'], 'iboss_acc_group_id'=>$_POST['main_policy_id']],null, null, null, 'iboss_acc_'.$_POST['type'].'_crm_address_info');
									//print_r($this->db->last_query());
									//die();
									$index =json_encode($res);
									$str = trim($index,']');
									echo trim($str,'[');
									
								}	
						
					  }
					
				  }
				  
				  
				  
				  
			 }
	}

function update_contact_acc_crm($unique_id)
	{
		
		
		if($_POST['update'] == 'Update_all')
		{
			
				$_POST_CONTACT['primary_code']=$_POST['primary_code'];
				$_POST_CONTACT['primary_contact']=$_POST['primary_contact'];
				$_POST_CONTACT['primary_dnc']=$_POST['primary_dnc'];
				$_POST_CONTACT['primary_con_given_date']=sg2iso($_POST['primary_con_given_date']);
				
				$_POST_CONTACT['home_code']=$_POST['home_code'];
				$_POST_CONTACT['home_contact']=$_POST['home_contact'];
				$_POST_CONTACT['home_dnc']=$_POST['home_dnc'];
				$_POST_CONTACT['home_con_given_date']=sg2iso($_POST['home_con_given_date']);
				
				$_POST_CONTACT['office_code']=$_POST['office_code'];				
				$_POST_CONTACT['office_contact']=$_POST['office_contact'];
				$_POST_CONTACT['office_contact_ext']=$_POST['office_contact_ext'];
				$_POST_CONTACT['office_dnc']=$_POST['office_dnc'];
				$_POST_CONTACT['office_con_given_date']=sg2iso($_POST['office_con_given_date']);
				//End 
				
				
				//Corporate
				$_POST_CONTACT['primary_office_code']=$_POST['primary_office_code'];
				$_POST_CONTACT['primary_office']=$_POST['primary_office'];
				$_POST_CONTACT['primary_office_dnc']=$_POST['primary_office_dnc'];
				$_POST_CONTACT['primary_office_con_given_date']=sg2iso($_POST['primary_office_con_given_date']);
				
				$_POST_CONTACT['secondary_office_code']=$_POST['secondary_office_code'];
				$_POST_CONTACT['secondary_office']=$_POST['secondary_office'];
				$_POST_CONTACT['secondary_office_dnc']=$_POST['secondary_office_dnc'];
				$_POST_CONTACT['secondary_office_given_date']=sg2iso($_POST['secondary_office_given_date']);
                //End Corporate
				 
				$_POST_CONTACT['primary_email']=$_POST['primary_email'];
				$_POST_CONTACT['secondary_email']=$_POST['secondary_email'];				
				//$_POST_CONTACT['unique_id']=$unique_id;
				$_POST_CONTACT['date_time']=current_date_time();
				
				$this->db->where(['unique_id'=>$unique_id, 'delete_log'=>"False"]);
				$this->db->update('iboss_crm_contact_info', $_POST_CONTACT);
				
				$store_li_id=array_filter($_POST['store_li_id']);
				
				
					 
					 for($i=0;$i<count($store_li_id);$i++)
							{
							
				
							 //$this->db->where_in($policy_type_id, array($value[$k]));							
							 
							 $this->db->where(['unique_id'=>$unique_id, 'delete_log'=>"False", 'iboss_acc_li_policy_info_id' =>$_POST['store_li_id'][$i]]);
							 $this->db->update('iboss_acc_li_crm_contact_info', $_POST_CONTACT);
							}
							
					
							
				$store_gi_id=array_filter($_POST['store_gi_id']);
				
				
					 
					 for($j=0;$j<count($store_gi_id);$j++)
							{
							 //$this->db->where_in($policy_type_id, array($value[$k]));							
							 $this->db->where(['unique_id'=>$unique_id, 'delete_log'=>"False", 'iboss_acc_gi_policy_info_id' =>$_POST['store_gi_id'][$j]]);
							 $this->db->update('iboss_acc_gi_crm_contact_info', $_POST_CONTACT);
							}	
							
							
				$store_group_id=array_filter($_POST['store_group_id']);
				
				
					 
					 for($k=0;$k<count($store_group_id);$k++)
							{
							 //$this->db->where_in($policy_type_id, array($value[$k]));							
							 $this->db->where(['unique_id'=>$unique_id, 'delete_log'=>"False", 'iboss_acc_group_policy_info_id' =>$_POST['store_group_id'][$k]]);
							 $this->db->update('iboss_acc_group_crm_contact_info', $_POST_CONTACT);
							}				
							
			
			$store_inv_id=array_filter($_POST['store_inv_id']);
				
				
					 
					 for($l=0;$l<count($store_inv_id);$l++)
							{
							 //$this->db->where_in($policy_type_id, array($value[$k]));							
							 $this->db->where(['unique_id'=>$unique_id, 'delete_log'=>"False", 'iboss_acc_group_id' =>$_POST['store_inv_id'][$l]]);
							 $this->db->update('iboss_acc_inv_crm_contact_info', $_POST_CONTACT);
							}					
					 
					 
			
				
			
			
		}
		
		
		//update_once
		
		if($_POST['update'] == 'Update_specific')
		{
			
				$_POST_CONTACT['primary_code']=$_POST['primary_code'];
				$_POST_CONTACT['primary_contact']=$_POST['primary_contact'];
				$_POST_CONTACT['primary_dnc']=$_POST['primary_dnc'];
				$_POST_CONTACT['primary_con_given_date']=sg2iso($_POST['primary_con_given_date']);
				
				$_POST_CONTACT['home_code']=$_POST['home_code'];
				$_POST_CONTACT['home_contact']=$_POST['home_contact'];
				$_POST_CONTACT['home_dnc']=$_POST['home_dnc'];
				$_POST_CONTACT['home_con_given_date']=sg2iso($_POST['home_con_given_date']);
				
				$_POST_CONTACT['office_code']=$_POST['office_code'];				
				$_POST_CONTACT['office_contact']=$_POST['office_contact'];
				$_POST_CONTACT['office_contact_ext']=$_POST['office_contact_ext'];
				$_POST_CONTACT['office_dnc']=$_POST['office_dnc'];
				$_POST_CONTACT['office_con_given_date']=sg2iso($_POST['office_con_given_date']);
				//End

				//Corporate
				$_POST_CONTACT['primary_office_code']=$_POST['primary_office_code'];
				$_POST_CONTACT['primary_office']=$_POST['primary_office'];
				$_POST_CONTACT['primary_office_dnc']=$_POST['primary_office_dnc'];
				$_POST_CONTACT['primary_office_con_given_date']=sg2iso($_POST['primary_office_con_given_date']);
				
				$_POST_CONTACT['secondary_office_code']=$_POST['secondary_office_code'];
				$_POST_CONTACT['secondary_office']=$_POST['secondary_office'];
				$_POST_CONTACT['secondary_office_dnc']=$_POST['secondary_office_dnc'];
				$_POST_CONTACT['secondary_office_given_date']=sg2iso($_POST['secondary_office_given_date']);
                //End Corporate	
				
				 
				$_POST_CONTACT['primary_email']=$_POST['primary_email'];
				$_POST_CONTACT['secondary_email']=$_POST['secondary_email'];				
				//$_POST_CONTACT['unique_id']=$unique_id;
				$_POST_CONTACT['date_time']=current_date_time();
				
				$this->db->where(['unique_id'=>$unique_id, 'delete_log'=>"False"]);
				$this->db->update('iboss_crm_contact_info', $_POST_CONTACT);
				
				
				
		$store_id=array_filter($_POST['update_crm']);
		for($z=0;$z<count($store_id);$z++)
{
			
			//$explode_value = $_POST['update_crm'];
			//explode("-",$_POST['update_crm'][$z]));
			$value=explode('-' ,$_POST['update_crm'][$z]);	
			$policy_id = $value[0];
			$type = $value[1];
			if($type == 'inv')
			{
			$this->db->where(['unique_id'=>$unique_id, 'delete_log'=>"False", 'iboss_acc_group_id' =>$policy_id]);
			$this->db->update('iboss_acc_'.$type.'_crm_contact_info', $_POST_CONTACT);	
			}
			else			
			{
			$this->db->where(['unique_id'=>$unique_id, 'delete_log'=>"False", 'iboss_acc_'.$type.'_policy_info_id' =>$policy_id]);
			$this->db->update('iboss_acc_'.$type.'_crm_contact_info', $_POST_CONTACT);
			}
			
			
			
}
		}		
		
		redirect( "iboss_master_crm_info/index" );
	}
	
function acc_crm_address_info($unique_id, $far_code)
	{
		$this->load->model("Iboss_acc_li_policy_info_model");
		$this->load->model("Iboss_acc_gi_policy_info_model");
		$this->load->model("Iboss_acc_group_policy_info_model");
		
		$data->main_crm_type=unqiue_id_spilit($unique_id);
		
		$data->templates = array('datatables','datepicker','icheck','chosen','select2');
		
		$data->address_labels = $this->Crm_address_info_model->get_field_comments();
		$data->enum_address = $this->Crm_address_info_model->get_enum();
		
		$data->overseas_country_id_options = $this->_selector_overseas_country();		
		
		$data->country_id_options = $this->_selector_options('Iboss_dict_country_model','id','name',array('id'=>'asc'));
		
		if(!empty($unique_id)){
			
	     $record = $this->Crm_contact_info_model->retrieve( array( "unique_id" => $unique_id ,'delete_log'=>'False') );
			
		$record[0]->primary_con_given_date=iso2sg($record[0]->primary_con_given_date);
		$record[0]->home_con_given_date=iso2sg($record[0]->home_con_given_date);
		$record[0]->office_con_given_date=iso2sg($record[0]->office_con_given_date);
		
		$record[0]->primary_office_con_given_date=iso2sg($record[0]->primary_office_con_given_date);
		$record[0]->secondary_office_given_date=iso2sg($record[0]->secondary_office_given_date);
		
		
		$address = $this->Crm_address_info_model->retrieve( array( "unique_id" => $unique_id ,'delete_log'=>'False') );
		
		  
		
		
		foreach($address as $row){
			if($row->address_type=='local_mail'){
			$record[0]->postal_code_1=$row->postal_code;
			$record[0]->unit_1=$row->unit;				
			$record[0]->block_1=$row->block;		
			$record[0]->building_1=$row->building;				
			$record[0]->street_1=$row->street;				
			$record[0]->city_1=$row->city;
			$record[0]->state_1=$row->state;										
			$record[0]->country_id_1=$row->country_id;
			$record[0]->send_mail=$row->send_mail;
			}
			
			if($row->address_type=='overseas_mail'){
			$record[0]->postal_code_2=$row->postal_code;
			$record[0]->unit_2=$row->unit;				
			$record[0]->block_2=$row->block;		
			$record[0]->building_2=$row->building;				
			$record[0]->street_2=$row->street;				
			$record[0]->city_2=$row->city;
			$record[0]->state_2=$row->state;										
			$record[0]->country_id_2=$row->country_id;
			$record[0]->send_mail=$row->send_mail;
			}
			
			if($row->address_type=='send_mail'){
			$record[0]->postal_code_3=$row->postal_code;
			$record[0]->unit_3=$row->unit;				
			$record[0]->block_3=$row->block;		
			$record[0]->building_3=$row->building;				
			$record[0]->street_3=$row->street;				
			$record[0]->city_3=$row->city;
			$record[0]->state_3=$row->state;										
			$record[0]->country_id_3=$row->country_id;
			$record[0]->send_mail=$row->send_mail;
			
			}
			
			
			
		}
		$this->_nitro_send_post_to_view($record[0],$data);
	     
		}
		
		 $data->policy_number_li = $this->Iboss_acc_li_policy_info_model->retrieve(array('iboss_crm_unique_id'=>$unique_id, 'far_code' =>$far_code));
		
$data->contact_li = $this->Iboss_acc_master_crm_info_model->retrieve(array('unique_id'=>$unique_id, 'iboss_acc_li_policy_info_id' =>$data->policy_number_li[0]->id),null, null,null,'iboss_acc_li_crm_address_info');		
		
 $data->policy_number_gi = $this->Iboss_acc_gi_policy_info_model->retrieve(array('iboss_crm_unique_id'=>$unique_id, 'far_code' =>$far_code));
		
 $data->contact_gi = $this->Iboss_acc_master_crm_info_model->retrieve(array('unique_id'=>$unique_id, 'iboss_acc_gi_policy_info_id' =>$data->policy_number_gi[0]->id),null, null,null,'iboss_acc_gi_crm_address_info');		
		
 $data->policy_number_group = $this->Iboss_acc_group_policy_info_model->retrieve(array('iboss_crm_unique_id'=>$unique_id, 'far_code' =>$far_code));
	
 $data->contact_group = $this->Iboss_acc_master_crm_info_model->retrieve(array('unique_id'=>$unique_id, 'iboss_acc_group_policy_info_id' =>$data->policy_number_group[0]->id),null, null,null,'iboss_acc_group_crm_address_info');	

 $data->account_number_inv = $this->Iboss_acc_inv_info_model->retrieve(array('iboss_crm_unique_id'=>$unique_id));

 $data->contact_inv = $this->Iboss_acc_master_crm_info_model->retrieve(array('unique_id'=>$unique_id, 'iboss_acc_group_id' =>$data->account_number_inv[0]->iboss_acc_group_id),null, null,null,'iboss_acc_inv_crm_address_info');

		
		$this->load->view("iboss_master_crm/iboss_acc_crm_address_info", $data);
	}
	
	
function update_address_acc_crm($unique_id)
	{
		//print_r($_POST);
		//die();
		
		if($_POST['update'] == 'Update_all')
		{
			
			
					
					
					if(!empty($_POST['postal_code_1']))
					{    
						$_POST_ADDRESS['postal_code']=$_POST['postal_code_1'];
						$_POST_ADDRESS['unit']=$_POST['unit_1'];
						$_POST_ADDRESS['block']=$_POST['block_1'];
						$_POST_ADDRESS['building']=$_POST['building_1'];
						$_POST_ADDRESS['street']=$_POST['street_1'];
						$_POST_ADDRESS['city']=$_POST['city_1'];
						$_POST_ADDRESS['state']=$_POST['state_1'];
						$_POST_ADDRESS['country_id']=$_POST['country_id_1'];
						//$_POST_ADDRESS['address_type']=$_POST['address_type_1'];
						//$_POST_ADDRESS['send_mail']=$_POST['send_mail'];	
						//$_POST_ADDRESS['unique_id']=$unique_id;	
						$_POST_ADDRESS['date_time']=current_date_time();
						
				
				
                
				
				
				
				
						if(!empty($_POST['local_address']))
						{							
						$sql = "select id from iboss_crm_address_info where unique_id='".$unique_id."' and address_type='local_mail' and delete_log='False'";
						$result = $this->db->query($sql);						
						$li_result = $result->num_rows();
						if($li_result == '1')
						{
						unset($_POST_ADDRESS['address_type']);	
						$_address_type[]='local_mail';		
						$this->db->where(['unique_id'=>$unique_id, 'delete_log'=>"False", 'address_type'=>'local_mail']);
						$this->db->update('iboss_crm_address_info', $_POST_ADDRESS);
						}
						else
						{
						unset($_POST_ADDRESS['address_type']);	
						$_address_type[]='local_mail';	
						$_POST_ADDRESS['address_type']='local_mail';												
						$_POST_ADDRESS['unique_id'] = $unique_id;
							
						$this->db->insert('iboss_crm_address_info', $_POST_ADDRESS);
						
						$this->db->where(['unique_id'=>$unique_id, 'delete_log'=>"False", 'address_type'=>'overseas_mail']);
						$this->db->update('iboss_crm_address_info', ['delete_log'=>"True"]);	
						}
						
						}
						if(!empty($_POST['overseas_address']))
						{
						
						$sql2 = "select id from iboss_crm_address_info where unique_id='".$unique_id."' and address_type='overseas_mail' and delete_log='False'";
						$result2 = $this->db->query($sql2);						
						$li_result2 = $result2->num_rows();
						if($li_result2 == '1')
						{
						unset($_POST_ADDRESS['address_type']);		
						$_address_type[]='overseas_mail';		
						$this->db->where(['unique_id'=>$unique_id, 'delete_log'=>"False", 'address_type'=>'overseas_mail']);
						$this->db->update('iboss_crm_address_info', $_POST_ADDRESS);
						}
						else
						{
						unset($_POST_ADDRESS['address_type']);		
						$_address_type[]='overseas_mail';	
						$_POST_ADDRESS['address_type']='overseas_mail';												
						$_POST_ADDRESS['unique_id'] = $unique_id;
							
						$this->db->insert('iboss_crm_address_info', $_POST_ADDRESS);
						
						$this->db->where(['unique_id'=>$unique_id, 'delete_log'=>"False", 'address_type'=>'local_mail']);
						$this->db->update('iboss_crm_address_info', ['delete_log'=>"True"]);
						}
						}
						if(!empty($_POST['update_local_mail']))
						{
						
						$sql3 = "select id from iboss_crm_address_info where unique_id='".$unique_id."' and address_type='send_mail' and delete_log='False'";
						$result3 = $this->db->query($sql3);						
						$li_result3 = $result3->num_rows();
						if($li_result3 == '1')
						{
						unset($_POST_ADDRESS['address_type']);		
						$_address_type[]='send_mail';		
						$this->db->where(['unique_id'=>$unique_id, 'delete_log'=>"False", 'address_type'=>'send_mail']);
						$this->db->update('iboss_crm_address_info', $_POST_ADDRESS);
						}
						else
						{
						unset($_POST_ADDRESS['address_type']);		
						$_address_type[]='send_mail';	
						$_POST_ADDRESS['address_type']='send_mail';												
						$_POST_ADDRESS['unique_id'] = $unique_id;
							
						$this->db->insert('iboss_crm_address_info', $_POST_ADDRESS);						
						}
						
						}
						
						
						for($s=0; $s<2; $s++)
						{
							
							
				 $store_li_id=array_filter($_POST['store_li_id']);
				
				
					 
					 for($i=0;$i<count($store_li_id);$i++)
							{
							
				
							 //$this->db->where_in($policy_type_id, array($value[$k]));							
							 $sql4 = "select id from iboss_acc_li_crm_address_info where unique_id='".$unique_id."' and address_type='".$_address_type[$s]."' and delete_log='False' and iboss_acc_li_policy_info_id ='".$_POST['store_li_id'][$i]."'";
							 $result4 = $this->db->query($sql4);						
							 $li_result4 = $result4->num_rows();
							 if($li_result4 == '1')
						{
							 unset($_POST_ADDRESS['address_type']);							
							 unset($_POST_ADDRESS['iboss_acc_group_id']);
							 $this->db->where(['unique_id'=>$unique_id, 'delete_log'=>"False", 'address_type'=>$_address_type[$s],  'iboss_acc_li_policy_info_id' =>$_POST['store_li_id'][$i]]);
							 $this->db->update('iboss_acc_li_crm_address_info', $_POST_ADDRESS);
						}
						else
						{	
							unset($_POST_ADDRESS['address_type']);							
							 unset($_POST_ADDRESS['iboss_acc_group_id']);
							$_POST_ADDRESS['address_type']=$_address_type[$s];												
							$_POST_ADDRESS['unique_id'] = $unique_id;
							$_POST_ADDRESS['iboss_acc_li_policy_info_id'] = $_POST['store_li_id'][$i];
							
							$this->db->insert('iboss_acc_li_crm_address_info', $_POST_ADDRESS);
							if($_address_type[$s]== 'local_mail')
							{
							$this->db->where(['unique_id'=>$unique_id, 'delete_log'=>"False", 'address_type'=>'overseas_mail', 'iboss_acc_li_policy_info_id'=>$_POST['store_li_id'][$i]]);
							$this->db->update('iboss_acc_li_crm_address_info', ['delete_log'=>"True"]);	
							}
							if($_address_type[$s]== 'overseas_mail')
							{
							$this->db->where(['unique_id'=>$unique_id, 'delete_log'=>"False", 'address_type'=>'local_mail', 'iboss_acc_li_policy_info_id'=>$_POST['store_li_id'][$i]]);
							$this->db->update('iboss_acc_li_crm_address_info', ['delete_log'=>"True"]);	
							}
						}
							}
							
					
							
				$store_gi_id=array_filter($_POST['store_gi_id']);
				
				
					 
					 for($j=0;$j<count($store_gi_id);$j++)
							{
								
							 $sql5 = "select id from iboss_acc_gi_crm_address_info where unique_id='".$unique_id."' and address_type='".$_address_type[$s]."' and delete_log='False' and iboss_acc_gi_policy_info_id ='".$_POST['store_gi_id'][$j]."'";
							 $result5 = $this->db->query($sql5);						
							 $li_result5 = $result5->num_rows();
							 if($li_result5 == '1')
						{
							 unset($_POST_ADDRESS['address_type']);							
							 unset($_POST_ADDRESS['iboss_acc_li_policy_info_id']);
							 $this->db->where(['unique_id'=>$unique_id, 'delete_log'=>"False", 'address_type'=>$_address_type[$s], 'iboss_acc_gi_policy_info_id' =>$_POST['store_gi_id'][$j]]);
							 $this->db->update('iboss_acc_gi_crm_address_info', $_POST_ADDRESS);
						}
						else
						{
							unset($_POST_ADDRESS['address_type']);							
							unset($_POST_ADDRESS['iboss_acc_li_policy_info_id']);
							$_POST_ADDRESS['address_type']=$_address_type[$s];												
							$_POST_ADDRESS['unique_id'] = $unique_id;
							$_POST_ADDRESS['iboss_acc_gi_policy_info_id'] = $_POST['store_gi_id'][$j];
							
							$this->db->insert('iboss_acc_gi_crm_address_info', $_POST_ADDRESS);
							if($_address_type[$s]== 'local_mail')
							{
							$this->db->where(['unique_id'=>$unique_id, 'delete_log'=>"False", 'address_type'=>'overseas_mail', 'iboss_acc_gi_policy_info_id'=>$_POST['store_gi_id'][$j]]);
							$this->db->update('iboss_acc_gi_crm_address_info', ['delete_log'=>"True"]);	
							}
							if($_address_type[$s]== 'overseas_mail')
							{
							$this->db->where(['unique_id'=>$unique_id, 'delete_log'=>"False", 'address_type'=>'local_mail', 'iboss_acc_gi_policy_info_id'=>$_POST['store_gi_id'][$j]]);
							$this->db->update('iboss_acc_gi_crm_address_info', ['delete_log'=>"True"]);		
							}
						}		
							 
							}	
							
							
				$store_group_id=array_filter($_POST['store_group_id']);
				
				
					 
					 for($k=0;$k<count($store_group_id);$k++)
							{
							 
							 $sql6 = "select id from iboss_acc_group_crm_address_info where unique_id='".$unique_id."' and address_type='".$_address_type[$s]."' and delete_log='False' and iboss_acc_group_policy_info_id ='".$_POST['store_group_id'][$k]."'";
							 $result6 = $this->db->query($sql6);						
							 $li_result6 = $result6->num_rows();
							 if($li_result6 == '1')
						{
							 unset($_POST_ADDRESS['address_type']);							
							 unset($_POST_ADDRESS['iboss_acc_gi_policy_info_id']);
							 $this->db->where(['unique_id'=>$unique_id, 'delete_log'=>"False", 'address_type'=>$_address_type[$s], 'iboss_acc_group_policy_info_id' =>$_POST['store_group_id'][$k]]);
							 $this->db->update('iboss_acc_group_crm_address_info', $_POST_ADDRESS);
						}
						else
						{
							unset($_POST_ADDRESS['address_type']);							
							unset($_POST_ADDRESS['iboss_acc_gi_policy_info_id']);
							$_POST_ADDRESS['address_type']=$_address_type[$s];												
							$_POST_ADDRESS['unique_id'] = $unique_id;
							$_POST_ADDRESS['iboss_acc_group_policy_info_id'] = $_POST['store_group_id'][$k];
							
							$this->db->insert('iboss_acc_group_crm_address_info', $_POST_ADDRESS);
							if($_address_type[$s]== 'local_mail')
							{
							$this->db->where(['unique_id'=>$unique_id, 'delete_log'=>"False", 'address_type'=>'overseas_mail', 'iboss_acc_group_policy_info_id'=>$_POST['store_group_id'][$k]]);
							$this->db->update('iboss_acc_group_crm_address_info', ['delete_log'=>"True"]);	
							}
							if($_address_type[$s]== 'overseas_mail')
							{
							$this->db->where(['unique_id'=>$unique_id, 'delete_log'=>"False", 'address_type'=>'local_mail', 'iboss_acc_group_policy_info_id'=>$_POST['store_group_id'][$k]]);
							$this->db->update('iboss_acc_group_crm_address_info', ['delete_log'=>"True"]);	
							}
						}	
							}				
							
			
			$store_inv_id=array_filter($_POST['store_inv_id']);
				
				
					 
					 for($l=0;$l<count($store_inv_id);$l++)
							{
							 
							 $sql7 = "select id from iboss_acc_inv_crm_address_info where unique_id='".$unique_id."' and address_type='".$_address_type[$s]."' and delete_log='False' and iboss_acc_group_id ='".$_POST['store_inv_id'][$l]."'";
							 $result7 = $this->db->query($sql7);						
							 $li_result7 = $result7->num_rows();
							 if($li_result7 == '1')
						{
							 unset($_POST_ADDRESS['address_type']);							
							 unset($_POST_ADDRESS['iboss_acc_group_policy_info_id']);
							 $this->db->where(['unique_id'=>$unique_id, 'delete_log'=>"False", 'address_type'=>$_address_type[$s],  'iboss_acc_group_id' =>$_POST['store_inv_id'][$l]]);
							 $this->db->update('iboss_acc_inv_crm_address_info', $_POST_ADDRESS);
						}
						else
						{
							unset($_POST_ADDRESS['address_type']);							
							unset($_POST_ADDRESS['iboss_acc_group_policy_info_id']);
							$_POST_ADDRESS['address_type']=$_address_type[$s];												
							$_POST_ADDRESS['unique_id'] = $unique_id;
							$_POST_ADDRESS['iboss_acc_group_id'] = $_POST['store_inv_id'][$l];
							
							$this->db->insert('iboss_acc_inv_crm_address_info', $_POST_ADDRESS);
							if($_address_type[$s]== 'local_mail')
							{
							$this->db->where(['unique_id'=>$unique_id, 'delete_log'=>"False", 'address_type'=>'overseas_mail', 'iboss_acc_group_id'=>$_POST['store_inv_id'][$l]]);
							$this->db->update('iboss_acc_inv_crm_address_info', ['delete_log'=>"True"]);	
							}
							if($_address_type[$s]== 'overseas_mail')
							{
							$this->db->where(['unique_id'=>$unique_id, 'delete_log'=>"False", 'address_type'=>'local_mail', 'iboss_acc_group_id'=>$_POST['store_inv_id'][$l]]);
							$this->db->update('iboss_acc_inv_crm_address_info', ['delete_log'=>"True"]);	
							}
						}
							 
							 
							}					
					 
				}
					
					
					//print_r($this->db->last_query());
					//die();
					}
			
		}
		
				
		//update_once
		if($_POST['update'] == 'Update_specific')
		{
		//print_r($_POST);
		//die();
				
				
					if(!empty($_POST['postal_code_1']))
					{    
						$_POST_ADDRESS['postal_code']=$_POST['postal_code_1'];
						$_POST_ADDRESS['unit']=$_POST['unit_1'];
						$_POST_ADDRESS['block']=$_POST['block_1'];
						$_POST_ADDRESS['building']=$_POST['building_1'];
						$_POST_ADDRESS['street']=$_POST['street_1'];
						$_POST_ADDRESS['city']=$_POST['city_1'];
						$_POST_ADDRESS['state']=$_POST['state_1'];
						$_POST_ADDRESS['country_id']=$_POST['country_id_1'];
						//$_POST_ADDRESS['address_type']=$_POST['address_type_1'];
						//$_POST_ADDRESS['send_mail']=$_POST['send_mail'];	
						//$_POST_ADDRESS['unique_id']=$unique_id;	
						$_POST_ADDRESS['date_time']=current_date_time();
						
						
						if(!empty($_POST['local_address']))
						{							
						$sql = "select id from iboss_crm_address_info where unique_id='".$unique_id."' and address_type='local_mail' and delete_log='False'";
						$result = $this->db->query($sql);						
						$li_result = $result->num_rows();
						if($li_result == '1')
						{
						unset($_POST_ADDRESS['address_type']);	
						$_address_type[]='local_mail';		
						$this->db->where(['unique_id'=>$unique_id, 'delete_log'=>"False", 'address_type'=>'local_mail']);
						$this->db->update('iboss_crm_address_info', $_POST_ADDRESS);
						}
						else
						{
						unset($_POST_ADDRESS['address_type']);													
						$_address_type[]='local_mail';	
						$_POST_ADDRESS['address_type']='local_mail';												
						$_POST_ADDRESS['unique_id'] = $unique_id;
						
							
						$this->db->insert('iboss_crm_address_info', $_POST_ADDRESS);						
						
						$this->db->where(['unique_id'=>$unique_id, 'delete_log'=>"False", 'address_type'=>'overseas_mail']);
						$this->db->update('iboss_crm_address_info', ['delete_log'=>"True"]);	
						}
						
						}
						if(!empty($_POST['overseas_address']))
						{
						
						$sql2 = "select id from iboss_crm_address_info where unique_id='".$unique_id."' and address_type='overseas_mail' and delete_log='False'";
						$result2 = $this->db->query($sql2);						
						$li_result2 = $result2->num_rows();
						if($li_result2 == '1')
						{
						unset($_POST_ADDRESS['address_type']);		
						$_address_type[]='overseas_mail';		
						$this->db->where(['unique_id'=>$unique_id, 'delete_log'=>"False", 'address_type'=>'overseas_mail']);
						$this->db->update('iboss_crm_address_info', $_POST_ADDRESS);
						}
						else
						{
						unset($_POST_ADDRESS['address_type']);													
						$_address_type[]='overseas_mail';	
						$_POST_ADDRESS['address_type']='overseas_mail';												
						$_POST_ADDRESS['unique_id'] = $unique_id;
							
						$this->db->insert('iboss_crm_address_info', $_POST_ADDRESS);
						
						$this->db->where(['unique_id'=>$unique_id, 'delete_log'=>"False", 'address_type'=>'local_mail']);
						$this->db->update('iboss_crm_address_info', ['delete_log'=>"True"]);
						}
						}
						if(!empty($_POST['update_local_mail']))
						{
						
						$sql3 = "select id from iboss_crm_address_info where unique_id='".$unique_id."' and address_type='send_mail' and delete_log='False'";
						$result3 = $this->db->query($sql3);						
						$li_result3 = $result3->num_rows();
						if($li_result3 == '1')
						{
						unset($_POST_ADDRESS['address_type']);		
						$_address_type[]='send_mail';		
						$this->db->where(['unique_id'=>$unique_id, 'delete_log'=>"False", 'address_type'=>'send_mail']);
						$this->db->update('iboss_crm_address_info', $_POST_ADDRESS);
						}
						else
						{
						unset($_POST_ADDRESS['address_type']);	
						$_address_type[]='send_mail';	
						$_POST_ADDRESS['address_type']='send_mail';												
						$_POST_ADDRESS['unique_id'] = $unique_id;
							
						$this->db->insert('iboss_crm_address_info', $_POST_ADDRESS);						
						}
						}
						
				// print_r($_address_type);
				// die();
				for($s=0; $s<2; $s++)
						{
				
		$store_id=array_filter($_POST['update_crm']);
		for($z=0;$z<count($store_id);$z++)
{
			
			//$explode_value = $_POST['update_crm'];
			//explode("-",$_POST['update_crm'][$z]));
			$value=explode('-' ,$_POST['update_crm'][$z]);	
			$policy_id = $value[0];
			$type = $value[1];
			if($type == 'inv')
			{	
			$sql8 = "select id from iboss_acc_inv_crm_address_info where unique_id='".$unique_id."' and address_type='".$_address_type[$s]."' and delete_log='False' and iboss_acc_group_id ='".$policy_id."'";
			$result8 = $this->db->query($sql8);						
			$li_result8 = $result8->num_rows();
			if($li_result8 == '1')
			{
			unset($_POST_ADDRESS['address_type']);							
			unset($_POST_ADDRESS['iboss_acc_group_id']);	
			$this->db->where(['unique_id'=>$unique_id, 'delete_log'=>"False", 'address_type'=>$_address_type[$s], 'iboss_acc_group_id' =>$policy_id]);
			$this->db->update('iboss_acc_'.$type.'_crm_address_info', $_POST_ADDRESS);	
			}
			else
			{
			unset($_POST_ADDRESS['address_type']);							
			unset($_POST_ADDRESS['iboss_acc_group_id']);	
			$_POST_ADDRESS['address_type']=$_address_type[$s];												
			$_POST_ADDRESS['unique_id'] = $unique_id;
			$_POST_ADDRESS['iboss_acc_group_id'] = $policy_id;	
			$this->db->insert('iboss_acc_inv_crm_address_info', $_POST_ADDRESS);	
			if($_address_type[$s]== 'local_mail')
			{
			$this->db->where(['unique_id'=>$unique_id, 'delete_log'=>"False", 'address_type'=>'overseas_mail', 'iboss_acc_group_id'=>$policy_id]);
			$this->db->update('iboss_acc_inv_crm_address_info', ['delete_log'=>"True"]);	
			}
			if($_address_type[$s]== 'overseas_mail')
			{
			$this->db->where(['unique_id'=>$unique_id, 'delete_log'=>"False", 'address_type'=>'local_mail', 'iboss_acc_group_id'=>$policy_id]);
			$this->db->update('iboss_acc_inv_crm_address_info', ['delete_log'=>"True"]);	
			}						
			}
			
			}
			else			
			{
			$sql9 = "select id from iboss_acc_".$type."_crm_address_info where unique_id='".$unique_id."' and address_type='".$_address_type[$s]."' and delete_log='False' and iboss_acc_".$type."_policy_info_id ='".$policy_id."'";
			$result9 = $this->db->query($sql9);						
			$li_result9 = $result9->num_rows();
			if($li_result9 == '1')
			{
			unset($_POST_ADDRESS['address_type']);							
			unset($_POST_ADDRESS['iboss_acc_'.$type.'_policy_info_id']);	
			$this->db->where(['unique_id'=>$unique_id, 'delete_log'=>"False", 'address_type'=>$_address_type[$s],  'iboss_acc_'.$type.'_policy_info_id' =>$policy_id]);
			$this->db->update('iboss_acc_'.$type.'_crm_address_info', $_POST_ADDRESS);
			}
			else
			{
			unset($_POST_ADDRESS['address_type']);							
			unset($_POST_ADDRESS['iboss_acc_'.$type.'_policy_info_id']);
			$_POST_ADDRESS['address_type']=$_address_type[$s];												
			$_POST_ADDRESS['unique_id'] = $unique_id;
			$_POST_ADDRESS['iboss_acc_'.$type.'_policy_info_id'] = $policy_id;
			$this->db->insert('iboss_acc_'.$type.'_crm_address_info', $_POST_ADDRESS);	
			if($_address_type[$s]== 'local_mail')
			{
			$this->db->where(['unique_id'=>$unique_id, 'delete_log'=>"False", 'address_type'=>'overseas_mail', 'iboss_acc_'.$type.'_policy_info_id'=>$policy_id]);
			$this->db->update('iboss_acc_'.$type.'_crm_address_info', ['delete_log'=>"True"]);	
			}
			if($_address_type[$s]== 'overseas_mail')
			{
			$this->db->where(['unique_id'=>$unique_id, 'delete_log'=>"False", 'address_type'=>'local_mail', 'iboss_acc_'.$type.'_policy_info_id'=>$policy_id]);
			$this->db->update('iboss_acc_'.$type.'_crm_address_info', ['delete_log'=>"True"]);	
			}
			}
			
			}
			
			
			
}
						}
					}
				

		}		
		
		redirect( "iboss_master_crm_info/index" );
	}



function compliance_refersh($unique_id){

		
		$data = $this->Crm_compliance_info_model->init_data();
		$data->templates = array('datatables','datepicker','icheck','chosen','select2');
		
		
		$data->cdd_outcome_options = $this->_selector_options('Iboss_dict_crm_outcome_model','id','name',null,array('outcome_type'=>'CDD'));
		$data->ecdd_outcome_options = $this->_selector_options('Iboss_dict_crm_outcome_model','id','name',null,array('outcome_type'=>'ECDD'));
		

		
		if(!empty($unique_id)){
		$data->compilance_details = $this->Crm_compliance_info_model->retrieve( array( "unique_id" => $unique_id ,'delete_log'=>'False') );
		$record = $this->Crm_compliance_info_model->retrieve( array( "unique_id" => $unique_id ) );
		
		$this->_nitro_send_post_to_view($record[0],$data);

		}
		
    echo  $html= $this->load->view( "iboss_crm_load_file/iboss_compliance_record", $data );
	}
	
/* function authorised_person_info_refresh($unique_id){
		
		$data = $this->Crm_personal_info_model->init_data();
		$data->templates = array('datatables','datepicker','icheck','chosen','select2');
		

		
		if(!empty($unique_id)){
			
			$data->auth_person_info = $this->Crm_personal_info_model->retrieve( array( "unique_id" => $unique_id ) );
			
			// $record = $this->Crm_personal_info_model->retrieve( array( "unique_id" => $unique_id ) );
			// $id=$record[0]->id;
			// $this->_nitro_send_post_to_view($record[0],$data);
		}
		
		$data->primary_crm_contact =function($unique_id,$field_name){
				
                $sql = "select * from iboss_crm_contact_info where  unique_id='".$unique_id."'";
				$result = $this->db->query($sql);
				$li_result = $result->row()->$field_name;
				
				return  $li_result;
				
				};
		
    echo  $html=$this->load->view( "iboss_crm_load_file/iboss_authorised_record", $data );
	} */







function farops_license_check($far_code,$ctype)	{
	
	$license=biz_licensing_farcode_result_2($far_code);
	
	 $lic_val=$license[0]->$ctype;
	if(!empty($lic_val))
	{
		echo  $lic_val;
	}else{
		echo "";
	}
	
	
	
	
}

		function getAccessToken()
		{

				$customURL=base_url()."amlapi/token.php";		
				$payload ="grant_type=client_credentials&client_id=testclient&client_secret=testpass";
				//$payload = urlencode($payload);
				
				$ch = curl_init(); 
				if (!$ch){die("Couldn't initialize a cURL handle");}
				$ret = curl_setopt($ch, CURLOPT_URL,$customURL);
				curl_setopt ($ch, CURLOPT_POST, 1); 
				curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);          
				curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
				curl_setopt ($ch, CURLOPT_POSTFIELDS,$payload);
				//set the content type to application/json
				curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/x-www-form-urlencoded'));
				$ret = curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
				$curlresponse = curl_exec($ch); // execute
				//print_r($curlresponse);
				curl_close($ch);
				
				return $curlresponse;
		}
		
		function checkAccessToken($token_type,$access_token)
		{
			
			$customURL=base_url()."amlapi/ajax_calls.php";		
		
			$data_send['search_user']='checktoken';
				$concat=array();
				foreach($data_send as $key=>$postdata)
				{
					
					$concat[]=$key."=".$postdata;
					
				}
			  $payload=@implode("&",$concat);
		
				$ch = curl_init(); 
				if (!$ch){die("Couldn't initialize a cURL handle");}
				$ret = curl_setopt($ch, CURLOPT_URL,$customURL);
				curl_setopt ($ch, CURLOPT_POST, 1); 
				curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);          
				curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
				curl_setopt ($ch, CURLOPT_POSTFIELDS,$payload);
				//set the content type to application/json
				curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/x-www-form-urlencoded','Authorization: '.$token_type.' '.$access_token));
				$ret = curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
				$curlresponse = curl_exec($ch); // execute
				curl_close($ch); 
				return $curlresponse ;
				
				
		}
		
		function aml_crm_compliance_info($unique_id=null,$viewpage=null) { 
	
		 $this->load->model("Iboss_acc_li_client_info_model");
		
		$data = $this->Crm_compliance_info_model->init_data();
		$data->templates = array('datatables','datepicker','icheck','chosen','select2');
		
		$data_send=array();
		//Common Data
		$data->viewpage=$viewpage;
		$data->unique_id=$unique_id;
		$data->main_crm_type=unqiue_id_spilit($unique_id);
		$data->crm_tab_type=10;
        $data->title_corp='';
		if($data->main_crm_type=='Corp')
		{
			$data->title_corp='Corp';
			$data->data_for='Corp';
			$data->data_record = $this->Crm_corporate_info_model->retrieve( array( "unique_id" => $unique_id ) );
			$data_send['name']=str_replace(" ","+",$data->data_record[0]->business_name);
			$data_send['record_type']='E';
		}
		else
		{	
			$data->data_for='Inv';
			$data->data_record = $this->Crm_personal_info_model->retrieve( array( "unique_id" => $unique_id ) );
			$data_send['name']=str_replace(" ","+",$data->data_record[0]->nric_name);
			$data_send['record_type']='P';
		}
		$data->record_type=$data_send['record_type'];
		
		$data->corporate_uniques=$this->session->userdata('auth_crm_unique_id');
		//End Common Data
		
		$getAccessToken=json_decode($this->getAccessToken());
		$data_send['search_user']='fetch_bydate';
		$data_send['request_from']='iBOSS';
		$data_send['record']='500';
		$data_send['unique_id']=$unique_id;
		$data_send['access_user_id']=$this->session->userdata('id');
		//$checkAccessToken=json_decode($this->checkAccessToken($getAccessToken->token_type,$getAccessToken->access_token),true);
		
		$customURL=base_url()."amlapi/ajax_calls.php";	
		$payload=json_encode($data_send,JSON_UNESCAPED_SLASHES);
		$concat=array();
				foreach($data_send as $key=>$postdata)
				{
					
					$concat[]=$key."=".$postdata;
					
				}
				  $payload=@implode("&",$concat);
		
				$ch = curl_init(); 
				if (!$ch){die("Couldn't initialize a cURL handle");}
				$ret = curl_setopt($ch, CURLOPT_URL,$customURL);
				curl_setopt ($ch, CURLOPT_POST, 1); 
				curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);          
				curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
				curl_setopt ($ch, CURLOPT_POSTFIELDS,$payload);
				//set the content type to application/json
				curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/x-www-form-urlencoded','Authorization: '.$getAccessToken->token_type.' '.$getAccessToken->access_token));
				$ret = curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
				$curlresponse = curl_exec($ch); // execute
				curl_close($ch); 
			
			
				$curlresponse_data=json_decode($curlresponse,true);
				//echo '<pre>';
				///print_r($curlresponse_data);
				//die;
				$data->curlresponse=json_encode($curlresponse_data['data']);
				
				$data->curlresponse_date="";
				
		
		
		return $this->load->view( "iboss_master_crm/iboss_aml_crm_compliance_info", $data );
		

	}
		
		
	function aml_search_user($unique_id=null,$record_type=null,$name=null)
	{
		if($name !='' and  $name !=null)
		{
			$name=$name;
		}else{
			$name=$_POST['name'];
		}
		
				$customURL=base_url()."amlapi/api_curls.php";	
				$data_send['admin_search']="true";
				$data_send['search_type']="search_name_search";
				$data_send['content-set']='WL,SOC,AM,TC';
				$data_send['exclude-deceased']='false';
				$data_send['hits-from']='0';
				$data_send['hits-to']='500';
				$data_send['record-type']=$record_type;
				$data_send['search-type']='broad';
				$data_send['name']=urlencode(str_replace(" ","+",$name));
				$data_send['unique_id']=$unique_id;
				$data_send['request_from']="iBOSS";
				$data_send['access_user_id']=$this->session->userdata('id');
				//die;
				$concat=array();
				foreach($data_send as $key=>$postdata)
				{
					
					$concat[]=$key."=".$postdata;
					
				}
				  $payload=@implode("&",$concat);
		
				$ch = curl_init(); 
				if (!$ch){die("Couldn't initialize a cURL handle");}
				$ret = curl_setopt($ch, CURLOPT_URL,$customURL);
				curl_setopt ($ch, CURLOPT_POST, 1); 
				curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);          
				curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
				curl_setopt ($ch, CURLOPT_POSTFIELDS,$payload);
				//set the content type to application/json
				curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/x-www-form-urlencoded'));
				$ret = curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
				 $curlresponse = curl_exec($ch); // execute
				curl_close($ch); 
				
				$response=json_decode($curlresponse);
				if($response->type == 'success')
				{
				$_POST_aml['aml_api_date_time'] =$response->aml_date_time;
				$_POST_aml['aml_data_found'] = "Yes";
				$_POST_aml['aml_record_fetched'] = $response->aml_record_fetched;
				$this->db->where('unique_id', $unique_id);
				$this->db->update('iboss_master_crm_index',$_POST_aml);
				}else{
				$_POST_aml['aml_api_date_time'] =$response->aml_date_time;
				$_POST_aml['aml_data_found'] = "No";
				$this->db->where('unique_id', $unique_id);
				$this->db->update('iboss_master_crm_index',$_POST_aml);
				}
				
				
			return $curlresponse;

	}	
		
	function aml_crm_compliance_user_info($peid=null,$name=null) { 
	
				
				$getAccessToken=json_decode($this->getAccessToken());
				
				$customURL=base_url()."amlapi/ajax_calls.php";	
				$data_send['search_user']="user_data_single";
				$data_send['peid']=$peid;
				if($name!="")
				{
					$data_send['name']=str_replace(" ","+",$name);
				}
				$data_send['request_from']='iBOSS';
				$data_send['access_user_id']=$this->session->userdata('id');
				$concat=array();
				foreach($data_send as $key=>$postdata)
				{
					
					$concat[]=$key."=".$postdata;
					
				}
				  $payload=@implode("&",$concat);
		
				$ch = curl_init(); 
				if (!$ch){die("Couldn't initialize a cURL handle");}
				$ret = curl_setopt($ch, CURLOPT_URL,$customURL);
				curl_setopt ($ch, CURLOPT_POST, 1); 
				curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);          
				curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
				curl_setopt ($ch, CURLOPT_POSTFIELDS,$payload);
				//set the content type to application/json
				curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/x-www-form-urlencoded','Authorization: '.$getAccessToken->token_type.' '.$getAccessToken->access_token));
				$ret = curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
				$curlresponse = curl_exec($ch); // execute
				curl_close($ch); 
				
				header('Content-Type: application/json');	
				echo $curlresponse;
				
	
	}
	
	/*********************************Save AML Search Info *****************************/
	
	function client_details_unique_id($unique_id)
	{
		$this->load->model("Crm_corporate_info_model");
		$this->load->model("Crm_personal_info_model");
		$data->main_crm_type=unqiue_id_spilit($unique_id);
		if($data->main_crm_type=='Corp')
		{
			$data->title_corp='Corp';
			$data->data_for='Corp';
			$data->data_record = $this->Crm_corporate_info_model->retrieve( array( "unique_id" => $unique_id ) );
			$data_send['name']=str_replace(" ","+",$data->data_record[0]->business_name);
			$data_send['record_type']='E';
		}
		else
		{	
			$data->data_for='Inv';
			$data->data_record = $this->Crm_personal_info_model->retrieve( array( "unique_id" => $unique_id ) );
			$data_send['name']=str_replace(" ","+",$data->data_record[0]->nric_name);
			$data_send['record_type']='P';
		}
		
		$data->record_type=$data_send['record_type'];
		
		$data->corporate_uniques=$this->session->userdata('auth_crm_unique_id');
		//End Common Data
		
		$getAccessToken=json_decode($this->getAccessToken());
		$data_send['search_user']='fetch_bydate';
		$data_send['request_from']='iBOSS';
		$data_send['record']='500';
		$data_send['unique_id']=$unique_id;
		$data_send['access_user_id']=$this->session->userdata('id');
		//echo "<pre>";
		//print_r($data_send);
		//die();
		//$checkAccessToken=json_decode($this->checkAccessToken($getAccessToken->token_type,$getAccessToken->access_token),true);
		
		$customURL=base_url()."amlapi/ajax_calls.php";	
		$payload=json_encode($data_send,JSON_UNESCAPED_SLASHES);
		$concat=array();
				foreach($data_send as $key=>$postdata)
				{
					
					$concat[]=$key."=".$postdata;
					
				}
				
				  $payload=@implode("&",$concat);
		
				$ch = curl_init(); 
				if (!$ch){die("Couldn't initialize a cURL handle");}
				$ret = curl_setopt($ch, CURLOPT_URL,$customURL);
				curl_setopt ($ch, CURLOPT_POST, 1); 
				curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);          
				curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
				curl_setopt ($ch, CURLOPT_POSTFIELDS,$payload);
				//set the content type to application/json
				curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/x-www-form-urlencoded','Authorization: '.$getAccessToken->token_type.' '.$getAccessToken->access_token));
				$ret = curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
				$curlresponse = curl_exec($ch); // execute
				curl_close($ch); 
			
				$curlresponse_data=json_decode($curlresponse,true);
				//echo '<pre>';
				//print_r($curlresponse_data);
				//die;
				$data->curlresponse=json_encode($curlresponse_data['data']);
		
		       
		     $this->aml_search_user($unique_id,$data->record_type,$data_send['name']); 
	      
		
	}
	
   /*********************************End Save AML Search Info *****************************/
	
 
	/***********Master Crm Cron Insert**********/

 function personal_info_cron_insert(){

 	date_default_timezone_set('Asia/Singapore');
      $date=date('Y-m-d H:i:s');

 	// error_reporting(E_ALL);
  //   ini_set('display_errors',1);
  //   ini_set('display_startup_errors',1);
  //   error_reporting(-1);

 	$sql="Select * from temp_iboss_crm_personal_info where cron_status='No' order by id desc limit 5 ";

 	$result=$this->db->query($sql);

 	$result_sql=$result->result();

 	foreach ($result_sql as $value) {

 		$iboss_personal_info_id=$value->id;

 		if($value->identification_no!='' && $value->far_code!=''){

 		$sql_master="Select * from iboss_master_crm_index where identification_no='".$value->identification_no."' and far_code='".$value->far_code."'";

 		$result_master=$this->db->query($sql_master);
 		$unique_id = $result_master->row()->unique_id;

 		if($unique_id==''){

 			$id5=$this->db->select('id')->from('iboss_crm_personal_info')->limit(1)->order_by('id','DESC')->get()->row()->id;
					$last_insert_id=$id5+1;
		            $sum_value = 000000 + $last_insert_id;
		            $make_unique_id = str_pad($sum_value, 6, '0', STR_PAD_LEFT);
					$create_unique_id = 'Inv'.$make_unique_id ;
					$post_value_2['unique_id']=$create_unique_id;
					$post_value_2['far_code']=$value->far_code;
					$post_value_2['identification_no']=$value->identification_no;
					$post_value_2['passport_no']=$value->passport_no;
					$post_value_2['fin_no']=$value->fin_no;
					$post_value_2['nric_name']=$value->nric_name;
					$post_value_2['dob']=$value->dob;
					$post_value_2['preferred_name'] = $value->preferred_name;
					$post_value_2['saluation']=$value->saluation;
					$post_value_2['gender']=$value->gender;
					$post_value_2['smoker'] = $value->smoker;
					$post_value_2['race_id']=$value->race_id;
					$post_value_2['nationality_id']=$value->nationality_id;
					$post_value_2['citizenship']=$value->citizenship;
					$post_value_2['country_of_residence']=$value->country_of_residence;
					$post_value_2['marital_status']=$value->marital_status;
					$post_value_2['religion_id']=$value->religion_id;
					$post_value_2['faiwa_client'] = $value->faiwa_client;
					$post_value_2['preferred_language']=$value->preferred_language;
					$post_value_2['remarks']=$value->remarks;
					$post_value_2['date_time']=$date;
					  
					$this->db->insert('iboss_crm_personal_info',$post_value_2);



					$post_value['unique_id']=$create_unique_id;
					$post_value['far_code']=$value->far_code;
					$post_value['identification_no']=$value->identification_no;
					$post_value['passport_no']=$value->passport_no;
					$post_value['fin_no']=$value->fin_no;
					$post_value['nric_name']=$value->nric_name;
					$post_value['dob']=$value->dob;
				    $post_value['crm_controller']='crm_personal_info';
					$this->db->insert('iboss_master_crm_index',$post_value);


					//Data Storiong Master CRM Personal Table

					$unique_id_check='$create_unique_id';

					//print_r($unique_id_check);


					
					//$last_insert_id_3=$this->iBOSS_read->insert_id();

					 $this->db->query("insert into iboss_crm_contact_info (unique_id,primary_contact,primary_dnc,primary_con_given_date,home_contact,home_dnc,home_con_given_date,office_contact,office_dnc,office_con_given_date,primary_email,secondary_email,status,delete_log,primary_office,primary_office_dnc,primary_office_con_given_date,secondary_office,secondary_office_dnc,secondary_office_given_date,primary_code,home_code,office_code,primary_office_code,secondary_office_code,date_time,office_contact_ext,ClientID,primary_email_dnc,primary_email_given_date,secondary_email_dnc,secondary_email_given_date,secondary_code,secondary_contact,secondary_dnc,secondary_con_given_date)
select '".$create_unique_id."',primary_contact,primary_dnc,primary_con_given_date,home_contact,home_dnc,home_con_given_date,office_contact,office_dnc,office_con_given_date,primary_email,secondary_email,status,delete_log,primary_office,primary_office_dnc,primary_office_con_given_date,secondary_office,secondary_office_dnc,secondary_office_given_date,primary_code,home_code,office_code,primary_office_code,secondary_office_code,date_time,office_contact_ext,ClientID,primary_email_dnc,primary_email_given_date,secondary_email_dnc,secondary_email_given_date,secondary_code,secondary_contact,secondary_dnc,secondary_con_given_date From temp_iboss_crm_contact_info where unique_id='".$value->unique_id."'");

$this->db->query("insert into iboss_crm_address_info(unique_id,postal_code,unit,block,building,street,city,state,country_id,status,delete_log,send_mail,address_type,date_time,mailing_dnc,mailing_dnc_effect_date,ClientID,import_addtype)select '".$create_unique_id."',postal_code,unit,block,building,street,city,state,country_id,status,delete_log,send_mail,address_type,date_time,mailing_dnc,mailing_dnc_effect_date,ClientID,import_addtype from temp_iboss_crm_address_info  where unique_id='".$value->unique_id."'");



$this->db->query("insert into iboss_crm_edu_and_emp_info(unique_id,education_id,school_id,qualification_id,status,delete_log,employer,nature_of_business,occupation_id,nature_of_employment,designation_id,length_of_service,annual_income,source_of_fund,date_time,ClientID)Select '".$create_unique_id."',education_id,school_id,qualification_id,status,delete_log,employer,nature_of_business,occupation_id,nature_of_employment,designation_id,length_of_service,annual_income,source_of_fund,date_time,ClientID from temp_iboss_crm_edu_and_emp_info where unique_id='".$value->unique_id."'");

$this->db->query("insert into iboss_crm_marketing_info(unique_id,email,calls,fax,sms,status,set_default,delete_log,letter,eversion,email_consent_date,sms_consent_date,letter_consent_date,call_consent_date,fax_consent_date,eversion_consent_date,date_time)select '".$create_unique_id."',email,calls,fax,sms,status,set_default,delete_log,letter,eversion,email_consent_date,sms_consent_date,letter_consent_date,call_consent_date,fax_consent_date,eversion_consent_date,date_time from temp_iboss_crm_marketing_info  where unique_id='".$value->unique_id."'");

$this->db->query("insert into iboss_crm_compliance_info(unique_id,ai,ai_foreign,oi_country_id,pep,pep_person_name,pep_prominent,pep_country_id,cdd_date_search,cdd_hit,cdd_date_verification,cdd_outcome,cdd_officer_incharge,comment,ecdd_date_search,ecdd_date_verification,ecdd_outcome,ecdd_compliance_approval,ecdd_additional_comment,ecdd_approving_officer,ecdd_approved_date,ecdd_authorised_report,ecdd_reporting_date,ecdd_reporting_outcome,set_default,status,delete_log,oi,ai_declaration_date,ii,ii_country_id,cdd_check_officer,ecdd_check_officer,pep_relationship,date_time,ClientID)Select  '".$create_unique_id."',ai,ai_foreign,oi_country_id,pep,pep_person_name,pep_prominent,pep_country_id,cdd_date_search,cdd_hit,cdd_date_verification,cdd_outcome,cdd_officer_incharge,comment,ecdd_date_search,ecdd_date_verification,ecdd_outcome,ecdd_compliance_approval,ecdd_additional_comment,ecdd_approving_officer,ecdd_approved_date,ecdd_authorised_report,ecdd_reporting_date,ecdd_reporting_outcome,set_default,status,delete_log,oi,ai_declaration_date,ii,ii_country_id,cdd_check_officer,ecdd_check_officer,pep_relationship,date_time,ClientID from temp_iboss_crm_compliance_info where unique_id='".$value->unique_id."'");

$_update['cron_status'] = 'Yes';
								
$this->db->where('id', $iboss_personal_info_id);
$this->db->update('temp_iboss_crm_personal_info', $_update);

			}

		}

	}

	} 

	function get_product_name($product_name){

	 $sql="Select id from iboss_product_gi_info where name='".$product_name."'";
	$result=$this->db->query($sql);
 	$id=$result->row()->id;
 	return $id;


	}

	function get_product_type($product_type){

    $sql="Select id from iboss_dict_gi_product_type where name='".$product_type."'";
	$result=$this->db->query($sql);
 	$id=$result->row()->id;
 	return $id;


	}

	function get_policy_status($policy_status){

		$sql="Select id from iboss_dict_policy_status where business_class_id='3' AND  name='".$policy_status."'";
		$result=$this->db->query($sql);
		 $id=$result->row()->id;
		 return $id;
	
	
		}
	
		function get_business_status($business_status){

			$sql="Select id from iboss_dict_business_status where business_class_id='3' AND  name='".$business_status."'";
			$result=$this->db->query($sql);
			 $id=$result->row()->id;
			 return $id;
		}

		function get_company_name($prefer_company){

			$sql="Select id from iboss_dict_fa_company where iboss_dict_biz_class_id='3' AND  name='".$prefer_company."'";
			$result=$this->db->query($sql);
			 $id=$result->row()->id;
			 return $id;
		}

		function get_product_sub_type($product_sub_type){

			$sql="Select id from iboss_dict_gi_product_sub_type where   name='".$product_sub_type."'";
			$result=$this->db->query($sql);
			 $id=$result->row()->id;
			 return $id;
		}

		function get_payment_method($payment_method){

			$sql="Select id from iboss_dict_payment_method where iboss_dict_biz_class_id='3' AND  name='".$payment_method."'";
			$result=$this->db->query($sql);
			 $id=$result->row()->id;
			 return $id;
		}

		
		function get_frequency($frequency){

			$sql="Select id from iboss_dict_fpayment where iboss_dict_biz_class_id='3' AND  name='".$frequency."'";
			$result=$this->db->query($sql);
			 $id=$result->row()->id;
			 return $id;
		}

		function get_currency($currency){

			$sql="Select id from iboss_dict_currency where  name='".$currency."'";
			$result=$this->db->query($sql);
			 $id=$result->row()->id;
			 return $id;
		}

		
		function get_unique_id($identification_no,$far_code){

			 $sql_master="Select * from iboss_master_crm_index where identification_no='".$identification_no."' and far_code='".$far_code."'";
		
			 $result_master=$this->db->query($sql_master);
			  $unique_id = $result_master->row()->unique_id;

			
		
			 return $unique_id;
		
		  }


		  function get_country_id($name){

		  	$sql="Select id from iboss_dict_country where  name='".$currency."'";
			$result=$this->db->query($sql);
			 $id=$result->row()->id;
			 return $id;

		  }
		




function gi_info_cron(){

	$sql="Select * from temp_iboss_acc_gi_policy_info where cron_status='No' order by id desc limit 5";
			

 	$result=$this->db->query($sql);
	  $result_sql=$result->result();


	   foreach ($result_sql as $value) {

        $temp_iboss_gi_policy_info_id=$value->id;

		if($value->identification_no!='' && $value->far_code!=''){

			$unique_id=$this->get_unique_id($value->identification_no,$value->far_code);
			
	  
			if($value->life_insured_nric!='' && $value->far_code!=''){
	  
			$life_assured_unique_id=$this->get_unique_id($value->life_insured_nric,$value->far_code);
	  
			}else{
	  
			$life_assured_unique_id=$unique_id; 
	  
			}

		if($unique_id!=''){
			$far_code=$value->far_code;
            $product_name=$this->get_product_name($value->iboss_product_gi_info_id);
			$product_type=$this->get_product_type($value->iboss_dict_gi_product_type_id);
			$registeration=$value->registration_date;
			$p_number=$value->policy_number;
			$policy_status=$this->get_policy_status($value->policy_status);
			$business_status=$this->get_business_status($value->business_status);
			$application=$value->application_date;
			$submission=$value->submission_date;
			$prefer_company=$this->get_company_name($value->iboss_dict_fa_company_id);
			$product_sub_type=$this->get_product_sub_type($value->iboss_dict_gi_product_sub_type_id);
			$policy_iss=$value->policy_issue_date;
			$inforce=$value->inforce_date;
			$end_date=$value->policy_end_date;
			$sum_assured=$value->sum_assured;
			$payment_method=$this->get_payment_method($value->payment_method);
			$frequency=$this->get_frequency($value->frequency);
			$auto_renewal=$value->auto_renewal;
			$policy_renewal_date=$value->policy_renewal_date;
			$vehicle=$value->vehicle_number;
			$currency=$this->get_currency($value->iboss_dict_currency_type_id);
			$exchange_rate=$value->exchange_rate;
			$basic_premium=$value->orginal_premium;
			$loading_premium=$value->orginal_loading_premium;
			$discount_premium=$value->orginal_discount_premium;
			$gst_sgd=$value->gst_amount;
			$renewal_notice_date=$value->RenewalNoticeReceivedDate;
			$policy_receive_date=$value->policy_received_date;
			$renew_next=$value->RenewalForNextYear;
			$remarks=$value->remarks;


			if($product_name!='' || $product_type!=''){
				
				 $cal=array("iboss_dict_currency_type_id"=>$currency,
			              "iboss_product_li_info_id"=>$product_name,
						  "exchange_rate"=>$product_name,
						  "original_premium"=>$basic_premium,
						  "original_loading_premium"=>$loading_premium,
						  "discount_amount"=>$discount_amount,
						  "original_discount_amount"=>$discount_premium,
						  "gst_amount"=>$gst_sgd,
						  "model_premium"=>"",
						  "total_premium"=>"",
						  "submission_date"=>$submission );
						  
			$result_value= $this->calculation_details($cal);
				
				 $post_value_8['iboss_crm_unique_id']=$unique_id;
			  $post_value_8['iboss_acc_gi_client_info_id']=$life_assured_unique_id;
			  $post_value_8['registration_date']=$registeration;
			  $post_value_8['far_code']=$far_code;
			  $post_value_8['policy_number']=$p_number;
              $post_value_8['policy_status']=$policy_status;  
			  $post_value_8['business_status']=$business_status; 
			  $post_value_8['application_date']=$application;
			  $post_value_8['submission_date']=$submission;
			  $post_value_8['iboss_dict_fa_company_id']=$prefer_company;
			  $post_value_8['iboss_product_gi_info_id']=$product_name;
			  $post_value_8['iboss_dict_gi_product_type_id']=$product_type;
			  $post_value_8['iboss_dict_gi_product_sub_type_id']=$product_sub_type;
			  $post_value_8['iboss_product_gi_insurer_bp_id'] =$product_insurer;
			  $post_value_8['iboss_product_gi_insurer_autosync_id']=$prodcut_autosync;
			  $post_value_8['policy_issue_date']=$policy_iss;
			  $post_value_8['inforce_date']=$inforce;
			  $post_value_8['policy_end_date']=$end_date;
			  $post_value_8['sum_assured']=$sum_assured;
			  $post_value_8['payment_method']=$payment_method;
			  $post_value_8['frequency']=$frequency;
			  $post_value_8['auto_renewal']=$auto_renewal;
			  $post_value_8['policy_renewal_date']=$policy_renewal_date;
			  $post_value_8['vehicle_number']=$vehicle;
			  $post_value_8['iboss_dict_currency_type_id']=$currency;
			  $post_value_8['exchange_rate']=$exchange_rate;
			  $post_value_8['orginal_premium']=$basic_premium;
			  $post_value_8['orginal_loading_premium']=$loading_premium;
			  $post_value_8['orginal_discount_premium']=$discount_premium;
			  $post_value_8['RenewalNoticeReceivedDate']=$renewal_notice_date;
		      $post_value_8['policy_received_date']=$policy_receive_date;
			  $post_value_8['RenewalForNextYear']=$renew_next;
			  $post_value_8['remarks']=$remarks;
			  //$post_value_8['gst_amount']=$gst_sgd;
			  //Basic Premium ( SGD ) -A
			  $post_value_8['premium']=$result_value['premium'];
              //Model Premium						  
              $post_value_8['total_modal_premium']=$result_value['model_premium'];
			  //Total Premium ( SGD )
			  $post_value_8['total_premium']=$result_value['total_premium'];
			  //GST
			  $post_value_8['gst_amount']=$result_value['gst_amount'];
			  //Discounted premium ( SGD )
			  $post_value_8['discount_amount']=$result_value['discount_amount'];
			  //Loading Premium ( SGD )-B
			  $post_value_8['loading_premium']=$result_value['loading_premium'];
			  
			  if(!empty($unique_id)){
			  	$post_value_8['iboss_acc_gi_client_info_id']=$unique_id;
			  }else{
			  	$post_value_8['iboss_acc_gi_client_info_id']=$life_assured_unique_id;
			  }
			  
		
			  $this->db->insert('iboss_acc_gi_policy_info', $post_value_8);
			  $insert_id=$this->db->insert_id();

			  /*****iboss_acc_gi_client_info */
			  $_main_client['iboss_acc_gi_policy_info_id']=$insert_id;
			  $_main_client['iboss_crm_unique_id']=$unique_id;
			  $_main_client['client_type']='Main';
			  $_main_client['far_code']=$value->far_code;
			  $this->db->insert('iboss_acc_gi_client_info',$_main_client);

			  $filed_name='iboss_acc_gi_policy_info_id';
			  $filed_value=$insert_id;

			  if(!empty($unique_id))
           		{
         			save_into_crm($unique_id,$filed_name,$filed_value, 'GI', '');  
           		}

			  if($unique_id !=$life_assured_unique_id)
			  {

				$Life1['iboss_acc_gi_policy_info_id']=$insert_id;
				$Life1['iboss_crm_unique_id']=$life_assured_unique_id;
				$Life1['client_type']='Life Assured';
				$Life1['far_code']=$value->far_code;
				$this->db->insert('iboss_acc_gi_client_info', $Life1);

			  $filed_name='iboss_acc_gi_policy_info_id';
			  $filed_value=$insert_id;

				if(!empty($life_assured_unique_id))
           		{
         			save_into_crm($life_assured_unique_id,$filed_name,$filed_value, 'GI', '');  
           		}

			  }
			  /***********End ***************************/

              //FAR Details PAge
			  $basic_FAR_writting['far_code'] =$value->far_code; 
			  $basic_FAR_writting['far_type'] ='4';
			  $basic_FAR_writting['far_type_of_sharing'] ='7'; 														
			  $basic_FAR_writting['status'] ='Active'; 														
			  $basic_FAR_writting['iboss_acc_gi_policy_info_id'] =$insert_id; 
			  $this->db->insert('iboss_acc_gi_far_details', $basic_FAR_writting);
							
              $basic_FAR_service['far_code'] =$value->far_code; 
			  $basic_FAR_service['far_type'] ='5'; 
			  $basic_FAR_service['far_type_of_sharing'] ='7'; 
			  $basic_FAR_service['percentage'] ='100'; 
			  $basic_FAR_service['status'] ='Active'; 														
			  $basic_FAR_service['start_date'] = $submission;
			  $basic_FAR_service['iboss_acc_gi_policy_info_id'] =$insert_id;
			  $this->db->insert('iboss_acc_gi_far_details', $basic_FAR_service);


			  /*****temp_iboss_acc_gi_policy_info_rl */
			  $this->db->query("insert into iboss_acc_gi_policy_info_rl(iboss_acc_gi_policy_info_id, postal_code, unit, block, building, street, city, state, country_id, policy_type)Select '".$insert_id."', postal_code, unit, block, building, street, city, state, (Select id from iboss_dict_country where  name=country_id) as country_id,policy_type from temp_iboss_acc_gi_policy_info_rl where iboss_acc_gi_policy_info_id='".$temp_iboss_gi_policy_info_id."'");


			  $this->db->query("insert into iboss_acc_gi_endorsement_info( iboss_acc_gi_policy_info_id, policy_number, endorsement_no, effective_date, endorsement_received_date, policy_issue_date, benefit_type, premium, total_premium, gst, modal_premium, invoice_no, remark, status, delete_log, InsurancePolicyID, EndorsementID, gst_policy, premium_status, uuid, submission_date)select   '".$insert_id."', policy_number, endorsement_no, effective_date, endorsement_received_date, policy_issue_date, (Select id from iboss_dict_benefit_type where iboss_dict_biz_class_id=3 and name=benefit_type) as benefit_type, premium, total_premium, gst, modal_premium, invoice_no, remark, status, delete_log, InsurancePolicyID, EndorsementID, gst_policy, premium_status, uuid, submission_date From temp_iboss_acc_gi_endorsement_info where iboss_acc_gi_policy_info_id='".$temp_iboss_gi_policy_info_id."'");
			  $insert_id_endorse=$this->db->insert_id();
			  
			  $this->db->query("insert into iboss_acc_gi_policy_financial (iboss_crm_unique_id, iboss_acc_gi_policy_info_id, fin_payment_method, fin_payment_make, fin_institution, fin_account_number, fin_account_holder, fin_expiary_date, fin_paid_to_date, fin_amount_paid, fin_cheque_number, fin_cheque_receive_date, fin_status, uuid, delete_log, fin_premium_due_date, fin_remarks, InsurancePolicyID, PaymentToInsurerID)select '".$unique_id."', '".$insert_id."', (
Select id from iboss_dict_payment_method where iboss_dict_biz_class_id=3 and name=fin_payment_method) as fin_payment_method, (
select id from iboss_dict_payment_make where iboss_dict_biz_class_id=3 and name=fin_payment_make) as fin_payment_make,(select id from iboss_dict_institution where iboss_dict_biz_class_id=3 and name=fin_institution) as fin_institution, fin_account_number, fin_account_holder, fin_expiary_date, fin_paid_to_date, fin_amount_paid, fin_cheque_number, fin_cheque_receive_date, (
select id from iboss_dict_payment_status where iboss_dict_biz_class_id=3 and name=fin_status
) as fin_status, uuid, delete_log, fin_premium_due_date, fin_remarks, InsurancePolicyID, PaymentToInsurerID from temp_iboss_acc_gi_policy_financial  where iboss_acc_gi_policy_info_id='".$temp_iboss_gi_policy_info_id."'");


			  $this->db->query("insert into iboss_acc_gi_endorsement_details_info( iboss_acc_gi_policy_info_id, iboss_acc_gi_policy_info_rider_id, iboss_acc_gi_endorsement_info_id, type, plan_name, premium, gst, gst_value, modal_premium, total_premium, delete_log)Select '".$insert_id."', iboss_acc_gi_policy_info_rider_id, '".$insert_id_endorse."', type, plan_name, premium, gst, gst_value, modal_premium, total_premium, delete_log from temp_iboss_acc_gi_endorsement_details_info  where iboss_acc_gi_policy_info_id='".$temp_iboss_gi_policy_info_id."'");

			$this->db->query("insert into iboss_acc_gi_claim_info(iboss_acc_gi_policy_info_id, iboss_crm_unique_id, employee_name, claimant_name, claim_no, plan_type, claim_type, claim_submission_date, incurred_period_from, incurred_period_to, clinic_hospital, incurred_amount, claim_status, settlement_date, claim_settlement_amt, status, delete_log)Select '".$insert_id."', '".$unique_id."', employee_name, claimant_name, claim_no, plan_type, (Select id from iboss_dict_claim_type where iboss_dict_biz_class_id=3 and name=claim_type) as claim_type, claim_submission_date, incurred_period_from, incurred_period_to, clinic_hospital, incurred_amount, (Select id from iboss_dict_claim_status where iboss_dict_biz_class_id=3 and name=claim_status) as claim_status, settlement_date, claim_settlement_amt, status, delete_log from temp_iboss_acc_gi_claim_info  where iboss_acc_gi_policy_info_id='".$temp_iboss_gi_policy_info_id."'");


		 }
		 

	 }
	 

 $_update['cron_status'] = 'Yes';
								
$this->db->where('id', $temp_iboss_gi_policy_info_id);
$this->db->update('temp_iboss_acc_gi_policy_info', $_update);

	 }
	

	}
}
	
function cleanData($a) {

     if(is_numeric($a)) {

     $a = preg_replace("/[^a-zA-Z0-9\/_|+ .-]/", '', $a);
	 
	

     }else{
		 $a=0;
	 }

     return $a;

}	

	
	
	function calculation_details($all_values)
	{
		  
		$iboss_dict_currency_type_id=$all_values['iboss_dict_currency_type_id'];
		$iboss_product_li_info_id=$all_values['iboss_product_li_info_id'];
		$exchange_rate=$this->cleanData($all_values['exchange_rate']);
		$original_premium=$this->cleanData($all_values['original_premium']);
		$premium=$this->cleanData($all_values['premium']);
		$original_loading_premium=$this->cleanData($all_values['original_loading_premium']);
		$discount_amount=$this->cleanData($all_values['discount_amount']);
		$original_discount_amount=$this->cleanData($all_values['original_discount_amount']);
		$gst_amount=$this->cleanData($all_values['original_discount_amount']);
		//$basic_shield_premium=$this->cleanData($all_values['basic_shield_premium']);
		$model_premium=$this->cleanData($all_values['model_premium']);
		$total_premium=$this->cleanData($all_values['total_premium']);
		
		$submission_date=$all_values['submission_date'];
		
			$result_value=array();
			if(!empty($iboss_product_li_info_id))
			{
							$sql = "select * from iboss_product_gi_info where  id='".$iboss_product_li_info_id."'";
							$result = $this->db->query($sql);
							$iboss_product_li_info= $result->row();
							
							$risk_of_location_info=$iboss_product_li_info->risk_of_location;							
							$gst=$iboss_product_li_info->gst;
							$payment_medisave=$iboss_product_li_info->payment_medisave;
							$policy_fee=$iboss_product_li_info->policy_fee;
							$max_sum_assured=$iboss_product_li_info->max_sum_assured;
							$min_sum_assured=$iboss_product_li_info->min_sum_assured;
							$policy_term=$iboss_product_li_info->policy_term;
							$premium_term=$iboss_product_li_info->premium_term;
							 
							 if(!empty($submission_date))
							 {
										 $submission_date_iso=sg2iso($submission_date); 
										 $sql = "select * from  iboss_product_gi_promotion where  iboss_product_gi_info_id='".$iboss_product_li_info_id."' and (start_date <= '".$submission_date_iso."' and  end_date >= '".$submission_date_iso."' ) ";
										 $result = $this->db->query($sql);
										 $promotion_rate= $result->row()->discount_rate;
											if(empty($promotion_rate))
											{
											$promotion_rate=0;	
												
											}
						
							 }
				
			}
			
					//Calculation Basic Premium ( SGD ) -A
					 $result_value['premium']=number_format($original_premium * $exchange_rate, 2, '.', '');
								
					//Loading Premium ( SGD )-B
								
					$result_value['loading_premium']=number_format($original_loading_premium * $exchange_rate, 2, '.', '');
					
					
					//Discounted premium ( SGD )-C
					if(!empty($promotion_rate) && $promotion_rate != '0')
					{
					$result_value['discount_amount_original_promotion']= number_format( $promotion_rate  * $result_value['premium'], 2, '.', '');					
					$result_value['discount_amount'] = number_format( $result_value['discount_amount_original_promotion'] * $exchange_rate, 2, '.', '');
					$result_value['discount_plan_rate']=($promotion_rate * 100).' %' ;
					}
					else
					{
					$result_value['discount_amount']=number_format( $original_discount_amount * $exchange_rate, 2, '.', '');
					}
					
					//GST ( SGD )-E
					if($gst=='Yes')
					{
					 $gst_value=(iboss_setup('GST')/100);
					 //$gst_value=1.07;
					$result_value['gst_plan_rate']=iboss_setup('GST');	
					// $result_value['gst_minus']=number_format( ($result_value['premium'] + $result_value['loading_premium'] - $result_value['discount_amount']) *($gst_value/100), 2, '.', '' );
					$result_value['gst_amount']=number_format( ($result_value['premium'] + $result_value['loading_premium'] - $result_value['discount_amount']) * ($gst_value), 2, '.', '' );
					 
					 //$result_value['gst_amount']=number_format(($result_value['gst_minus']) - ($result_value['premium'] + $result_value['loading_premium'] - $result_value['discount_amount']), 2, '.', '');	 
					}else{
						$result_value['gst_amount']=0;
					}
                    
					  
	                //Model Premium		
					$result_value['model_premium']=number_format(($result_value['premium']) + ($result_value['loading_premium'] ) - ($result_value['discount_amount'] ), 2, '.', '');  
				    //Total Premium ( SGD )

					$result_value['total_premium']=number_format(($result_value['premium'] + $result_value['loading_premium'])-($result_value['discount_amount'] ) + ($result_value['gst_amount']) , 2, '.', '');
	                 
					 //Plan GST 
					$result_value['plan_gst']=$gst;
					
					
					$result_value['risk_of_location_new']=$risk_of_location_info;
                    					  
                    

					return $result_value;
										
										
		
	}




	function get_product_name_1($product_name){

		$sql="Select id from iboss_product_group_info where name='".$product_name."'";
	   $result=$this->db->query($sql);
		$id=$result->row()->id;
		return $id;
   
   
	   }
   
	   function get_product_type_1($product_type){
   
	    $sql="Select id from iboss_dict_group_product_type where name='".$product_type."'";
	   $result=$this->db->query($sql);
		$id=$result->row()->id;
		return $id;
   
   
	   }
   
	   function get_policy_status_1($policy_status){
   
		   $sql="Select id from iboss_dict_policy_status where business_class_id='6' AND  name='".$policy_status."'";
		   $result=$this->db->query($sql);
			$id=$result->row()->id;
			return $id;
	   
	   
		   }
	   
		   function get_business_status_1($business_status){
   
			   $sql="Select id from iboss_dict_business_status where business_class_id='6' AND  name='".$business_status."'";
			   $result=$this->db->query($sql);
				$id=$result->row()->id;
				return $id;
		   }
   
		   function get_company_name_1($prefer_company){
   
			   $sql="Select id from iboss_dict_fa_company where iboss_dict_biz_class_id='6' AND  name='".$prefer_company."'";
			   $result=$this->db->query($sql);
				$id=$result->row()->id;
				return $id;
		   }
   
		   function get_product_sub_type_1($product_sub_type){
   
			   $sql="Select id from iboss_dict_group_product_sub_type where   name='".$product_sub_type."'";
			   $result=$this->db->query($sql);
				$id=$result->row()->id;
				return $id;
		   }
   
		   function get_payment_method_1($payment_method){
   
			   $sql="Select id from iboss_dict_payment_method where iboss_dict_biz_class_id='6' AND  name='".$payment_method."'";
			   $result=$this->db->query($sql);
				$id=$result->row()->id;
				return $id;
		   }
   
		   
		   function get_frequency_1($frequency){
   
			   $sql="Select id from iboss_dict_fpayment where iboss_dict_biz_class_id='6' AND  name='".$frequency."'";
			   $result=$this->db->query($sql);
				$id=$result->row()->id;
				return $id;
		   }
   
		   function get_currency_1($currency){

			$sql="Select id from iboss_dict_currency where  name='".$currency."'";
			$result=$this->db->query($sql);
			 $id=$result->row()->id;
			 return $id;
		}
   
		   
		   function get_unique_id_1($identification_no,$far_code){
   
				$sql_master="Select * from iboss_master_crm_index where identification_no='".$identification_no."' and far_code='".$far_code."'";
		   
				$result_master=$this->db->query($sql_master);
				 $unique_id = $result_master->row()->unique_id;
   
			   
		   
				return $unique_id;
		   
			 }
   
   
   


	function group_info_cron(){

		$sql="Select * from temp_iboss_acc_group_policy_info where cron_status='No' order by id desc limit 5";
				
	
		 $result=$this->db->query($sql);
		  $result_sql=$result->result();
		 
	
	
		   foreach ($result_sql as $value) {
	
			$temp_iboss_group_policy_info_id=$value->id;
	
			if($value->identification_no!='' && $value->far_code!=''){
	
				$unique_id=$this->get_unique_id_1($value->identification_no,$value->far_code);
				
		  
				if($value->life_insured_nric!='' && $value->far_code!=''){
		  
				$life_assured_unique_id=$this->get_unique_id_1($value->life_insured_nric,$value->far_code);
		  
				}else{
		  
				$life_assured_unique_id=$unique_id; 
		  
				}
				
				
			
				if($unique_id!=''){
	// 				error_reporting(E_ALL);
    // ini_set('display_errors',1);
    // ini_set('display_startup_errors',1);
    // error_reporting(-1);
				$far_code=$value->far_code;
				$product_name=$this->get_product_name_1($value->iboss_product_group_info_id);
				$product_type=$this->get_product_type_1($value->iboss_dict_group_product_type_id);
				$registeration=$value->registration_date;
				$p_number=$value->policy_number;
				$policy_status=$this->get_policy_status_1($value->policy_status);
				$business_status=$this->get_business_status_1($value->business_status);
				$application=$value->application_date;
				$submission=$value->submission_date;
				$prefer_company=$this->get_company_name_1($value->iboss_dict_fa_company_id);
				$product_sub_type=$this->get_product_sub_type_1($value->iboss_dict_group_product_sub_type_id);
				$policy_iss=$value->policy_issue_date;
				$inforce=$value->inforce_date;
				$end_date=$value->policy_end_date;
				$sum_assured=$value->sum_assured;
				$payment_method=$this->get_payment_method_1($value->payment_method);
				$frequency=$this->get_frequency_1($value->frequency);
				$auto_renewal=$value->auto_renewal;
				$policy_renewal_date=$value->policy_renewal_date;
				$vehicle=$value->vehicle_number;
				$currency=$this->get_currency_1($value->iboss_dict_currency_type_id);
				$exchange_rate=$value->exchange_rate;
				$basic_premium=$value->orginal_premium;
				$loading_premium=$value->orginal_loading_premium;
				$discount_premium=$value->orginal_discount_premium;
				$gst_sgd=$value->gst_amount;
				$renewal_notice_date=$value->RenewalNoticeReceivedDate;
				$policy_receive_date=$value->policy_received_date;
				$renew_next=$value->RenewalForNextYear;
				$remarks=$value->remarks;
				
				if($product_name!='' || $product_type!=''){
					 $calc=array("iboss_dict_currency_type_id"=>$currency,
							  "iboss_product_li_info_id"=>$product_name,
							  "exchange_rate"=>$product_name,
							  "original_premium"=>$basic_premium,
							  "original_loading_premium"=>$loading_premium,
							  "discount_amount"=>$discount_amount,
							  "original_discount_amount"=>$discount_premium,
							  "gst_amount"=>$gst_sgd,
							  "model_premium"=>"",
							  "total_premium"=>"",
							  "submission_date"=>$submission );
							  
				$result_values= $this->calculation_details_1($calc);
					
			      $post_value_8['iboss_crm_unique_id']=$unique_id;
				  $post_value_8['iboss_acc_group_client_info_id']=$life_assured_unique_id;
				  $post_value_8['registration_date']=$registeration;
				  $post_value_8['far_code']=$far_code;
				  $post_value_8['policy_number']=$p_number;
				  $post_value_8['policy_status']=$policy_status;  
				  $post_value_8['business_status']=$business_status; 
				  $post_value_8['application_date']=$application;
				  $post_value_8['submission_date']=$submission;
				  $post_value_8['iboss_dict_fa_company_id']=$prefer_company;
				  $post_value_8['iboss_product_group_info_id']=$product_name;
				  $post_value_8['iboss_dict_group_product_type_id']=$product_type;
				  $post_value_8['iboss_dict_group_product_sub_type_id']=$product_sub_type;
				  $post_value_8['iboss_product_group_insurer_bp_id'] =$product_insurer;
				  $post_value_8['iboss_product_group_insurer_autosync_id']=$prodcut_autosync;
				  $post_value_8['policy_issue_date']=$policy_iss;
				  $post_value_8['inforce_date']=$inforce;
				  $post_value_8['policy_end_date']=$end_date;
				  $post_value_8['sum_assured']=$sum_assured;
				  $post_value_8['payment_method']=$payment_method;
				  $post_value_8['frequency']=$frequency;
				  $post_value_8['auto_renewal']=$auto_renewal;
				  $post_value_8['policy_renewal_date']=$policy_renewal_date;
				  $post_value_8['iboss_dict_currency_type_id']=$currency;
				  $post_value_8['exchange_rate']=$exchange_rate;
				  $post_value_8['orginal_premium']=$basic_premium;
				  $post_value_8['orginal_loading_premium']=$loading_premium;
				  $post_value_8['orginal_discount_premium']=$discount_premium;
				  $post_value_8['RenewalNoticeReceivedDate']=$renewal_notice_date;
				  $post_value_8['policy_received_date']=$policy_receive_date;
				  $post_value_8['RenewalForNextYear']=$renew_next;
				  $post_value_8['remarks']=$remarks;
				  //$post_value_8['gst_amount']=$gst_sgd;
				  //Basic Premium ( SGD ) -A
				  $post_value_8['premium']=$result_values['premium'];
				  //Model Premium						  
				  $post_value_8['total_modal_premium']=$result_values['model_premium'];
				  //Total Premium ( SGD )
				  $post_value_8['total_premium']=$result_values['total_premium'];
				  //GST
				  $post_value_8['gst_amount']=$result_values['gst_amount'];
				  //Discounted premium ( SGD )
				  $post_value_8['discount_amount']=$result_values['discount_amount'];
				  //Loading Premium ( SGD )-B
				  $post_value_8['loading_premium']=$result_values['loading_premium'];
				  
				  if(!empty($unique_id)){
					  $post_value_8['iboss_acc_group_client_info_id']=$unique_id;
				  }else{
					  $post_value_8['iboss_acc_group_client_info_id']=$life_assured_unique_id;
				  }
				  
			
				  $this->db->insert('iboss_acc_group_policy_info', $post_value_8);
				  $insert_id=$this->db->insert_id();
				 
				  /*****iboss_acc_gi_client_info */
				  $_main_client['iboss_acc_group_policy_info_id']=$insert_id;
				  $_main_client['iboss_crm_unique_id']=$unique_id;
				  $_main_client['client_type']='Main';
				  $_main_client['far_code']=$value->far_code;
				  $this->db->insert('iboss_acc_group_client_info',$_main_client);
	
				  $filed_name='iboss_acc_group_policy_info_id';
				  $filed_value=$insert_id;
	
				  if(!empty($unique_id))
					   {
						 save_into_crm($unique_id,$filed_name,$filed_value, 'GROUP', '');  
					   }
	
				  if($unique_id !=$life_assured_unique_id)
				  {
	
					$Life1['iboss_acc_group_policy_info_id']=$insert_id;
					$Life1['iboss_crm_unique_id']=$life_assured_unique_id;
					$Life1['client_type']='Life Assured';
					$Life1['far_code']=$value->far_code;
					$this->db->insert('iboss_acc_group_client_info', $Life1);
	
				  $filed_name='iboss_acc_group_policy_info_id';
				  $filed_value=$insert_id;
	
					if(!empty($life_assured_unique_id))
					   {
						 save_into_crm($life_assured_unique_id,$filed_name,$filed_value, 'GROUP', '');  
					   }
	
				  }
				  /***********End ***************************/
	
				  //FAR Details PAge
				  $basic_FAR_writting['far_code'] =$value->far_code; 
				  $basic_FAR_writting['far_type'] ='4';
				  $basic_FAR_writting['far_type_of_sharing'] ='7'; 														
				  $basic_FAR_writting['status'] ='Active'; 														
				  $basic_FAR_writting['iboss_acc_group_policy_info_id'] =$insert_id; 
				  $this->db->insert('iboss_acc_group_far_details', $basic_FAR_writting);
								
				  $basic_FAR_service['far_code'] =$value->far_code; 
				  $basic_FAR_service['far_type'] ='5'; 
				  $basic_FAR_service['far_type_of_sharing'] ='7'; 
				  $basic_FAR_service['percentage'] ='100'; 
				  $basic_FAR_service['status'] ='Active'; 														
				  $basic_FAR_service['start_date'] = $submission;
				  $basic_FAR_service['iboss_acc_group_policy_info_id'] =$insert_id;
				  $this->db->insert('iboss_acc_group_far_details', $basic_FAR_service);
	
	
				  /*****temp_iboss_acc_gi_policy_info_rl */
				//   $this->db->query("insert into iboss_acc_group_policy_info_rl(iboss_acc_group_policy_info_id, postal_code, unit, block, building, street, city, state, country_id, policy_type)Select '".$insert_id."', postal_code, unit, block, building, street, city, state, (Select id from iboss_dict_country where  name=country_id) as country_id,policy_type from temp_iboss_acc_group_policy_info_rl where iboss_acc_group_policy_info_id='".$temp_iboss_group_policy_info_id."'");
	
	
				  $this->db->query("insert into iboss_acc_group_endorsement_info( iboss_acc_group_policy_info_id, policy_number, endorsement_no, effective_date, endorsement_received_date, policy_issue_date, benefit_type, premium, total_premium, gst, modal_premium, invoice_no, remark, status, delete_log, InsurancePolicyID, EndorsementID, gst_policy, premium_status, uuid, submission_date)select   '".$insert_id."', policy_number, endorsement_no, effective_date, endorsement_received_date, policy_issue_date, (Select id from iboss_dict_benefit_type where iboss_dict_biz_class_id=6 and name=benefit_type) as benefit_type, premium, total_premium, gst, modal_premium, invoice_no, remark, status, delete_log, InsurancePolicyID, EndorsementID, gst_policy, premium_status, uuid, submission_date From temp_iboss_acc_group_endorsement_info where iboss_acc_group_policy_info_id='".$temp_iboss_group_policy_info_id."'");
				  $insert_id_endorse=$this->db->insert_id();
				  
				  $this->db->query("insert into iboss_acc_group_policy_financial (iboss_crm_unique_id, iboss_acc_group_policy_info_id, fin_payment_method, fin_payment_make, fin_institution, fin_account_number, fin_account_holder, fin_expiary_date, fin_paid_to_date, fin_amount_paid, fin_cheque_number, fin_cheque_receive_date, fin_status, uuid, delete_log, fin_premium_due_date, fin_remarks, InsurancePolicyID, PaymentToInsurerID)select '".$unique_id."', '".$insert_id."', (
	Select id from iboss_dict_payment_method where iboss_dict_biz_class_id=6 and name=fin_payment_method) as fin_payment_method, (
	select id from iboss_dict_payment_make where iboss_dict_biz_class_id=6 and name=fin_payment_make) as fin_payment_make,(select id from iboss_dict_institution where iboss_dict_biz_class_id=6 and name=fin_institution) as fin_institution, fin_account_number, fin_account_holder, fin_expiary_date, fin_paid_to_date, fin_amount_paid, fin_cheque_number, fin_cheque_receive_date, (
	select id from iboss_dict_payment_status where iboss_dict_biz_class_id=6 and name=fin_status
	) as fin_status, uuid, delete_log, fin_premium_due_date, fin_remarks, InsurancePolicyID, PaymentToInsurerID from temp_iboss_acc_group_policy_financial  where iboss_acc_group_policy_info_id='".$temp_iboss_group_policy_info_id."'");
	
	
				  $this->db->query("insert into iboss_acc_group_endorsement_details_info( iboss_acc_group_policy_info_id, iboss_acc_group_policy_info_rider_id, iboss_acc_group_endorsement_info_id, type, plan_name, premium, gst, gst_value, modal_premium, total_premium, delete_log)Select '".$insert_id."', iboss_acc_group_policy_info_rider_id, '".$insert_id_endorse."', type, plan_name, premium, gst, gst_value, modal_premium, total_premium, delete_log from temp_iboss_acc_group_endorsement_details_info  where iboss_acc_group_policy_info_id='".$temp_iboss_group_policy_info_id."'");
	
				$this->db->query("insert into iboss_acc_group_claim_info(iboss_acc_group_policy_info_id, iboss_crm_unique_id, employee_name, claimant_name, claim_no, plan_type, claim_type, claim_submission_date, incurred_period_from, incurred_period_to, clinic_hospital, incurred_amount, claim_status, settlement_date, claim_settlement_amt, status, delete_log)Select '".$insert_id."', '".$unique_id."', employee_name, claimant_name, claim_no, plan_type, (Select id from iboss_dict_claim_type where iboss_dict_biz_class_id=6 and name=claim_type) as claim_type, claim_submission_date, incurred_period_from, incurred_period_to, clinic_hospital, incurred_amount, (Select id from iboss_dict_claim_status where iboss_dict_biz_class_id=6 and name=claim_status) as claim_status, settlement_date, claim_settlement_amt, status, delete_log from temp_iboss_acc_group_claim_info  where iboss_acc_group_policy_info_id='".$temp_iboss_group_policy_info_id."'");
	
	
			 }
			 
	
		 }
		 
	
	 $_update['cron_status'] = 'Yes';
									
	$this->db->where('id', $temp_iboss_group_policy_info_id);
	$this->db->update('temp_iboss_acc_group_policy_info', $_update);
	
		 }
		
	
		}
	}

	function calculation_details_1($all_values)
	{
		  
		$iboss_dict_currency_type_id=$all_values['iboss_dict_currency_type_id'];
		$iboss_product_li_info_id=$all_values['iboss_product_li_info_id'];
		$exchange_rate=$this->cleanData($all_values['exchange_rate']);
		$original_premium=$this->cleanData($all_values['original_premium']);
		$premium=$this->cleanData($all_values['premium']);
		$original_loading_premium=$this->cleanData($all_values['original_loading_premium']);
		$discount_amount=$this->cleanData($all_values['discount_amount']);
		$original_discount_amount=$this->cleanData($all_values['original_discount_amount']);
		$gst_amount=$this->cleanData($all_values['original_discount_amount']);
		//$basic_shield_premium=$this->cleanData($all_values['basic_shield_premium']);
		$model_premium=$this->cleanData($all_values['model_premium']);
		$total_premium=$this->cleanData($all_values['total_premium']);
		
		$submission_date=$all_values['submission_date'];
		
			$result_values=array();
			if(!empty($iboss_product_li_info_id))
			{
							$sql = "select * from iboss_product_group_info where  id='".$iboss_product_li_info_id."'";
							$result = $this->db->query($sql);
							$iboss_product_li_info= $result->row();
							
							$risk_of_location_info=$iboss_product_li_info->risk_of_location;							
							$gst=$iboss_product_li_info->gst;
							$payment_medisave=$iboss_product_li_info->payment_medisave;
							$policy_fee=$iboss_product_li_info->policy_fee;
							$max_sum_assured=$iboss_product_li_info->max_sum_assured;
							$min_sum_assured=$iboss_product_li_info->min_sum_assured;
							$policy_term=$iboss_product_li_info->policy_term;
							$premium_term=$iboss_product_li_info->premium_term;
							 
							 if(!empty($submission_date))
							 {
										 $submission_date_iso=sg2iso($submission_date); 
										 $sql = "select * from  iboss_product_group_promotion where  iboss_product_group_info_id='".$iboss_product_li_info_id."' and (start_date <= '".$submission_date_iso."' and  end_date >= '".$submission_date_iso."' ) ";
										 $result = $this->db->query($sql);
										 $promotion_rate= $result->row()->discount_rate;
											if(empty($promotion_rate))
											{
											$promotion_rate=0;	
												
											}
						
							 }
				
			}
			
					//Calculation Basic Premium ( SGD ) -A
					 $result_values['premium']=number_format($original_premium * $exchange_rate, 2, '.', '');
								
					//Loading Premium ( SGD )-B
								
					$result_values['loading_premium']=number_format($original_loading_premium * $exchange_rate, 2, '.', '');
					
					
					//Discounted premium ( SGD )-C
					if(!empty($promotion_rate) && $promotion_rate != '0')
					{
					$result_values['discount_amount_original_promotion']= number_format( $promotion_rate  * $result_value['premium'], 2, '.', '');					
					$result_values['discount_amount'] = number_format( $result_value['discount_amount_original_promotion'] * $exchange_rate, 2, '.', '');
					$result_values['discount_plan_rate']=($promotion_rate * 100).' %' ;
					}
					else
					{
					$result_values['discount_amount']=number_format( $original_discount_amount * $exchange_rate, 2, '.', '');
					}
					
					//GST ( SGD )-E
					if($gst=='Yes')
					{
					 $gst_value=(iboss_setup('GST')/100);
					 //$gst_value=1.07;
					$result_values['gst_plan_rate']=iboss_setup('GST');	
					// $result_value['gst_minus']=number_format( ($result_value['premium'] + $result_value['loading_premium'] - $result_value['discount_amount']) *($gst_value/100), 2, '.', '' );
					$result_values['gst_amount']=number_format( ($result_values['premium'] + $result_values['loading_premium'] - $result_values['discount_amount']) * ($gst_value), 2, '.', '' );
					 
					 //$result_value['gst_amount']=number_format(($result_value['gst_minus']) - ($result_value['premium'] + $result_value['loading_premium'] - $result_value['discount_amount']), 2, '.', '');	 
					}else{
						$result_values['gst_amount']=0;
					}
                    
					  
	                //Model Premium		
					$result_values['model_premium']=number_format(($result_values['premium']) + ($result_values['loading_premium'] ) - ($result_values['discount_amount'] ), 2, '.', '');  
				    //Total Premium ( SGD )

					$result_values['total_premium']=number_format(($result_values['premium'] + $result_values['loading_premium'])-($result_values['discount_amount'] ) + ($result_values['gst_amount']) , 2, '.', '');
	                 
					 //Plan GST 
					$result_values['plan_gst']=$gst;
					
					
					$result_values['risk_of_location_new']=$risk_of_location_info;
                    					  
                    

					return $result_values;
										
										
		
	}



 }



 
?>