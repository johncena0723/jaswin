<link href="<?=base_url();?>css/plugins/chosen/new-chosen.css" rel="stylesheet">

<?php $this->load->view("iboss_group_load_file/iboss_tab_nav");?>
<?php $this->load->view("template/jeditable_index.php");?>

<style>






.footer {
	bottom:inherit;
}

#mytable_filter [type="search"]{
	
	width: 450px;
}

</style>
<script>
$(document).ready( function () {
		$(".row_hide").addClass('hidden');
	});	
</script>
<style>
	/*.excel {
    float: right;
	}*/

.loader {
  position: relative;
  display: grid;
  grid-template-columns: 33% 33% 33%;
  grid-gap: 2px;
  width: 50px;
  height: 50px;
}
.loader > div {
  width: 100px;
  height: 100px;
  background: #EE7103;
  -moz-border-radius: 50px;
  -webkit-border-radius: 50px;
  border-radius: 60px;
  position: relative;
  display: inline-block;
  width: 70%;
  height: 70%;  
  transform: scale(0);
  transform-origin: center center;
  animation: loader 0.5s infinite linear;
}
.loader > div:nth-of-type(1), .loader > div:nth-of-type(5), .loader > div:nth-of-type(9) {
  animation-delay: 0.2s;
}
.loader > div:nth-of-type(4), .loader > div:nth-of-type(8) {
  animation-delay: 0.1s;
}
.loader > div:nth-of-type(2), .loader > div:nth-of-type(6) {
  animation-delay: 0.3s;
}
.loader > div:nth-of-type(3) {
  animation-delay: 0.4s;
}
.result {
    padding-left: 70px;
}
@keyframes loader {
  0% {
    transform: scale(0);
  }
  40% {
    transform: scale(1);
  }
  80% {
    transform: scale(1);
  }
  100% {
    transform: scale(0);
  }
}
.news {
  background-color: #00629B;
}

.loader > div:nth-of-type(9) {
  background-color: #00629B;
}

.loader > div:nth-of-type(6) {
  background-color: #e7eaec00;
}

.loader > div:nth-of-type(8) {
  background-color: #e7eaec00;
}

.panel-default {
    border-color: transparent;
}

.panel {
    
    background-color: transparent;    
}


.capitalize {
    text-transform: capitalize;
}

.uppercase {
    text-transform: uppercase;
}
.share-it{
	position:fixed;
	width:10px;

	right:0;
	z-index:9;
	top:10%;
}	
.share-it i{
	font-size:16px;
}
.facebook{margin:0 auto; float:left; margin-right:4px;height:140px;width:25px;}
.facebook  a{
	color:#fff;
	padding:10px 16px;
	background-color:#527aba;
	display:inline-block;
	transition:0.5s ease;
	width:140px;
	
}
/*.facebook  a:hover{
	color:#fff;
	padding:10px 20px;
	margin-left:-20px;
	background-color:#527aba;
	display:inline-block;
}
*/
.twitter{margin:0 auto; float:left; margin-right:4px;}
.twitter  a{
	color:#fff;
	padding:10px 16px;
	background-color:#77cdf1;
	display:inline-block;
	text-align:center;
	transition:0.5s ease;
	width:140px;
}
/*.twitter  a:hover{
	color:#fff;
	padding:10px 20px;
	margin-left:-20px;
	background-color:#77cdf1;
	display:inline-block;
	text-align:center;

}*/
.vertical-text {
	transform: rotate(90deg);
	transform-origin: left top 0;
	margin-left:24px;
}
.modal-backdrop {
    z-index: 1000 !important;
}
.sidebar-container ul.nav-tabs li.active a {font-weight: 600 !important;
		background-color:#527aba;
	 color:#fff;
	 border:none;
}
.fa-copy{
color:orange;	

}

#mytable_filter [type="search"]{
	
	width: 450px;
}

</style>
<style>
.drop_down_up .chosen-drop {
    border-bottom: 0;
    border-top: 1px solid #aaa;
    top: auto;
    bottom: 40px;
}

.dt-buttons{
	float: right;
}

.buttons-html5 {
    color: white;
    background: #f8ac59;
    border: 1px solid #e7eaec;
}
</style>
<script>
$(document).ready( function () {
	var startYear = 1900;
for (i = new Date().getFullYear(); i > startYear; i--)
{
    $('#yearpicker').append($('<option />').val(i).html(i));
}
// jQuery('#group_report_chosen').addClass('drop_down_up');
jQuery('#manager_name_chosen').addClass('drop_down_up');
});


</script>

<script>


</script>



<div class="wrapper wrapper-content animated fadeInRight ecommerce">

	  <div class="ibox float-e-margins close_bar">
	  
	  
	  <div class="ibox-title">
			<h5>Filter</h5>
			
			
		</div>  
		<div class="ibox-content">
			<div class=" ">
	            <?//=form_open_multipart("iboss_monthly_screnning_clients/export_excel_report",array('class'=>"form-horizontal" , 'id'=>'master_export' , "name"=>"master_export"))?>
				<?=form_open_multipart("iboss_business_simple_report/export_excel_report",array('class'=>"form-horizontal" , 'id'=>'master_export' , "name"=>"master_export"))?>
				
									
								<div class="row">
										<!-- start period  -->	
										<div class="col-lg-6">
								<label class="col-lg-12 ">Year</label>
								<div class="form-group" id="data_5k">
									<div class="col-lg-12">
									<select name="yearpicker" id="yearpicker" class="business_repo_val policy_status filter_new" style="margin-left:10px"></select>
									
									<!-- <div class="input-daterange input-group col-lg-12">
									<span class="input-group-addon"><i class="fa fa-calendar"></i></span>
									
									 </div> -->
									
								</div>
			         			</div>
							</div>

								
																   <!-- end period -->
															<!-- policy and transaction  -->
								<div class="col-lg-6">
									 <label id="status_label" class="col-lg-12 row">Biz Based on</label>
						            <div class="form-group ">
						                <div class="col-lg-12">
											<div class="col-lg-12 row">
											
											<div class="i-checks pull-left  policy_status_all" style="margin-top: 8px;"><input name="filter_by" class="business_repo_val policy_status filter_new"  id="submitted" type="radio"  value="submitted">&nbsp;&nbsp;&nbsp;&nbsp;Submitted&nbsp;&nbsp;&nbsp;&nbsp; </div>
										
											<div class="i-checks pull-left  inforce" style="margin-top: 8px;"><input name="filter_by" class="business_repo_val policy_status filter_new"  checked  id="inforce" type="radio"  value="inforce">&nbsp;&nbsp;&nbsp;&nbsp;Inforce &nbsp;&nbsp;&nbsp;&nbsp;</div>
										
						                </div>
										
									</div>
									
						            </div>
								</div>
								</div>
															 <!-- policy end  -->
								<div class="row">
															<!-- Client type -->
													 <div class="col-lg-6">
									 <label class="col-lg-12">Client type</label>
						            <div class="form-group ">
						                <div class="col-lg-12">
										
										<div class="col-lg-12">
											
												<div class="i-checks pull-left" style="margin-top: 8px;"><input name="client_type"   class="business_repo_val client_type iiboss_dict_status_new filter_new"  id="All" type="radio"  value="All">&nbsp;&nbsp;&nbsp;&nbsp;All&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div> 
										
												<div class="i-checks pull-left" style="margin-top: 8px;"><input name="client_type"   class="business_repo_val client_type iiboss_dict_status_new filter_new"  id="INV" type="radio"  checked value="INV">&nbsp;&nbsp;&nbsp;&nbsp;Personal&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div> 

										
												<div class="i-checks pull-left" style="margin-top: 8px;"><input name="client_type"  class="business_repo_val client_type iiboss_dict_status_new filter_new"  id="Corp" type="radio"  value="Corp">&nbsp;&nbsp;&nbsp;&nbsp;Corp&nbsp;&nbsp;&nbsp;&nbsp;</div> 
									
						                </div>		
									</div>
								
						            </div>
								 </div>
											<!-- Client type end -->
						
															<!-- Gender -->
											

													<div class="col-lg-6">
									 <label class="col-lg-12 row">Gender</label>
						            <div class="form-group ">
						                <div class="col-lg-12">
										
										<div class="col-lg-12 row">
											
												<div class="i-checks pull-left" style="margin-top: 8px;"><input name="gender"   class="business_repo_val gender iiboss_dict_status_new filter_new"  id="all" type="radio"  value="all">&nbsp;&nbsp;&nbsp;&nbsp;All&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div> 
										
												<div class="i-checks pull-left" style="margin-top: 8px;"><input name="gender"   class="business_repo_val gender iiboss_dict_status_new filter_new"  id="Male" type="radio"  checked value="1">&nbsp;&nbsp;&nbsp;&nbsp;Male&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div> 

												<div class="i-checks pull-left" style="margin-top: 8px;"><input name="gender"  class="business_repo_val gender iiboss_dict_status_new filter_new"  id="Female" type="radio"  value="2">&nbsp;&nbsp;&nbsp;&nbsp;Female&nbsp;&nbsp;&nbsp;&nbsp;</div> 
									
						                </div>		
									</div>
									 
						            </div>
								 </div>                     <!-- Gender end -->
								 </div> 
											
													<div class="row">
															<!-- Nationality start  -->
													<div class="col-lg-6"> 
														<label class="col-lg-12">Nationality</label>
														<!-- <div class="form-group"> -->
														<div class="col-lg-8">
															<!-- <div class="col-lg-12" id="individual_show"> -->
															<?$attr = 'id="nationality_name" name="nationality_name" class="form-control chosen-select business_repo_val filter_new" value="nationality_name"';?>
																<?=form_dropdown('name', $nationality_value, '', $attr)?>												
															 <!-- </div>						                -->
														</div>
													</div>
										
											<!-- Nationality end  -->
									
										<!-- start period  -->	
									
										
											
								<!-- Pep Start -->
								<div class="col-lg-6">
									 <label class="col-lg-12 row">PEP</label>
						            <div class="form-group">
						                <div class="col-lg-12">
										
										<div class="col-lg-12 row">
											
												 <div class="i-checks pull-left" style="margin-top: 8px;"><input name="pep"   class="business_repo_val pep iiboss_dict_pep_new filter_new"  id="all" type="radio"  checked value="all">&nbsp;&nbsp;&nbsp;&nbsp;All&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div> 
										
												<div class="i-checks pull-left" style="margin-top: 8px;"><input name="pep"   class="business_repo_val pep iiboss_dict_pep_new filter_new"  id="No" type="radio"  value="No">&nbsp;&nbsp;&nbsp;&nbsp;No&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div> 
										
												<div class="i-checks pull-left" style="margin-top: 8px;"><input name="pep"  class="business_repo_val pep iiboss_dict_pep_new filter_new"  id="Yes" type="radio"  value="Yes">&nbsp;&nbsp;&nbsp;&nbsp;Yes&nbsp;&nbsp;&nbsp;&nbsp;</div> 
									 
						                </div>		
									</div>
									
						            </div>
								 </div>
								<!-- Pep End -->
								</div>



								<div class="row">
								<!-- AI Start -->
								<div class="col-lg-6">
									 <label class="col-lg-12">AI</label>
						            <div class="form-group ">
						                <div class="col-lg-12">
										<div class="col-lg-12">
														
												<div class="i-checks pull-left" style="margin-top: 8px;"><input name="ai"   class="business_repo_val ai iiboss_dict_pep_new filter_new"  id="all" type="radio"  checked value="all">&nbsp;&nbsp;&nbsp;&nbsp;All&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div> 
										
												<div class="i-checks pull-left" style="margin-top: 8px;"><input name="ai"   class="business_repo_val ai iiboss_dict_pep_new filter_new"  id="Yes" type="radio"  value="Yes">&nbsp;&nbsp;&nbsp;&nbsp;Yes&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div> 
										
												<div class="i-checks pull-left" style="margin-top: 8px;"><input name="ai"  class="business_repo_val ai iiboss_dict_pep_new filter_new"  id="No" type="radio"  value="No">&nbsp;&nbsp;&nbsp;&nbsp; No&nbsp;&nbsp;&nbsp;&nbsp;</div> 
									
						                 </div>
									</div>
									
						            </div>
								 </div>
								<!-- AI End --> 

								</div>
								
								
								
								
								
								
				<!-- submit and export -->
						<div class="row">
							
						
							<div class="col-sm-4">
							<br>
							<div class="col-sm-4" style="text-align: left;" >
									<!-- <button class='btn btn-info excel' type='button' onclick="export_excel()">Export</button> -->
									<!-- <button class='btn btn-info excel' type='button'    onclick="export_excel_new()">Export</button> -->
								</div>
							</div>
							<div class="col-sm-4"></div>
						 <div class="col-sm-4" style="text-align: right;" >							
						<br>
									<!-- <button class="btn btn-primary"  name="result" type="button" onclick="show_report();">Submit</button> -->
									<button class="btn btn-primary sub_hide"  name="result" type="button" onclick="check_to_change_function();">Submit</button>
									<button class="btn btn-default" name="reset" onclick="return form_clear();" type="button">Clear</button>
								</div>
							
						</div>
			 
				                   
					
	            <?=form_close()?>
			</div>		
		</div>

		<!-- <div class="row row_hide hidden">
			<div class="col-lg-12">
				<div class="ibox float-e-margins">
										
			  	 </div>
				
				
				<div class="ibox-content">
					<div class=""> -->


		<div class="row row_hide1 hidden ">
			<div class="col-lg-12">
				<div class="ibox float-e-margins">
					</div>					
			  	 		
				
				<div class="ibox-content">
					<div id="biz_result_report"></div>				
				</div>
				
				
			</div>
		</div>


					<div class="row row_hide hidden">
			<div class="col-lg-12">
				<div class="ibox float-e-margins">
					</div>					
			  	 
				
				
				<div class="ibox-content">
					<div class="">
				<table id="mytable57" class="table table-striped  table-hover">
				<thead>
      
      <tr>
	  <th style="vertical-align: middle;"><?="UNIQUE_ID"?></th>
	  <th style="vertical-align: middle;"><?="CLIENT TYPE"?></th>
	  <th style="vertical-align: middle;"><?="NATIONALITY_ID"?></th>
	  <th style="vertical-align: middle;"><?="NATIONALITY NAME"?></th>
  	  <th style="vertical-align: middle;"><?="GENDER"?></th> 
        <th style="vertical-align: middle;"><?="PEP"?></th>
       <th style="vertical-align: middle;"><?="AI"?></th>       
       
      </tr> 
    </thead>
	<tbody>
	</tbody>
		
	</table>
					</div>
				</div>
				
				
			</div>
		</div>



 <div class="modal fade" id="loading_gif" role="dialog" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog" style="margin: 14% 45%;">
    
       <!--Modal content--> 
    	  <span style="color: white;" class="waitclass"><i class="fa fa-spinner fa-spin fa-4x fa-fw"></i></span> 
      
      </div>  
 </div>  
					<table class="table table-striped  table-hover" id="result_policy" >
						<a class="btn btn-info excel hide" value = '' onclick="export_excel()">Export</a>
						<thead>
	
						</thead>
						
					</table>
					</div>
				</div>
				
				
			</div>
		</div>
		

    
	
		
		
	<br>	
			 <!-- <div class="row" >
			
				<div class="content_result ibox-content col-lg-12">
						<table class="table table-striped  table-hover" id="result_policy" >
							
							<thead>
							</thead>
							
						</table>
				</div>
		
		
			</div>  -->
	<br>	
	
	<br>	
	<br>	
	<br>	
	<br>	
		<br>	
	</div>
	
</div>
<br>	
	
		

</div>
</div>
</div>

	<!-- <div class="row row_hide hidden">
			<div class="col-lg-12">
				<div class="ibox float-e-margins">
					</div>					
			  	 
				
				
				<div class="ibox-content">
					<div class="">
				<table id="mytable56" class="table table-striped  table-hover">
		<thead>
			<tr>
				<td>iboss_crm_unique_id</td>
				<td>submission_date</td>
				<td>far_name</td>
				<td>far_code</td>
				<td>identification_no</td>
				<td>nric_name</td>
				<td>pep</td>
				<td>nationality_name</td>
			</tr> 
		</thead>
		
	</table>
					</div>
				</div>
				
				
			</div>
		</div>



 <div class="modal fade" id="loading_gif" role="dialog" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog" style="margin: 14% 45%;">
    
       Modal content 
    	  <span style="color: white;" class="waitclass"><i class="fa fa-spinner fa-spin fa-4x fa-fw"></i></span> 
      
      </div>  
 </div>   -->

<script src="<?=base_url()?>js/plugins/dataTables/jquery.datatables.min.js"></script>
<link href="<?=base_url()?>css/plugins/dataTables/datatables.min.css" rel="stylesheet">
<script src="<?=base_url()?>js/plugins/dataTables/datatables.min.js"></script>



<script> 
/*$(document).ready(function(){	
far_load()
$('.pep').on('ifChecked', function(event){
	$.ajax({
			  type: "POST",
			//   url: "<?php //echo base_url()?>index.php/iboss_monthly_screnning_clients/product_details/",
			url: "<?php// echo base_url()?>index.php/iboss_monthly_screnning_clients/product_details/",

			  data:$('.filter_new').serialize(),
			
			  success: function(data)
			  {
				  //alert(data);
				  $('#individual_show').html(data);				  
				  $('.chosen-select').chosen({width:"100%"});
			  }
	});
	


});
});*/
</script>

<script>

$(document).ready(function(){	
far_load()
$('.far_status').on('ifChecked', function(event){
	$.ajax({
			  type: "POST",
			//   url: "<?php //echo base_url()?>index.php/iboss_monthly_screnning_clients/product_details/",
			url: "<?php echo base_url()?>index.php/iboss_business_simple_report/product_details/",

			  data:$('.filter_new').serialize(),
			
			  success: function(data)
			  {
				  //alert(data);
				  $('#individual_show').html(data);				  
				  $('.chosen-select').chosen({width:"100%"});
			  }
	});
	






});
});



	$(function() {
  $("#datepicker").datepicker({
    dateFormat: 'yy',
    changeYear: true,
    changeMonth: false,
  });
});



function far_load()
{
	//$('#loading_gif').modal('show');
	$.ajax({
			  type: "POST",
			  url: "<?php echo base_url()?>index.php/iboss_business_simple_report/product_details/",
			  data:$('.filter_new').serialize(),
			
			  success: function(data)
			  {
				  //alert(data);
				  $('#individual_report_show').html(data);				  
				  $('#filter_new').html(data);
				  $('.chosen-select').chosen({width:"100%"});
				  jQuery('#far_name_chosen').addClass('drop_down_up');
			  }
	});
	
}






function form_clear()
  {
	 $(".row_hide").addClass('hidden');
	$('#nric_no').val('');
	$('#far_code_display').val('');
	$('.chosen-select option:selected').removeAttr('selected');
	$('.chosen-select').trigger("chosen:updated");
	// audit_client_name();
  }
  
  function show_report_old()
{
	$('#loading_gif').modal('show');
	
  $.ajax({
        type: "POST",
        url: "<?php echo base_url()?>index.php/iboss_business_simple_report/get_product_json_new/",
		data:$('.filter_new').serialize(),
        success: function(data)
        {
          
    	      $('#result_policy').html(data);
			  $(".row_hide").removeClass('hidden');
			  $('#loading_gif').modal('hide'); 
        }
  });
  
  
}

function check_to_change_function(){

	if($('#business_class').val() == 0){
		$('.row_hide1').addClass('hidden');
		$('.sub_hide').addClass('hidden');
		
		show_report();
	} else {
		$(".row_hide").addClass('hidden');
		$('.sub_hide').addClass('hidden');
		result_report();
	}

}


function result_report()
{
	var url =  "<?php echo base_url().'index.php/iboss_business_simple_report/get_product_json_new_old'?>";
	$('.row_hide1').removeClass('hidden');	
	$('#loading_gif').modal('show');

        $.ajax({
        url:        url,
        type:       'POST',
        cache:      false,
		dataType : "html",
		contentType: "application/x-www-form-urlencoded",
		data: $('.business_repo_val').serialize()+'&daterange='+$('#daterange').val(),
        success: function(html){
			
				$('#biz_result_report').html(html);
				$('#loading_gif').modal('hide');            
        } 

         /*error: function() {
          $('#loading_gif').modal('hide');
		  $(".row_hide").addClass('hidden');
            $('#warning_alert_message_index').modal('show');
              $('.para').text(type);
            }
					hello 
			{"data": "unique_id"},
		   
		   {"data": "client_type"},
							{"data": "nationality_id"},   
							{"data": "nationality_name"},   
							 {"data": "gender"},								             		
							 {"data": "pep"},
							 {"data":"ai"},

							 hello 
       */
      });
	  
	  $('.sub_hide').removeClass('hidden');
}


function show_report()
{
	//$('.excel').addClass('hide');
	to_store_to_get();
	var unique_id=$(".unique_id").val();
	var client_type=$("#client_type").val();
	var nationality_id = $('.nationality_id').val();
	var finnationality_name_no = $('#nationality_name').val();
	var gender = $('#gender').val();
	var pep = $('#pep').val();
	var ai = $('#ai').val();


	$(".row_hide").removeClass('hidden');
	$('#mytable57').DataTable().clear();
	
	var dtable = $("#mytable57").DataTable({
		
          initComplete: function() {
             var api = this.api();
              $('#mytable_filter input,.filter')
                  .off('.DT')
                  .on('input.DT', function() {
                      api.search(this.value).draw();
              });
          },
              language: {
		              processing: "<div class='loader'><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>"
		          },
		  destroy: true,
              processing: true,
              serverSide: true,
			  
              ajax: {"url": "<?php echo base_url().'index.php/iboss_business_simple_report/get_product_json/'?>"+far, "type": "POST",
			dataType : "json",
              error: function (xhr, error, code)
            	{
            	   	var type="Please check the data or contact IT Dept!!";
    				$(".row_hide").addClass('hidden');
                 	$('#warning_alert_message_index').modal('show');
                 	$('.para').text(type);

            	  var headers = xhr.getAllResponseHeaders();
   				  var arr = headers.trim().split(/[\r\n]+/);
   				  var headerMap = {};
    			 arr.forEach(function (line) {
      				var parts = line.split(': ');
      				var header = parts.shift();
      				var value = parts.join(': ');
     			    headerMap[header] = value;
    				});

    				if(headerMap['status']=='500'){
    				var type="Please check the data or contact IT Dept!!";
    				$(".row_hide").addClass('hidden');
                 	$('#warning_alert_message_index').modal('show');
                 	$('.para').text(type);
    				}

    			if(headerMap['status']=='404'){
    				var type="Permission denied!!!";
    				$(".row_hide").addClass('hidden');
                 	$('#warning_alert_message_2').modal('show');
                 	$('.para').text(type);
    			}
            },
			  
			  "data": function(d) {
					   var frm_data = $('.filter_new').serializeArray();
					   $.each(frm_data, function(key, val) {
						 d[val.name] = val.value;						 
					   });					   
					 },
					 
			  },
			  /*
			  {"data": "unique_id"},
		   
		   {"data": "client_type"},
							{"data": "nationality_id"},   
							{"data": "nationality_name"},   
							 {"data": "gender"},								             		
							 {"data": "pep"},
							 {"data":"ai"},
			  */
              deferRender: true,
                	columns: [
						//{"data": "unique_id"},//0
						{"data": "unique_id"},//1
						{"data": "client_type"},//2
						{"data": "nationality_id"},//2
						{"data": "nationality_name" },//3
						{"data": "gender"},//2
						{"data": "pep" },
						{"data": "ai" },
						
						//{"data": "passport_no"},
						//{"data": "fin_no"},
						
						//{"data": "passport_no"},//6
						//{"data": "fin_no"}//7

                  ], "columnDefs":[ { "orderable":false , "targets":5}],
                
		
               rowCallback: function(row, data, iDisplayIndex) {
              var info = this.fnPagingInfo();
              var page = info.iPage;
              var length = info.iLength;
              $('td:eq(0)', row).html();
          }
      });
	  
	  
	$("#mytable_filter").addClass('hidden'); 


	$('.buttons-excel').removeClass('btn-default');


$('a.toggle-vis').on( 'click', function (e) {
        e.preventDefault();
 
        // Get the column API object

        var column = dtable.column( $(this).attr('data-column') );
 
        // Toggle the visibility
        column.visible( ! column.visible() );
       // column.searchable();
    } );

$('.test').on('click', function() {
  //clear global search values
  dtable.search('');
  dtable.column($(this).data('columnIndex')).search(this.value).draw();
});	

$('.reloadtable_search').on('keyup', function() {
  //clear global search values
  //dtable.search('');
  dtable.columns([3, 4]).search(this.value).draw();
});	

	
}

































//function Load_WrapjointFAR() 

/*
function show_report()
{

// 	ajax: {"url": "<?php// echo base_url().'index.php/iboss_business_simple_report/get_product_json_new_old/'?>",
// 			  "type": "POST",
             
//          "data": function(d) {
// 			console.log(d);
// }
// });
$('#mytable57').dataTable( {
    paging: false,
    searching: false
} );


$(".row_hide").removeClass('hidden');
$('#mytable57').DataTable().clear();
 $.ajax({
                url: "<?php echo base_url()?>index.php/iboss_business_simple_report/get_product_json_new_old/",
				type: "POST",
				data:$('.filter_new').serialize(),
                dataSrc: "",
                dataType: "json",
                success: function (data) {
					console.log(data);
                    $('#mytable57').dataTable({
 
                        data: data,
				 columns:[          
							{data: 'unique_id'},
							/*{data: 'client_type'},
							{data: 'nationality_id'},   
							{data: 'nationality_name'},   
							 {data: 'gender'},								             		
							 {data: 'pep'},
							 {data:'ai'}],
							dom: 'Bfrtip',
            buttons: [
                'copy', 'csv', 'excel', 'pdf', 'print'
            ],]
                    })
                }
            });
}*/
// var dtable = $("#mytable57").DataTable({
// 	"processing": true,
//         "serverSide": true,
// 		ajax({
//         type: "POST",
//         url: "<?php// echo base_url()?>index.php/iboss_business_simple_report/get_product_json_new_old/",
// 		data:$('.filter_new').serialize(),
//         success: function(data)
//         {
// 			console.log(data);
			
// 			columns: [          
// 		   {"data": "client_type"},
// 		   {"data": "gender"},	
// 		   {"data": "nationality_name"},                		
// 			{"data": "pep"}]
			
//         }
//   });
// });   
//}




			
// $(".row_hide").removeClass('hidden');
// $('#mytable57').DataTable().clear();

// var dtable = $("#mytable57").DataTable({
    
// 			  initComplete: function() {
// 				var api = this.api();
// 				$('#mytable_filter input,.filter')
// 				.off('.DT')
// 				.on('input.DT', function() {
// 				api.search(this.value).draw();
// 				});
// 				},
//               language: {
//                   processing: "<div class='loader'><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div>"
//               },
//               destroy: true,
//               processing: true,
//               serverSide: true,
//              ajax: {"url": "<?php echo base_url().'index.php/iboss_business_simple_report/get_product_json_new_old/'?>",
// 			  "type": "POST",
             
//          "data": function(d) {
// 			console.log(d);
// 			//alert(data);
//              var frm_data = $('.filter_new').serializeArray();
//              $.each(frm_data, function(key, val) {
// 				console.log(val);
//              d[val.name] = val.value;

//              });             
//            },
           
//         },
//                 columns: [          
// 		   {"data": "client_type"},
// 		   {"data": "gender"},	
// 		   {"data": "nationality_name"},                		
// 			{"data": "pep"},
			
  
// ], //"columnDefs":[ { "orderable":false , "targets":6}],
//               rowCallback: function(row, data, iDisplayIndex) {
//               var info = this.fnPagingInfo();
//               var page = info.iPage;
//               var length = info.iLength;
//               $('td:eq(0)', row).html();
//           }
//       });

// $('a.toggle-vis').on( 'click', function (e) {
//          e.preventDefault();
//         // Get the column API object
//         var column = dtable.column( $(this).attr('data-column') );
//         // Toggle the visibility
//         column.visible( ! column.visible() );
//        // column.searchable();
//     } );

// $('.test').on('click', function() {
//   dtable.search('');
//   dtable.column($(this).data('columnIndex')).search(this.value).draw();
// });  

// $('.reloadtable_search').on('keyup', function() {
//   dtable.columns([3, 4]).search(this.value).draw();
// });  

// $('.sub_hide').removeClass('hidden');	
  



function master_crm_val()
{
/*$('#loading_gif').modal('show');
far_name = $('#far_name').val();

if(far_name=='' )
{
$('#loading_gif').modal('hide');
notify('warning','Select the FAR Name !');
return false;
} 

var  far_status=$(".far_status").val();
var  daterange=$(".daterange").val();
var  business_class=$("#business_class").val();*/

var  far_code=$('#far_name').val();
 

$(".row_hide").removeClass('hidden');
$('#mytable').DataTable().clear();

var dtable = $("#mytable").DataTable({
    
          initComplete: function() {
             var api = this.api();
              $('#mytable_filter input,.filter')
                  .off('.DT')
                  .on('input.DT', function() {
                      api.search(this.value).draw();
              });
          },
              language: {
                  processing: "<div class='loader'><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div>"
              },
      destroy: true,
              processing: true,
              serverSide: true,
              ajax: {"url": "<?php echo base_url().'index.php/iboss_business_simple_report/get_product_json_new_old/'?>"+far_code, "type": "POST",
              error: function (xhr, error, code)
              {
                   var type="Please check the data or contact IT Dept!!";
            $(".row_hide").addClass('hidden');
                   $('#warning_alert_message_index').modal('show');
                   $('.para').text(type);

                var headers = xhr.getAllResponseHeaders();
             var arr = headers.trim().split(/[\r\n]+/);
             var headerMap = {};
           arr.forEach(function (line) {
              var parts = line.split(': ');
              var header = parts.shift();
              var value = parts.join(': ');
               headerMap[header] = value;
            });

            if(headerMap['status']=='500'){
            var type="Please check the data or contact IT Dept!!";
            $(".row_hide").addClass('hidden');
                   $('#warning_alert_message_index').modal('show');
                   $('.para').text(type);
            }

          if(headerMap['status']=='404'){
            var type="Permission denied!!!";
            $(".row_hide").addClass('hidden');
                   $('#warning_alert_message_2').modal('show');
                   $('.para').text(type);
          }
            },
        
        "data": function(d) {
			// console.log(d);
             var frm_data = $('.filter_new').serializeArray();
             $.each(frm_data, function(key, val) {
             d[val.name] = val.value;             
             });             
           },
           
        },
       
              deferRender: true,
                  columns: [
            
            {"data": "client_type"},//1
			{"data": "gender"},
            {"data": "nationality_name"},//
            {"data": "pep"},//4
			//{"data":"count_li"}
			
            // {"data":"count_gi"}, 
            // {"data":"count_group"},  
            // {"data":"count_inv"}                   
    

], "columnDefs":[ { "orderable":false , "targets":4}],
               
               rowCallback: function(row, data, iDisplayIndex) {
              var info = this.fnPagingInfo();
              var page = info.iPage;
              var length = info.iLength;
              $('td:eq(0)', row).html();
          }
      });
    
    
  $("#mytable_filter").addClass('hidden'); 
  $('.buttons-excel').removeClass('btn-default');


$('a.toggle-vis').on( 'click', function (e) {
         e.preventDefault();
        // Get the column API object
        var column = dtable.column( $(this).attr('data-column') );
        // Toggle the visibility
        column.visible( ! column.visible() );
       // column.searchable();
    } );

$('.test').on('click', function() {
  dtable.search('');
  dtable.column($(this).data('columnIndex')).search(this.value).draw();
});  

$('.reloadtable_search').on('keyup', function() {
  dtable.columns([3, 4]).search(this.value).draw();
});  

  
}


function individual_report(value, forval='individual_report')
{

$('#individual_report_show').html(''+setwaiting_big);
	var mystr =$('.iiboss_dict_status_new').serialize();
	var status = mystr.split("=");
	
	
	$.ajax({
			  type: "POST",
			  url: "<?php echo base_url()?>index.php/iboss_business_simple_report/product_details/",
			  data:$('.filter_new').serialize(),
			
			  success: function(data)
			  {
				  //alert(data);
				  $('#individual_report_show').html(data);				  
				  $('#filter_new').html(data);
				  $('.chosen-select').chosen({width:"100%"});
				  jQuery('#far_name_chosen').addClass('drop_down_up');
			  }
	});
	
}

function export_excel(){

var start_date=$( "input[name^='daterangepicker_start']" ).val();
var end_date=$( "input[name^='daterangepicker_end']" ).val();
var business_class_new=$("#business_class").val();
var daterange=$("#daterange").val();
var far_name = $('#far_name').val();
var pep =$('#pep').val();


var fin_no = $('#fin_no').val();
//var client_id = $('#client_id').val();
var passport = $('#passport_no').val();
$('#loading_gif').modal('show');

if($.trim(business_class_new) == '' &&  $.trim(daterange) == '' && $.trim(client_name) == '' && $.trim(fin_no) == '' && $.trim(passport) == ''){
	$('#loading_gif').modal('hide');
	notify('warning','Select the values !');
	return false;
}


	
	$('#table_individual_tbody').empty();
	$.ajax({
	url: "<?php echo base_url().'index.php/iboss_business_simple_report/export_excel/'?>",
	type: "POST",
	data: $('.business_repo_val').serialize()+'&period_of_start_date='+start_date+'&period_of_end_date='+end_date,
	dataType : "json",
	success:function( data){
			 
			 let table_data = "";

			 for(let count=0, result_length=data.length; count < result_length; count++) {
			 table_data += "<tr>";
				 table_data += "<td>"+data[count]['unique_id']+"</td>";
				 table_data += "<td>"+data[count]['business_class_new']+"</td>";
				 table_data += "<td>"+data[count]['daterange']+"</td>";
				 table_data += "<td>"+data[count]['iboss_preferred_name']+"</td>";
				 table_data += "<td>"+data[count]['identification_no']+"</td>";
				 table_data += "<td>"+data[count]['passport_no']+"</td>";
				 table_data += "<td>"+data[count]['fin_no']+"</td>";
				 table_data += "<td>"+data[count]['nric_name']+"</td>";
				 table_data += "<td>"+data[count]['pep']+"</td>";
				 
			table_data += "</tr>";
			 }
			 
			 $('#table_individual_tbody').append(table_data);

			 $('#loading_gif').modal('hide');
			 
				 platform_export( 'Master_Crm' ,'xls');
			 
	 }, error: function() {
		$('#loading_gif').modal('hide');
		$('#warning_alert_message_2').modal('show');
	 }	
});

}




function export_excel_new()
{

$('#loading_gif').modal('show');
// business_class = $('#business_class').val();
far_name = $('#far_name').val();

// if(  far_name=='' )
// 		{

			
			
// 	       $('#loading_gif').modal('hide');
// 			notify('warning','Select the values !');
// 			return false;
// 		} 
$("#master_export")[0].submit();
$('#loading_gif').modal('hide');

}

// function from_date()
// {
// 	$("#data_5 .input-daterange #period_of_start_date").datepicker({
//         //numberOfMonths: 2,
// 	    format: "dd/mm/yyyy",
// 	    keyboardNavigation: false,
// 	    forceParse: false,
// 	    autoclose: true
//     }).on('changeDate', function(selected){
//     	//alert('sdfsd');
//       	var minDate = new Date(selected.date.valueOf());
// 		$("#data_5 .input-daterange #period_of_end_date").datepicker('setStartDate', minDate);
//     });
// }

// function end_date()
// {
// 	$("#data_5 .input-daterange #period_of_end_date").datepicker({
//         //numberOfMonths: 2,
// 	    format: "dd/mm/yyyy",
// 	    keyboardNavigation: false,
// 	    forceParse: false,
// 	    autoclose: true
//     }).on('changeDate', function(selected){
//     	//alert('sdfsd');
//       	var maxDate = new Date(selected.date.valueOf());
// 		$("#data_5 .input-daterange #period_of_start_date").datepicker('setEndDate', maxDate);
//    	});  
// }
	



// backup surendhar // 
// function get_product_json_new_old($value='') 
// {
// 	//header('Content-Type: application/json');
// 	//print_r($_POST); die();
// //echo 'hhhhh';
// // 

// // 	error_reporting(E_ALL);
// //  			ini_set('display_errors', 1);

// // // 			ini_set('memory_limit', '-1');
// // // 			ini_set('max_execution_time', 0);
// // // 			memory_get_peak_usage(true);
// // echo 'hello';
//     $year = $_POST['yearpicker'];
// 	$biz_based=$_POST['filter_by'];
// 	$client_type=$_POST['client_type'];
// 	$gender=$_POST['gender'];
// 	$nationality=$_POST['name'];
// 	$pep=$_POST['pep'];
// 	$ai=$_POST['ai'];

// 	if($biz_based=='inforce'){

// 		$common_biz_based='inforce_date';
// 		$inv_biz_based='completion_date';
// 		$others_biz_based='completed_date';

// 	}else{
		
// 		$common_biz_based='submission_date';
// 		$inv_biz_based='submitted_date';
// 		$others_biz_based='submission_date';

// 	}

// 	if($client_type=='Corp')
// 	{
// 		$clientbased ='client_type';
// 	}

// 	else if($client_type=='INV')
// 	{	
// 		$clientbased ='client_type';
// 	}

// 	else
// 	{

// 		//$clientbased='';
// 	}

	

//    $data = new stdClass();
//    $data->templates = array('datatables','datepicker','icheck','chosen','select2');


// 	$master_excel = "select *,count(*) from  (select dest.* from (
// 	select * from(
// 	select iboss_crm_unique_id from  iboss_acc_li_policy_info  where delete_log='False' and DATE_FORMAT( $common_biz_based ,"%Y" ) = $year
	
// 	union
// 	select iboss_crm_unique_id from  iboss_acc_gi_policy_info  where delete_log='False' and DATE_FORMAT( $common_biz_based ,"%Y" ) = $year 
// 	union
// 	select iboss_crm_unique_id from  iboss_acc_group_policy_info  where delete_log='False' and DATE_FORMAT( $common_biz_based ,"%Y" ) = $year 
// 	union
// 	select iboss_crm_unique_id from iboss_acc_inv_report where delete_log='False' and DATE_FORMAT( $inv_biz_based ,"%Y" ) = $year
// 	union
// 	select iboss_crm_unique_id from iboss_acc_other_services_info where delete_log='False' and DATE_FORMAT( $others_biz_based ,"%Y" ) = $year
// 	)a
// 	) src,
// 	(SELECT unique_id,client_type,nationality_id,nationality_name,gender,ai,pep FROM iboss_master_crm_report) dest where  dest.unique_id=src.iboss_crm_unique_id"; 
	
// //print_($master_excel); die();
	

// //(SELECT unique_id,client_type,nationality_id,nationality_name,gender,ai,pep FROM iboss_master_crm_report) dest where  dest.unique_id=src.iboss_crm_unique_id 
// //	)a group by gender,nationality_name,pep where client_type= $client_type";

	
	

	
   
  
   
//    $export = $this->iboss_read->query($master_excel);
// 	 $data->master_export_value =$export->result_array();
	 
// 	 echo json_encode($data);
	 
  
// }

// backup end surendhar //

</script>