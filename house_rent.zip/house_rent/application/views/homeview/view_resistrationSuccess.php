<!DOCTYPE html>
<html>
<head>
	<?php  $this->load->view('headerview/headerCSSLink')?>

	<title>Home:: Owner Registration Success</title>

</head>
<body >

	<div class="container" style="background-color:white; margin-top: 100px; padding-bottom: 100px;">
		
		<?php  $this->load->view('headerview/homeBodyTopView')?>

		<h4>Owner Registration Success </h4><hr>

		<div class="alert alert-success">
			Now You Can Login And Post Ads Fore Your Home
		</div>

			
		</center>
	</div>

</body>
</html>