<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Tenant | Dashboard</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.6 -->
  <!-- <link rel="stylesheet" href="../surendhar/bootstrap/css/bootstrap.min.css"> -->


  <link rel="stylesheet" href="<?php echo base_url('surendhar/bootstrap/css/bootstrap.min.css'); ?>"/>
  
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo base_url('surendhar/dist/css/AdminLTE.min.css'); ?>"/>
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="<?php echo base_url('surendhar/dist/css/skins/_all-skins.min.css'); ?>"/>
  <!-- iCheck -->
  <link rel="stylesheet" href="<?php echo base_url('surendhar/plugins/iCheck/flat/blue.css'); ?>"/>
  <!-- Morris chart -->
  <link rel="stylesheet" href="<?php echo base_url('surendhar/plugins/morris/morris.css'); ?>"/>
  <!-- jvectormap -->
  <link rel="stylesheet" href="<?php echo base_url('surendhar/plugins/jvectormap/jquery-jvectormap-1.2.2.css'); ?>"/>
  <!-- Date Picker -->
  <link rel="stylesheet" href="<?php echo base_url('surendhar/plugins/datepicker/datepicker3.css'); ?>"/>
  <!-- Daterange picker -->
  <link rel="stylesheet" href="<?php echo base_url('surendhar/plugins/daterangepicker/daterangepicker.css'); ?>"/>
  <!-- bootstrap wysihtml5 - text editor -->
  <link rel="stylesheet" href="<?php echo base_url('surendhar/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css'); ?>"/>

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
  
<script> 
/*document.ready({
    $('.count').each(function () {
    $(this).prop('Counter',0).animate({
        Counter: $(this).text()
    }, {
        duration: 4000,
        easing: 'swing',
        step: function (now) {
            $(this).text(Math.ceil(now));
        }
    });
});
})
*/
</script>
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">
    <!-- Logo -->
    <a href="#" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>Ren</b>al</span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><b>Rental</b></span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </a>

      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          <!-- Messages: style can be found in dropdown.less-->
          <li class="dropdown messages-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <i class="fa fa-envelope-o"></i>
              <span class="label label-success">4</span>
            </a>
            <ul class="dropdown-menu">
              <li class="header">You have 4 messages</li>
              <li>
                <!-- inner menu: contains the actual data -->
                <ul class="menu">
                  <li><!-- start message -->
                    <a href="#">
                      <div class="pull-left">
                        <img src="surendhar/dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">
                      </div>
                      <h4>
                        Support Team
                        <small><i class="fa fa-clock-o"></i> 5 mins</small>
                      </h4>
                      <p>Why not buy a new awesome theme?</p>
                    </a>
                  </li>
                  <!-- end message -->
                  <li>
                    <a href="#">
                      <div class="pull-left">
                        <img src="surendhar/dist/img/user3-128x128.jpg" class="img-circle" alt="User Image">
                      </div>
                      <h4>
                        <!-- AdminLTE Design Team -->
                        <small><i class="fa fa-clock-o"></i> 2 hours</small>
                      </h4>
                      <p>Why not buy a new awesome theme?</p>
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <div class="pull-left">
                        <img src="surendhar/dist/img/user4-128x128.jpg" class="img-circle" alt="User Image">
                      </div>
                      <h4>
                        Developers
                        <small><i class="fa fa-clock-o"></i> Today</small>
                      </h4>
                      <p>Why not buy a new awesome theme?</p>
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <div class="pull-left">
                        <img src="surendhar/dist/img/user3-128x128.jpg" class="img-circle" alt="User Image">
                      </div>
                      <h4>
                        Sales Department
                        <small><i class="fa fa-clock-o"></i> Yesterday</small>
                      </h4>
                      <p>Why not buy a new awesome theme?</p>
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <div class="pull-left">
                        <img src="surendhar/dist/img/user4-128x128.jpg" class="img-circle" alt="User Image">
                      </div>
                      <h4>
                        Reviewers
                        <small><i class="fa fa-clock-o"></i> 2 days</small>
                      </h4>
                      <p>Why not buy a new awesome theme?</p>
                    </a>
                  </li>
                </ul>
              </li>
              <li class="footer"><a href="#">See All Messages</a></li>
            </ul>
          </li>
          <!-- Notifications: style can be found in dropdown.less -->
          <li class="dropdown notifications-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <i class="fa fa-bell-o"></i>
              <span class="label label-warning">10</span>
            </a>
            <ul class="dropdown-menu">
              <li class="header">You have 10 notifications</li>
              <li>
                <!-- inner menu: contains the actual data -->
                <ul class="menu">
                  <li>
                    <a href="#">
                      <i class="fa fa-users text-aqua"></i> 5 new members joined today
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <i class="fa fa-warning text-yellow"></i> Very long description here that may not fit into the
                      page and may cause design problems
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <i class="fa fa-users text-red"></i> 5 new members joined
                    </a>
                  </li>

                  <li>
                    <a href="#">
                      <i class="fa fa-shopping-cart text-green"></i> 25 sales made
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <i class="fa fa-user text-red"></i> You changed your username
                    </a>
                  </li>
                </ul>
              </li>
              <li class="footer"><a href="#">View all</a></li>
            </ul>
          </li>
          <!-- Tasks: style can be found in dropdown.less -->
          <li class="dropdown tasks-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <i class="fa fa-flag-o"></i>
              <span class="label label-danger">9</span>
            </a>
            <ul class="dropdown-menu">
              <li class="header">You have 9 tasks</li>
              <li>
                <!-- inner menu: contains the actual data -->
                <ul class="menu">
                  <li><!-- Task item -->
                    <a href="#">
                      <h3>
                        Design some buttons
                        <small class="pull-right">20%</small>
                      </h3>
                      <div class="progress xs">
                        <div class="progress-bar progress-bar-aqua" style="width: 20%" role="progressbar" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100">
                          <span class="sr-only">20% Complete</span>
                        </div>
                      </div>
                    </a>
                  </li>
                  <!-- end task item -->
                  <li><!-- Task item -->
                    <a href="#">
                      <h3>
                        Create a nice theme
                        <small class="pull-right">40%</small>
                      </h3>
                      <div class="progress xs">
                        <div class="progress-bar progress-bar-green" style="width: 40%" role="progressbar" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100">
                          <span class="sr-only">40% Complete</span>
                        </div>
                      </div>
                    </a>
                  </li>
                  <!-- end task item -->
                  <li><!-- Task item -->
                    <a href="#">
                      <h3>
                        Some task I need to do
                        <small class="pull-right">60%</small>
                      </h3>
                      <div class="progress xs">
                        <div class="progress-bar progress-bar-red" style="width: 60%" role="progressbar" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100">
                          <span class="sr-only">60% Complete</span>
                        </div>
                      </div>
                    </a>
                  </li>
                  <!-- end task item -->
                  <li><!-- Task item -->
                    <a href="#">
                      <h3>
                        Make beautiful transitions
                        <small class="pull-right">80%</small>
                      </h3>
                      <div class="progress xs">
                        <div class="progress-bar progress-bar-yellow" style="width: 80%" role="progressbar" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100">
                          <span class="sr-only">80% Complete</span>
                        </div>
                      </div>
                    </a>
                  </li>
                  <!-- end task item -->
                </ul>
              </li>
              <li class="footer">
                <a href="#">View all tasks</a>
              </li>
            </ul>
          </li>
          <!-- User Account: style can be found in dropdown.less -->
          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <img src="surendhar/dist/img/user2-160x160.jpg" class="user-image" alt="User Image">
              <span class="hidden-xs"><?php echo $this->session->userdata('user'); ?></span>
            </a>
            <ul class="dropdown-menu">
              <!-- User image -->
              <li class="user-header">
                <img src="surendhar/dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">

                <p>
                <?php echo $this->session->userdata('user'); ?>
                  <small>Member since Nov. 2012</small>
                </p>
              </li>
              <!-- Menu Body -->
              <li class="user-body">
                <div class="row">
                  <div class="col-xs-4 text-center">
                    <a href="#">Followers</a>
                  </div>
                  <div class="col-xs-4 text-center">
                    <a href="#">Sales</a>
                  </div>
                  <div class="col-xs-4 text-center">
                    <a href="#">Friends</a>
                  </div>
                </div>
                <!-- /.row -->
              </li>
              <!-- Menu Footer-->
              <li class="user-footer">
                <div class="pull-left">
                  <a href="#" class="btn btn-default btn-flat">Profile</a>
                </div>
                <div class="pull-right">
                  <a href="<?php echo base_url()."login/logout"; ?>" class="btn btn-default btn-flat">Sign out</a>
                </div>
              </li>
            </ul>
          </li>
          <!-- Control Sidebar Toggle Button -->
          <li>
            <a href="#" data-toggle="control-sidebar"><i class="fa fa-gears"></i></a>
          </li>
        </ul>
      </div>
    </nav>
  </header>
   <!-- Left side column. contains the logo and sidebar -->
   <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="surendhar/dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p><?php echo $this->session->userdata('user'); ?></p>
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>
      <!-- search form -->
      <form action="#" method="get" class="sidebar-form">
        <div class="input-group">
          <input type="text" name="q" class="form-control" placeholder="Search...">
              <span class="input-group-btn">
                <button type="submit" name="search" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i>
                </button>
              </span>
        </div>
      </form>
      <!-- /.search form -->
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu">
        <li class="header">MAIN NAVIGATION</li>
        <li class="active treeview">
          <a href="#">
            <i class="fa fa-group"></i> <span>Tenant</span>
            
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li> <a href="<?php echo base_url('tenant/') ?>"> <i class="fa fa-circle-o"></i> Add Tenant</a></li>
            <li> <a href="<?php echo base_url('viewtenant/') ?>"> <i class="fa fa-circle-o"></i> View Tenant</a></li>
          </ul>
        </li>
        
        <li class="active treeview">
          <a href="#">
            <i class="fa fa-home"></i> <span>House</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li class="active"><a href="<?php echo base_url('house/') ?>"><i class="fa fa-circle-o"></i> Add House</a></li>
            <!-- <li><a href="index2.html"><i class="fa fa-circle-o"></i> View Tenant</a></li> -->
          </ul>
        </li>
        
        <li class="active treeview">
          <a href="#">
            <i class="fa fa-home"></i> <span>Payments</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li class="active"><a href="index.html"><i class="fa fa-circle-o"></i> Pending Payments</a></li>
             <li><a href="index2.html"><i class="fa fa-circle-o"></i> Received Payments</a></li> 
          </ul>
        </li>
       
        
        
        <!-- <li>
          <a href="surendhar/pages/calendar.html">
            <i class="fa fa-calendar"></i> <span>Calendar</span>
            <span class="pull-right-container">
              <small class="label pull-right bg-red">3</small>
              <small class="label pull-right bg-blue">17</small>
            </span>
          </a>
        </li> -->
        
        <li class="treeview">
          <a href="#">
            <i class="fa fa-folder"></i> <span>Details</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="#"><i class="fa fa-circle-o"></i> Invoice</a></li>
            <li><a href="#"><i class="fa fa-circle-o"></i> Profile</a></li>
            <li><a href="#"><i class="fa fa-circle-o"></i> Login</a></li>
            <li><a href="#"><i class="fa fa-circle-o"></i> Register</a></li>
           
            
            
          </ul>
        </li>
        <li class="treeview">
          
          <ul class="treeview-menu">
            
            
    
          </ul>
        
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>

  <!--Left side end -->

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Data Tables
        <small>advanced tables</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Tables</a></li>
        <li class="active">Data tables</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          
            
            <!-- /.box-header -->
            

            <!-- <div class="float-right"><a href="javascript:void(0);" class="btn btn-primary" data-toggle="modal" data-target="#Modal_Edit"><span class="fa fa-plus"></span> Add New</a></div> -->

          <div class="box">
            <div class="box-header">
              <h3 class="box-title" style="margin-left:480px; color:#3c8dbc;"><strong>TENANT LIST</strong></h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
            <table class="table table-striped" id="example">
                <thead>
                    <tr>
                    <th>Id</th>
                  <th>Tenant Name</th>
                  <th>House</th>
                  <th>Gender</th>
                  <th>Nationality</th>
                  <th>Phone No</th>
                  <th>Email</th>
                  <th> Agreement Document</th>
                  <th> Registration_Date</th>
                  <th> Action</th>
                      
                    </tr>
                </thead>
                <tbody id="show_data">
                    
                </tbody>
            </table>

            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
<!-- MODAL EDIT -->
<form>
            <div class="modal fade" id="Modal_Edit" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Edit Tenanat Details</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                        <div class="form-group row">
                            <label class="col-md-2 col-form-label">Full Name</label>
                            <div class="col-md-10">
                              <input type="text" name="fullname_edit" id="fullname_edit" class="form-control" placeholder="fullname" readonly>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-2 col-form-label">House</label>
                            <div class="col-md-10">
                              <input type="text" name="house_edit" id="house_edit" class="form-control" placeholder="house">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-2 col-form-label">Gender</label>
                            <div class="col-md-10">
                              <input type="text" name="gender_edit" id="gender_edit" class="form-control" placeholder="Gender">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-md-2 col-form-label">National</label>
                            <div class="col-md-10">
                              <input type="text" name="national_id_edit" id="national_id_edit" class="form-control" placeholder="National">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-md-2 col-form-label">Phone No</label>
                            <div class="col-md-10">
                              <input type="text" name="phone_number_edit" id="phone_number_edit" class="form-control" placeholder="Phone Number">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-md-2 col-form-label">Email</label>
                            <div class="col-md-10">
                              <input type="text" name="email_edit" id="email_edit" class="form-control" placeholder="Email">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-md-2 col-form-label">Agreement</label>
                            <div class="col-md-10">
                              <input type="text" name="agreement_document_edit" id="agreement_document_edit" class="form-control" placeholder="Agreement">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-md-2 col-form-label">Registration_date</label>
                            <div class="col-md-10">
                              <input type="text" name="registration_date_edit" id="registration_date_edit" class="form-control" placeholder="Registration_date">
                            </div>
                        </div>

                        
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" type="submit" id="btn_update" class="btn btn-primary">Update</button>
                  </div>
                </div>
              </div>
            </div>
            </form>
        <!--END MODAL EDIT-->

        <!--MODAL DELETE-->
         <form>
            <div class="modal fade" id="Modal_Delete" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Delete House</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                       <strong>Are you sure to delete this House?</strong>
                  </div>
                  <div class="modal-footer">
                    <input type="hidden" name="fullname_delete" id="fullname_delete" class="form-control">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">No</button>
                    <button type="button" type="submit" id="btn_delete" class="btn btn-primary">Yes</button>
                  </div>
                </div>
              </div>
            </div>
            </form>
        <!--END MODAL DELETE-->

  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 2.3.8
    </div>
    <strong>Copyright &copy; 2014-2016 <a href="#">Aptitude Studio</a>.</strong> All rights
    reserved.
  </footer>

  <!-- Control Sidebar -->
  
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
 
</div>
<!-- ./wrapper -->



<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.22/pdfmake.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.4.1/html2canvas.min.js"></script>


<!-- <script src="<?= base_url('assets/js/main.js'); ?>"> -->
<script src="<?= base_url('surendhar/plugins/jQuery/jquery-2.2.3.min.js'); ?>"></script>
<!-- jQuery UI 1.11.4 -->
<script src="https://code.jquery.com/ui/1.11.4/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button);
</script>
<!-- Bootstrap 3.3.6 -->
<script src="<?= base_url('surendhar/bootstrap/js/bootstrap.min.js'); ?>"></script>
<!-- Morris.js charts -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
<script src="<?= base_url('surendhar/plugins/morris/morris.min.js'); ?>"></script>



<script type="text/javascript" src="<?php echo base_url().'assets/js/jquery-3.2.1.js'?>"></script>
<script type="text/javascript" src="<?php echo base_url().'assets/js/bootstrap.js'?>"></script>
<script type="text/javascript" src="<?php echo base_url().'assets/js/jquery.dataTables.js'?>"></script>
<script type="text/javascript" src="<?php echo base_url().'assets/js/dataTables.bootstrap4.js'?>"></script>

<script type="text/javascript">
	$(document).ready(function(){
		show_product();	//call function show all product
		
		$('#example1').dataTable();
		 
		//function show all product
		function show_product(){
		    $.ajax({
		        type  : 'ajax',
		        url   : '<?php echo site_url('Particular_tenant/tenant_data')?>',
		        async : false,
		        dataType : 'json',
		        success : function(data){
                   // console log(data);
                    
		            var html = '';
		            var i;
		            for(i=0; i<data.length; i++){
		                html += '<tr>'+
                                '<td>'+data[i].id+'</td>'+
		                  		'<td>'+data[i].fullname+'</td>'+
		                        '<td>'+data[i].house+'</td>'+
		                        '<td>'+data[i].gender+'</td>'+
                                '<td>'+data[i].national_id+'</td>'+
                                '<td>'+data[i].phone_number+'</td>'+
                                '<td>'+data[i].email+'</td>'+
                                '<td>'+data[i].agreement_document+'</td>'+
                                '<td>'+data[i].registration_date+'</td>'+
                                // '<td>'+data[i].exit_date+'</td>'+
		                        
                                '<td style="text-align:right;">'+
                                     '<a href="javascript:void(0);" data-toggle="modal" data-target="#Modal_Edit" class="btn btn-info btn-sm item_edit" data-fullname="'+data[i].fullname+'" data-house="'+data[i].house+'"  data-gender="'+data[i].gender+'" data-national_id="'+data[i].national_id+'" data-phone_number="'+data[i].phone_number+'" data-email="'+data[i].email+'" data-agreement_document="'+data[i].agreement_document+'" data-registration_date="'+data[i].registration_date+'">Edit</a>'+' </td> <td>'+
                                     '<a href="javascript:void(0);" data-toggle="modal" data-target="#Modal_Delete" class="btn btn-danger btn-sm item_delete" data-fullname="'+data[i].fullname+'">Delete</a>'+
                                 '</td>'+


		                        '</tr>';
		            }
		            $('#show_data').html(html);
		        }

		    });
		}

      /* Save product
        $('#btn_save').on('click',function(){
            var house_number = $('#house_number').val();                                                                                                                                    
            var features = $('#features').val();
            var rent        = $('#rent').val();
            $.ajax({
                type : "POST",
                url  : "<?//php echo site_url('house/save')?>",
                dataType : "JSON",
                data : {house_number:house_number , features:features, rent:rent},
                success: function(data){
                    $('[name="house_number"]').val("");
                    $('[name="features"]').val("");
                    $('[name="rent"]').val("");
                    $('#Modal_Add').modal('hide');
                    show_product();
                }
            });
            return false;
        }); */

       // get data for update record
        $('#show_data').on('click','.item_edit',function(){
            var fullname = $(this).data('fullname');
            var house = $(this).data('house');
            var gender        = $(this).data('gender');
            var national_id = $(this).data('national_id');
            var phone_number = $(this).data('phone_number');
            var email        = $(this).data('email');
            var agreement_document = $(this).data('agreement_document');
            var registration_date = $(this).data('registration_date');
            
            
            $('#Modal_Edit').modal('show');
            $('[name="fullname_edit"]').val(fullname);
            $('[name="house_edit"]').val(house);
            $('[name="gender_edit"]').val(gender);
            $('[name="national_id_edit"]').val(national_id);
            $('[name="phone_number_edit"]').val(phone_number);
            $('[name="email_edit"]').val(email);
            $('[name="agreement_document_edit"]').val(agreement_document);
            $('[name="registration_date_edit"]').val(registration_date);
           
          });

      //  // update record to database
         $('#btn_update').on('click',function(){
            var fullname = $('#fullname_edit').val();
            var house = $('#house_edit').val();
            var gender        = $('#gender_edit').val();
            var national_id = $('#national_id_edit').val();
            var phone_number = $('#phone_number_edit').val();
            var email        = $('#email_edit').val();
            var agreement_document = $('#agreement_document_edit').val();
            var registration_date = $('#registration_date_edit').val();
          
            $.ajax({
                type : "POST",
                url  : "<?php echo site_url('Particular_tenant/update')?>",
                dataType : "JSON",
                data : {fullname:fullname, house:house, gender:gender, national_id:national_id, phone_number:phone_number, email:email, agreement_document:agreement_document, registration_date:registration_date },
                success: function(data){
                    $('[name="fullname_edit"]').val("");
                    $('[name="house_edit"]').val("");
                    $('[name="gender_edit"]').val("");
                    $('[name="national_id_edit"]').val("");
                    $('[name="phone_number_edit"]').val("");
                    $('[name="email_edit"]').val("");
                    $('[name="agreement_document_edit"]').val("");
                    $('[name="registration_date_edit"]').val("");
                    
                    $('#Modal_Edit').modal('hide');
                    show_product();
                }
            });
            return false;
        });

      //  // get data for delete record
         $('#show_data').on('click','.item_delete',function(){
            var fullname = $(this).data('fullname');
            
            $('#Modal_Delete').modal('show');
            $('[name="fullname_delete"]').val(fullname);
        });

      //  // delete record to database
         $('#btn_delete').on('click',function(){
            var fullname = $('#fullname_delete').val();
            $.ajax({
                type : "POST",
                url  : "<?php echo site_url('Particular_tenant/delete')?>",
                dataType : "JSON",
                data : {fullname:fullname},
                success: function(data){
                    $('[name="fullname_delete"]').val("");
                    $('#Modal_Delete').modal('hide');
                    show_product();
                }
            });
            return false;
        });

	});

</script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
.btn {
  background-color: DodgerBlue;
  border: none;
  color: white;
  padding: 12px 12px;
  font-size: 11px;
  cursor: pointer;
}

/* Darker background on mouse-over */
.btn:hover {
  background-color: RoyalBlue;
}
</style>
</body>
</html>
