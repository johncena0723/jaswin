<table class="table table-bordered table-hover ">
	<tr><td><a href="<?php echo base_url();?>owner/index" >Home</a></td></tr>
	<tr><td><a href="<?php echo base_url();?>owner/allFlat">All Flat</a></td></tr>
	<tr><td><a href="<?php echo base_url();?>owner/addFlat">Add Flat</a></td></tr>
	<tr><td><a href="<?php echo base_url();?>owner/publishedFlat">Published Flat</a></td></tr>
	<tr><td><a href="<?php echo base_url();?>owner/unpublishedFlat">Unpublished Flat</a></td></tr>
	<tr><td><a href="">Upload Images</a></td></tr>
	<tr><td><a href="">Account Settings</a></td></tr>
	<tr><td><a href="<?php echo base_url();?>owner/LogOut" onclick="return confirm('Are you sure to Log Out?')">Log Out</a></td></tr>

</table>


