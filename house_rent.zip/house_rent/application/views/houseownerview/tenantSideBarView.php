<!DOCTYPE html>
<html>
<head>
	<?php  $this->load->view('headerview/headerCSSLink')?>

	<title>Home:: Owner</title>

</head>
<body >

	<div class="container" style="background-color:white; margin-top: 100px; padding-bottom: 100px;">
		
		<center><h1>Welcome To ABC House Rent</h1><hr>

		<h4>Welcome To Owner Home </h4><hr>

		<div class="row">
	
			<div class="col-sm-3" >

				<?php $this->load->view('houseownerview/tenantSideBarView');?>

			</div>
			<div class="col-sm-9" >
				
				Fulloname :: {fullname} <br>

				Email :: {email} <br>

				Mobile:: {phone_number} <br>

				Account Created at:: {createdat} <br>


			</div>
		</div>

			
		</center>
	</div>

</body>
</html>