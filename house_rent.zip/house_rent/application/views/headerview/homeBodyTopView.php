<a href="<?php echo base_url();?>" >Home</a><br>
<a href="<?php echo base_url();?>home/ownerRegistration" >Register As a Home Owner</a><br>
<a href="<?php echo base_url();?>home/LogIn" >Log In</a>
<center><h1>Welcome To ABC House Rent</h1><hr>