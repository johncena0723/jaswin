<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>public/css/homeBody.css">
<link rel="stylesheet" href="<?php echo base_url();?>public/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>public/css/bootstrap-theme.min.css">
