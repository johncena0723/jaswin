<?php
echo 'hello';
// Multiple recipients
$to = 'harish@gmail.com, sally@example.com'; // note the comma

// Subject
$subject = 'Rental Reminders for March';

// Message
$message = '
<html>
<head>
  <title>Rental Reminders for August</title>
</head>
<body>
  <p>Here are the Rental upcoming in months!</p>
  <table>
    <tr>
      <th>Harish</th><th>07</th><th>March</th><th>2020</th>
    </tr>
    <tr>
     
    </tr>
    <tr>
    
    </tr>
  </table>
</body>
</html>
';

// To send HTML mail, the Content-type header must be set
$headers[] = 'MIME-Version: 1.0';
$headers[] = 'Content-type: text/html; charset=iso-8859-1';

// Additional headers
$headers[] = 'To: Mary <surendharchinna@gmail.com>, Kelly <kelly@example.com>';
$headers[] = 'From: Rental Reminder <test1@example.com>';
$headers[] = 'Cc: test@example.com';
$headers[] = 'Bcc: admin@example.com';

// Mail it
mail($to, $subject, $message, implode("\r\n", $headers));
?>