<?php
class Particular_Tenantmodel extends CI_Model{

	function tenant_list(){
        $hasil=$this->db->get('tenants');
        
        //print_r($hasil); die();
		return $hasil->result();
	}

// 	function save_product(){
// 		$data = array(
// 			   'house_number' 	=> $this->input->post('house_number'), 
// 			   'features' 	=> $this->input->post('features'), 
// 			   'rent' => $this->input->post('rent'), 
// 		   );
// 	   $result=$this->db->insert('houses',$data);
// 	   //print_r($data); die();
// 	   return $result;	
//    }

   function update_product(){
	   $fullname=$this->input->post('fullname');
	   $house=$this->input->post('house');
	   $gender=$this->input->post('gender');
	   $national_id=$this->input->post('national_id');
	   $email=$this->input->post('email');
	   $phone_number=$this->input->post('phone_number');
	   $agreement_document=$this->input->post('agreement_document');
	   $registration_date=$this->input->post('registration_date');
	  



	   $this->db->set('fullname', $fullname);
	   $this->db->set('house', $house);
	   $this->db->set('gender', $gender);
	   $this->db->set('national_id', $national_id);
	   $this->db->set('email', $email);
	   $this->db->set('phone_number', $phone_number);
	   $this->db->set('agreement_document', $agreement_document);
	   $this->db->set('registration_date', $registration_date);
	   
	   $this->db->where('fullname', $fullname);
	   $result=$this->db->update('tenants');
	  // print_r($);die();
	   return $result;
   }

   function delete_product(){
	   $fullname=$this->input->post('fullname');
	   $this->db->where('fullname', $fullname);
	   $result=$this->db->delete('tenants');
	   return $result;
   }
	
}
?>