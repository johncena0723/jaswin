<?php  
defined('BASEPATH') OR exit('No direct script access allowed');  
  
class TenantModel extends CI_Model {  
  
    function __construct()  
    {  
        //call model constructor  
        parent::__construct();  
    }     
          
        function fetchtable()  
        {  
            $query = $this->db->get('tenants');  
            return $query->result();  
        }  
}  
?>  