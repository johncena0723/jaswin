<?php
class House_model extends CI_Model{

	function house_list(){
        $hasil=$this->db->get('houses');
       // print_r($hasiil); die();
		return $hasil->result();
	}

	function save_product(){
		 $data = array(
				'house_number' 	=> $this->input->post('house_number'), 
				'features' 	=> $this->input->post('features'), 
				'rent' => $this->input->post('rent'), 
			);
        $result=$this->db->insert('houses',$data);
        //print_r($data); die();
		return $result;	
	}

	function update_product(){
		$house_number=$this->input->post('house_number');
		$features=$this->input->post('features');
		$rent=$this->input->post('rent');

		$this->db->set('features', $features);
		$this->db->set('rent', $rent);
		$this->db->where('house_number', $house_number);
		$result=$this->db->update('houses');
		return $result;
	}

	function delete_product(){
		$house_number=$this->input->post('house_number');
		$this->db->where('house_number', $house_number);
		$result=$this->db->delete('houses');
		return $result;
	}
	
}