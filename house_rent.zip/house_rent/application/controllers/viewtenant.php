<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Viewtenant extends CI_Controller {

	public function __construct(){

		parent::__construct();

		$this->load->model("tenantModel","a");

	}

	public function index()
	{
$this->load->view('view_tenant');

        //$this->load->view('add_tenant');
		
    }
    
   
	


    }
    ?>
	
	
	
		
	

