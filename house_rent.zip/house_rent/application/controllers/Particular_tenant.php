<?php
class Particular_tenant extends CI_Controller{
	function __construct(){
		parent::__construct();
		$this->load->model('Particular_Tenantmodel');
	}
	function index(){

		$this->load->view('particular_view_tenant');
	}

	function tenant_data(){
        $data=$this->Particular_Tenantmodel->tenant_list();
        
        print_r($data); die();
		echo json_encode($data);
	}

    function save(){
		$data=$this->Particular_Tenantmodel->save_product();
		echo json_encode($data);
	}

	function update(){
		$data=$this->Particular_Tenantmodel->update_product();
		echo json_encode($data);
	}

	function delete(){
		$data=$this->Particular_Tenantmodel->delete_product();
		echo json_encode($data);
	}

	
}
?>