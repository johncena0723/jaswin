<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	public function index()
	{
		
		$this->load->view('adminview/view_adminHome');

	}
	
	public function process()  
    {  
        $user = $this->input->post('user');  
        $pass = $this->input->post('pass');  
        if ($user=='admin' && $pass=='admin')   
        {  
            //declaring session  
            $this->session->set_userdata(array('user'=>$user));  
            //$this->load->view('Dashboard');  
            $this->load->view('Dashboard');
        }  
        else{  

             

redirect('admin'); 



        }  
    }  
    public function logout()  
    {  
        //removing session  
        $this->session->unset_userdata('user');  
        redirect("admin");  
    }  
  
}  

/*public function register(){
    if (($this->session->userdata('uid') != "")) {
        redirect(site_url('home'));
    } else {
        $this->load->view('register');
    }
}

public function login(){
    if (($this->session->userdata('uid') != "")) {
        redirect(site_url('home'));
    } else {
        $this->load->view('login');
    }
}*/
	
?>
