<?php  
defined('BASEPATH') OR exit('No direct script access allowed');  
  
class In_voice extends CI_Controller {  
      
    public function index()  
    {  
        $this->load->view('ingenarator'); 
       //  echo 'hello ';
    }

    public function addinvoice()
	{

		
            
                    $data = array(
						
						't_name' => $this->input->post('t_name'),
						'amount' => $this->input->post('amount'),
						'n_house' => $this->input->post('n_house')
						// 'subtotal' => $this->input->post('subtotal'),
						// 'discount' => $this->input->post('discount'),
						// 'shipping' => $this->input->post('shipping'),
						// 'grandTotal' => $this->input->post('grandTotal'),
						
						
						//'isPublished' => '0'
						
					);
                    $this->db->insert('new_invoice',$data);
                   // print_r($data); die();
					//print_r($data); die();
					redirect ("in_voice/index");

//                    $this->session->set_flashdata('addSuccessMessage', ' ');

					
            

		}

}  
   
?>  