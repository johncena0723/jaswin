<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tenant extends CI_Controller {

	public function __construct(){

		parent::__construct();

		//$this->load->model("tenantModel","a");
		$this->load->helper('url');    //loads a helper class for working with URLs
    $this->load->helper('file');   //loads a helper class for working with the files
    $this->load->database();    //loads a database

	}

	public function index()
	{
		$this->load->view('add_tenant');
		
	}
//$email = $_POST['email'];
	function rolekey_exists($email) {
		$this->tenantModel->mail_exists($email);
	  }


	public function addtenant()
	{

		
            
                    $data = array(
						
						'fullname' => $this->input->post('fullname'),
						'house' => $this->input->post('house'),
						'email' => $this->input->post('email'),
						'password' => $this->input->post('password'),
						'gender' => $this->input->post('gender'),
						'national_id' => $this->input->post('national_id'),
						'registration_date' => $this->input->post('registration_date'),
						'phone_number' => $this->input->post('phone_number'),
						'exit_date' => $this->input->post('exit_date'),
						'agreement_document' => $this->input->post('agreement_document')
						
						//'isPublished' => '0'
						
					);
					$this->db->insert('tenants',$data);
					//print_r($data); die();
					redirect ("tenant/index");

//                    $this->session->set_flashdata('addSuccessMessage', ' ');

					
            

		}
		


	}
	?>
	
	
	
		
	

