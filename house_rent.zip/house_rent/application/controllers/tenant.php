<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tenant extends CI_Controller {

	public function __construct(){

		parent::__construct();

		//$this->load->model("tenantModel","a");

	}

	public function index()
	{
		$this->load->view('add_tenant');
		
	}
	public function addtenant()
	{

		
            
                    $data = array(
						
						'fullname' => $this->input->post('fullname'),
						'house' => $this->input->post('house'),
						'email' => $this->input->post('email'),
						'gender' => $this->input->post('gender'),
						'national_id' => $this->input->post('national_id'),
						'registration_date' => $this->input->post('registration_date'),
						'phone_number' => $this->input->post('phone_number'),
						'exit_date' => $this->input->post('exit_date'),
						'agreement_document' => $this->input->post('agreement_document')
						
						//'isPublished' => '0'
						
					);
					$this->db->insert('tenants',$data);
					//print_r($data); die();
					redirect ("tenant/index");

//                    $this->session->set_flashdata('addSuccessMessage', ' ');

					
            

		}
		


	}
	?>
	
	
	
		
	

