 

<?php
class Login extends CI_Controller 
{
	public function __construct()
	{
	parent::__construct();
	$this->load->database();
    $this->load->helper('url');
    $this->load->library('session');
   // $this->load->model('Particular_Tenantmodel');
    }
    public function index()  
    {  
        $this->load->view('homeview/new_view_LogIn'); 
        
       // echo 'hello ';
    }  


    
    
    //To retrieve
    
    

	public function process()
	{

        
		//$this->session->set_userdata(array('fullname'=>$user));  
        if($this->input->post('login'))
        
		{
            $name=$this->input->post('fullname');
			$e=$this->input->post('email');
			$p=$this->input->post('password');
    
            $this->session->set_userdata(array('fullname'=>$name)); 
            
            $que=$this->db->query("select * from tenants where fullname='".$name."' and password='$p'");
            
			$row = $que->num_rows();
            if($row)
            
			{
            //redirect('Tenant_dashboard');
            
            $this->load->view('tenant_Dashboard');
			}
			else
			{
        $data['error']="<h4 style='color:red; margin-left:80px'><b>Invalid login details</b></h4>";
        
			}	
		}
		//$this->load->view('homeview/new_view_login',@$data);		
	}
	
	
    public function logout()  
    {  
        //removing session  
        $this->session->unset_userdata('fullname');  
        redirect("Login");  
    } 
}
?>



<?php  
/*defined('BASEPATH') OR exit('No direct script access allowed');  
  
class Login extends CI_Controller {  
      
    public function index()  
    {  
        $this->load->view('homeview/new_view_LogIn'); 
        
       // echo 'hello ';
    }  
    public function process()  
    {  
        $user = $this->input->post('user');  
        $pass = $this->input->post('pass');  
        if ($user=='aptitude' && $pass=='1234')   
        {  
            //declaring session  
            $this->session->set_userdata(array('user'=>$user));  
            //$this->load->view('Dashboard');  
            $this->load->view('tenant_Dashboard');
        }  
        else{  
//         //      $data['error'] = '<span style="color:red;">Your Account is Invalid</span>';  
//         //     // $message = "wrong answer";
//         //     // echo "<script type='text/javascript'>alert('$data');</script>";

//         //     // redirect('Login'); 
//         //    $this->load->view('homeview/new_view_LogIn', $data);  

             
echo '<script type="text/javascript">';
echo ' alert("Your account is invalid")';  //not showing an alert box.
echo '</script>';
//echo ' Your account is invalid';
redirect('Login'); 



        }  
    }  

    function update(){
		$data=$this->house_model->update_product();
		echo json_encode($data);
    } 
    
    public function logout()  
    {  
        //removing session  
        $this->session->unset_userdata('user');  
        redirect("Login");  
    }  
  
}  

/*public function register(){
    if (($this->session->userdata('uid') != "")) {
        redirect(site_url('home'));
    } else {
        $this->load->view('register');
    }
}

public function login(){
    if (($this->session->userdata('uid') != "")) {
        redirect(site_url('home'));
    } else {
        $this->load->view('login');
    }
}*/
?>  