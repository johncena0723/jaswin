<?php
class House extends CI_Controller{
	function __construct(){
		parent::__construct();
		$this->load->model('house_model');
	}
	function index(){
		$this->load->view('house_view');
	}

	function house_data(){
        $data=$this->house_model->house_list();
       // print_r($data); die();
		echo json_encode($data);
	}

	function save(){
		$data=$this->house_model->save_product();
		echo json_encode($data);
	}

	function update(){
		$data=$this->house_model->update_product();
		echo json_encode($data);
	}

	function delete(){
		$data=$this->house_model->delete_product();
		echo json_encode($data);
	}

}