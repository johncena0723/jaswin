<?php
class Mail extends CI_Controller{
	function __construct(){
		parent::__construct();
		//$this->load->model('Particular_Tenantmodel');
	}
	function index(){

		$this->load->view('simple_mail');
	}

	
	
}
?>